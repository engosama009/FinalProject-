using System;
using System.Data;
using System.Windows.Forms;

namespace Dental_Clinic_Management
{
    public partial class HistoryForm : Form
    {
        private HistoryManager historyManager;
        private int selectedClientId = -1;
        private int selectedHistoryId = -1;

        public HistoryForm()
        {
            InitializeComponent();
            historyManager = new HistoryManager();
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // Load clients into combobox
            LoadClients();
            
            // Load all history records
            LoadAllHistoryRecords();
        }

        private void LoadClients()
        {
            try
            {
                // Create a connection to the database
                using (SqlConnection connection = new SqlConnection(historyManager.ConnectionString))
                {
                    string query = @"
                        SELECT 
                            CodeClient,
                            Name + ' ' + LastName AS FullName
                        FROM 
                            Client
                        ORDER BY 
                            Name, LastName";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable clientsTable = new DataTable();
                    adapter.Fill(clientsTable);

                    // Add a default "All Clients" option
                    DataRow allClientsRow = clientsTable.NewRow();
                    allClientsRow["CodeClient"] = -1;
                    allClientsRow["FullName"] = "-- All Clients --";
                    clientsTable.Rows.InsertAt(allClientsRow, 0);

                    // Bind to combobox
                    cmbClients.DataSource = clientsTable;
                    cmbClients.DisplayMember = "FullName";
                    cmbClients.ValueMember = "CodeClient";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading clients: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadAllHistoryRecords()
        {
            DataTable historyTable = historyManager.GetAllHistoryRecords();
            dgvHistory.DataSource = historyTable;

            // Format the grid
            FormatHistoryGrid();
        }

        private void LoadClientHistory(int clientId)
        {
            DataTable historyTable = historyManager.GetClientHistory(clientId);
            dgvHistory.DataSource = historyTable;

            // Format the grid
            FormatHistoryGrid();
        }

        private void FormatHistoryGrid()
        {
            // Set column headers and visibility
            if (dgvHistory.Columns.Count > 0)
            {
                dgvHistory.Columns["CodeHist"].HeaderText = "ID";
                dgvHistory.Columns["CauseOFVisite"].HeaderText = "Cause of Visit";
                dgvHistory.Columns["DateVisite"].HeaderText = "Visit Date";
                
                if (dgvHistory.Columns.Contains("ClientName"))
                {
                    dgvHistory.Columns["ClientName"].HeaderText = "Client";
                    dgvHistory.Columns["CodeClient"].Visible = false;
                }
            }

            // Auto-size columns
            dgvHistory.AutoResizeColumns();
        }

        private void cmbClients_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClients.SelectedValue != null)
            {
                selectedClientId = Convert.ToInt32(cmbClients.SelectedValue);
                
                if (selectedClientId == -1)
                {
                    // "All Clients" selected
                    LoadAllHistoryRecords();
                }
                else
                {
                    // Specific client selected
                    LoadClientHistory(selectedClientId);
                }
            }
        }

        private void dgvHistory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedHistoryId = Convert.ToInt32(dgvHistory.Rows[e.RowIndex].Cells["CodeHist"].Value);
                txtCauseOfVisit.Text = dgvHistory.Rows[e.RowIndex].Cells["CauseOFVisite"].Value.ToString();
                
                // Enable update and delete buttons
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (selectedClientId <= 0)
            {
                MessageBox.Show("Please select a client first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCauseOfVisit.Text))
            {
                MessageBox.Show("Please enter a cause of visit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool success = historyManager.AddHistoryRecord(txtCauseOfVisit.Text, selectedClientId);
            
            if (success)
            {
                MessageBox.Show("History record added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCauseOfVisit.Clear();
                
                // Refresh the grid
                if (selectedClientId == -1)
                {
                    LoadAllHistoryRecords();
                }
                else
                {
                    LoadClientHistory(selectedClientId);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedHistoryId <= 0)
            {
                MessageBox.Show("Please select a history record to update.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCauseOfVisit.Text))
            {
                MessageBox.Show("Please enter a cause of visit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool success = historyManager.UpdateHistoryRecord(selectedHistoryId, txtCauseOfVisit.Text);
            
            if (success)
            {
                MessageBox.Show("History record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCauseOfVisit.Clear();
                selectedHistoryId = -1;
                
                // Disable update and delete buttons
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
                
                // Refresh the grid
                if (selectedClientId == -1)
                {
                    LoadAllHistoryRecords();
                }
                else
                {
                    LoadClientHistory(selectedClientId);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedHistoryId <= 0)
            {
                MessageBox.Show("Please select a history record to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this history record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if (result == DialogResult.Yes)
            {
                bool success = historyManager.DeleteHistoryRecord(selectedHistoryId);
                
                if (success)
                {
                    MessageBox.Show("History record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCauseOfVisit.Clear();
                    selectedHistoryId = -1;
                    
                    // Disable update and delete buttons
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    
                    // Refresh the grid
                    if (selectedClientId == -1)
                    {
                        LoadAllHistoryRecords();
                    }
                    else
                    {
                        LoadClientHistory(selectedClientId);
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCauseOfVisit.Clear();
            selectedHistoryId = -1;
            
            // Disable update and delete buttons
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }
    }
}
