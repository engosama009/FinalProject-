-- Add missing columns to Client table
USE [dentaldoctor]
GO

-- Check if Allergies column exists, if not add it
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Allergies')
BEGIN
    ALTER TABLE Client ADD Allergies NVARCHAR(255) NULL;
END
GO

-- Check if CreatedAt column exists, if not add it
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'CreatedAt')
BEGIN
    ALTER TABLE Client ADD CreatedAt DATETIME DEFAULT GETDATE();
END
GO

-- Check if Status column exists, if not add it
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Status')
BEGIN
    ALTER TABLE Client ADD Status NVARCHAR(20) DEFAULT 'Active';
END
GO

-- Update existing records to have default values
UPDATE Client SET 
    Allergies = 'None',
    CreatedAt = GETDATE(),
    Status = 'Active'
WHERE Allergies IS NULL OR CreatedAt IS NULL OR Status IS NULL;
GO
