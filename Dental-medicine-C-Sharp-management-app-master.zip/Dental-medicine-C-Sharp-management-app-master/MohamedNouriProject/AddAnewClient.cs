﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MohamedNouriProject
{


    public partial class AddAnewClient : Form
    {


        public AddAnewClient()
        {
            InitializeComponent();


            if (ClientList.EditorAttribute)
            {


                button1.Text = "Edit";


            }

            // Add FormClosing event handler to properly close the form
            this.FormClosing += new FormClosingEventHandler(AddAnewClient_FormClosing);
        }

        /// <summary>
        /// Event handler for form closing
        /// </summary>
        private void AddAnewClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Make sure the form actually closes and doesn't just hide
            this.Dispose();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
         //   MessageBox.Show(ClientList.iduser);


            if (ValidateChildren(ValidationConstraints.Enabled))
            {




            string sex = "";
            if (radioFemme.Checked)
            {
                sex = "Female";
            }
            else
            {
                sex = "Male";
            }


            if (ClientList.EditorAttribute)
            {


             UpdateFournisseur(ClientList.iduser,userName.Text, lastName.Text, date.Value.Date, sex, adresse.Text, work.Text, telNumber.Text, email.Text, allergies.Text);


                return;
            }



                InsertFournisseur(userName.Text,lastName.Text,date.Value.Date, sex, adresse.Text, work.Text , telNumber.Text,email.Text, allergies.Text);

            }
            else
            {
                MessageBox.Show("Please check your input and try again!");

                return;
            }
        }







        private void UpdateFournisseur(string id, string Name, string LastName, DateTime DateOfBirth, string Sexe, string Adresse, string Profession, string TelNumber, string Email, string Allergies)
        {









            string Query = " UPdate   Client SET  Name = @CLIENT_Name , LastName = @CLIENT_LastName, DateOfBirth = @CLIENT_DateOfBirth, Sexe = @CLIENT_SEXE, Adresse = @CLIENT_Adresse, Profession = @CLIENT_Profession, TelNumber = @CLIENT_TelNumber, Email = @CLIENT_Email, Allergies = @CLIENT_Allergies, Status = 'Active' WHERE CodeClient = @fn";


            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True");
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(Query, connection);
                command.Parameters.AddWithValue("@CLIENT_Name", Name);
                command.Parameters.AddWithValue("@CLIENT_LastName", LastName);
                command.Parameters.AddWithValue("@CLIENT_SEXE", Sexe);
                command.Parameters.AddWithValue("@CLIENT_DateOfBirth", DateOfBirth);
                command.Parameters.AddWithValue("@CLIENT_Adresse", Adresse);
                command.Parameters.AddWithValue("@CLIENT_Profession", Profession);
                command.Parameters.AddWithValue("@CLIENT_TelNumber", TelNumber);
                command.Parameters.AddWithValue("@CLIENT_Email", Email);
                command.Parameters.AddWithValue("@CLIENT_Allergies", Allergies);

 command.Parameters.AddWithValue("@fn", id);
                if (command.ExecuteNonQuery() == 0)
                    throw new ApplicationException("No rows were updated. Please check your parameters!");
                else
                    MessageBox.Show("Client updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();

            }


        }




        private void InsertFournisseur(string Name, string LastName, DateTime DateOfBirth, string Sexe, string Adresse, string Profession, string TelNumber, string Email, string Allergies)
        {









            string Query = " INSERT INTO Client (Name, LastName, DateOfBirth, Sexe, Adresse, Profession, TelNumber, Email, Allergies, CreatedAt, Status)" +
                " VALUES (" +
                "@CLIENT_Name," +
                "@CLIENT_LastName," +
                "@CLIENT_DateOfBirth," +
                " @CLIENT_SEXE," +
                "@CLIENT_Adresse ," +
                "@CLIENT_Profession," +
                "@CLIENT_TelNumber," +
                "@CLIENT_Email," +
                "@CLIENT_Allergies," +
                "@CLIENT_CreatedAt," +
                "@CLIENT_Status" +
                ") ";

 ;

            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True");
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(Query, connection);
                command.Parameters.AddWithValue("@CLIENT_Name", Name);
                command.Parameters.AddWithValue("@CLIENT_LastName", LastName);
                command.Parameters.AddWithValue("@CLIENT_SEXE", Sexe);
                command.Parameters.AddWithValue("@CLIENT_DateOfBirth", DateOfBirth);
                command.Parameters.AddWithValue("@CLIENT_Adresse", Adresse);
                command.Parameters.AddWithValue("@CLIENT_Profession", Profession);
                command.Parameters.AddWithValue("@CLIENT_TelNumber", TelNumber);
                command.Parameters.AddWithValue("@CLIENT_Email", Email);
                command.Parameters.AddWithValue("@CLIENT_Allergies", Allergies);
                command.Parameters.AddWithValue("@CLIENT_CreatedAt", DateTime.Now);
                command.Parameters.AddWithValue("@CLIENT_Status", "Active");


                if (command.ExecuteNonQuery() == 0)
                    throw new ApplicationException("No rows were inserted. Please check your parameters!");
                else
                    MessageBox.Show("Client created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();

            }


        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Annuler_Click(object sender, EventArgs e)
        {
            while (Controls.Count > 0)
            {
                Controls[0].Dispose();
            }
            this.Close();
            this.Close();
        }

        private void userName_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(userName, e);
        }

        private void userPrenom_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(lastName, e);
        }

        private void telNumber_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(telNumber, e);
        }

        private void work_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(work, e);
        }

        private void adresse_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(adresse, e);
        }



       void isEmpty(TextBox textB, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textB.Text))
            {
                e.Cancel = true;
                textB.Focus(); // Focus on the empty field instead of always lastName
                errorProvider1.SetError(textB, "This field cannot be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(textB, "");
            }
        }

        private void email_Validating(object sender, CancelEventArgs e)
        {
            isEmpty(email, e);
        }

        private void choosePhoto_Click(object sender, EventArgs e)
        {
            // Create an OpenFileDialog to allow the user to select an image
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.bmp)|*.jpg; *.jpeg; *.png; *.bmp";
            openFileDialog.Title = "Select Patient Photo";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Load the selected image and display it in the photoPanel
                    Image img = Image.FromFile(openFileDialog.FileName);

                    // Create a PictureBox to display the image
                    PictureBox pictureBox = new PictureBox();
                    pictureBox.Image = img;
                    pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
                    pictureBox.Dock = DockStyle.Fill;

                    // Clear any existing controls in the photoPanel
                    photoPanel.Controls.Clear();

                    // Add the PictureBox to the photoPanel
                    photoPanel.Controls.Add(pictureBox);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading image: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
