﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MohamedNouriProject.Model
{


    class Client
    {
        public String Name { get; set; }
        public String LastName { get; set; }
        public String TelNumber { get; set; }
        public String Email { get; set; }
        public String Allergies { get; set; }
        public DateTime CreatedAt { get; set; }
        public String Status { get; set; }
    }
}
