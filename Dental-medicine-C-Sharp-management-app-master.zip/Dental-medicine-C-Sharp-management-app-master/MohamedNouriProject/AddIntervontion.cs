﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MohamedNouriProject.Resources
{
    public partial class AddIntervontion : Form
    {


        public int CodeDent = 1;

        String connetionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";
        public AddIntervontion()
        {
            InitializeComponent();

          //  MessageBox.Show(Oppointment.iduser);
            if (Oppointment.EditorAttribute)
            {


               // button1.Text = "Modifier";

            }


            using (SqlConnection con = new SqlConnection(connetionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Dent", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {

                            sda.Fill(dt);

                            //Assign DataTable as DataSource.

                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                checkedListBox.Items.Add(dt.Rows[i]["CodeDent"].ToString());

                            }
                        }
                    }

                }

            }

            // Add FormClosing event handler to properly close the form
            this.FormClosing += new FormClosingEventHandler(AddIntervontion_FormClosing);
        }

        /// <summary>
        /// Event handler for form closing
        /// </summary>
        private void AddIntervontion_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Make sure the form actually closes and doesn't just hide
            this.Dispose();
        }

        private void AddIntervontion_Load(object sender, EventArgs e)
        {


        }

        private void checkedListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


                InsertFournisseur(Cout.Text, Oppointment.CodeClientS, DateTime.Now , NbreInt.Text, Observations.Text, comboBox2.Text, CodeDent );


        }



        private void InsertFournisseur(string Cout, string CodeClient, DateTime Date, String Nbre,String observation, String Acte, int CodeDent )
        {

            using (SqlConnection
                    connection = new SqlConnection(connetionString))
            {

                try
                {
                    connection.Open();
                    string Query = " INSERT INTO Interventions (Cout, Date, Nbre, CodeClient,observation,Acte,CodeDent)" +
            " VALUES ( @CLIENT_Cout, @CLIENT_Date, @CLIENT_Nbre  , @CLIENT_CodeClient , @CLIENT_observation  , @CLIENT_Acte  ,@CLIENT_CodeDent)" ;




                    SqlCommand command = new SqlCommand(Query, connection);
                    // Convert Cout to decimal to avoid string conversion issues
                    decimal coutValue;
                    if (decimal.TryParse(Cout, out coutValue))
                    {
                        command.Parameters.AddWithValue("@CLIENT_Cout", coutValue);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("@CLIENT_Cout", DBNull.Value);
                    }
                    command.Parameters.AddWithValue("@CLIENT_CodeClient", CodeClient);
                    command.Parameters.AddWithValue("@CLIENT_Date", Date);
                    // Convert Nbre to integer to avoid string conversion issues
                    int nbreValue;
                    if (int.TryParse(Nbre, out nbreValue))
                    {
                        command.Parameters.AddWithValue("@CLIENT_Nbre", nbreValue);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("@CLIENT_Nbre", DBNull.Value);
                    }
                    command.Parameters.AddWithValue("@CLIENT_observation", observation);
                    command.Parameters.AddWithValue("@CLIENT_Acte", Acte);

                    command.Parameters.AddWithValue("@CLIENT_CodeDent", CodeDent);





                    if (command.ExecuteNonQuery() == 0)
                        throw new ApplicationException("No row inserted, check the settings!");
                    else
                        MessageBox.Show("Created");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    connection.Close();

                }


            }
        }

        private void Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
