﻿﻿﻿﻿﻿﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using MohamedNouriProject.db;

namespace MohamedNouriProject
{

    public partial class Home : Form
    {



        public string   usernameValue

        {
            set { userName.Text = value; }
        }



        // Using DatabaseConnection class instead of defining connection string here
        public Home()
        {
            InitializeComponent();

            //  dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            //  usersList.Show();
            GetResumNumber();

            fillChart2();

            // Add FormClosing event handler to properly close the application
            this.FormClosing += new FormClosingEventHandler(Home_FormClosing);
        }

        /// <summary>
        /// Event handler for form closing
        /// </summary>
        private void Home_FormClosing(object sender, FormClosingEventArgs e)
        {
            // If user clicked X, exit the application
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit();
            }
        }



        private void GetResumNumber()
        {
            try
            {
                try
                {
                    // Query 1: Count clients
                    string query = "SELECT COUNT(*) FROM Client";
                    object result = DatabaseConnection.ExecuteScalar(query);
                    Int32 count = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);
                    sumLabel1.Text = count.ToString();

                    // Query 2: Count appointments
                    string query2 = "SELECT COUNT(*) FROM RDV";
                    result = DatabaseConnection.ExecuteScalar(query2);
                    count = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);
                    sumLabel2.Text = count.ToString();

                    // Query 3: Count interventions
                    string query3 = "SELECT COUNT(*) FROM Interventions";
                    result = DatabaseConnection.ExecuteScalar(query3);
                    count = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);
                    sumLabel3.Text = count.ToString();

                    // Query 4: Sum intervention costs
                    string query5 = "SELECT SUM(cout) FROM Interventions";
                    result = DatabaseConnection.ExecuteScalar(query5);
                    count = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);
                    Sum.Text = count.ToString() + " $ ";

                    // Load grid data
                    BindGrid();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message,
                        "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // Set default values for labels
                    sumLabel1.Text = "0";
                    sumLabel2.Text = "0";
                    sumLabel3.Text = "0";
                    Sum.Text = "0 $";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BindGrid()
        {
            try
            {
                // Using parameterized query for date comparison
                string query = "SELECT * FROM RDV WHERE DateRDV = @dateRDV ORDER BY Time";

                // Create parameters array
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@dateRDV", SqlDbType.Date) { Value = DateTime.Today.Date }
                };

                // Use DatabaseConnection class to execute the query
                DataTable dt = DatabaseConnection.ExecuteQuery(query, parameters);

                // Clear existing columns and set AutoGenerateColumns to false
                dataGridView1.Columns.Clear();
                dataGridView1.AutoGenerateColumns = false;

                // Add and configure columns explicitly before setting the DataSource
                DataGridViewTextBoxColumn colCodeRDV = new DataGridViewTextBoxColumn();
                colCodeRDV.Name = "CodeRDV";
                colCodeRDV.HeaderText = "Code RDV"; // Or "Appointment Code"
                colCodeRDV.DataPropertyName = "CodeRDV"; // Matches DataTable column
                dataGridView1.Columns.Add(colCodeRDV);

                DataGridViewTextBoxColumn colTime = new DataGridViewTextBoxColumn();
                colTime.Name = "Time";
                colTime.HeaderText = "Time";
                colTime.DataPropertyName = "Time"; // Matches DataTable column
                dataGridView1.Columns.Add(colTime);

                DataGridViewTextBoxColumn colComments = new DataGridViewTextBoxColumn();
                colComments.Name = "Comments";
                colComments.HeaderText = "Comments";
                colComments.DataPropertyName = "Commentaire"; // Matches DataTable column 'Commentaire'
                dataGridView1.Columns.Add(colComments);

                NbreTotalRDV.Text = dt.Rows.Count.ToString();

                // Set DataSource. Now the columns exist and are mapped.
                dataGridView1.DataSource = dt;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database error in BindGrid: " + ex.Message,
                    "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Clear the grid and set default values
                dataGridView1.DataSource = null;
                dataGridView1.Columns.Clear();
                NbreTotalRDV.Text = "0";
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred in BindGrid: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Home_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dentaldoctorDataSet.RDV' table. You can move it or remove it as needed.
            // this.rDVTableAdapter.Fill(this.dentaldoctorDataSet.RDV);
            // TODO: This line of code loads data into the 'dentaldoctorDataSet.RDV' table. You can move it or remove it as needed.
            // this.dataGridView1.Fill(this.dentaldoctorDataSet.RDV);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // MessageBox.Show(" Value at 0,0" + dataGridView1.Rows[0].Cells[0].Value);
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //this.rDVTableAdapter.FillBy(this.dentaldoctorDataSet.RDV);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void listeDesRendezVousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Llamar al mismo método que se usa para el botón de citas
            rdvButton_Click(sender, e);
        }

        private void rdvButton_Click(object sender, EventArgs e)
        {

            rootPanel.Controls.Clear();
              Oppointment usersList = new Oppointment();
           usersList.Dock = DockStyle.Fill;
           usersList.AutoScroll = true;

             this.rootPanel.Controls.Add(usersList);
            usersList.Show();

            //rootPanel.Refresh();

        }



        private void UserList(object sender, EventArgs e)
        {
            rootPanel.Controls.Clear();
            DentsListe usersList = new DentsListe();
             usersList.Dock = DockStyle.Fill;
             usersList.AutoScroll = true;

             this.rootPanel.Controls.Add(usersList);

            usersList.Show();
        }


        private void rootPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addANewClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Reset the editor attribute to ensure we're in "add" mode, not "edit" mode
            ClientList.EditorAttribute = false;
            ClientList.iduser = "";

            // Use the new SimpleClientForm instead of AddAnewClient
            SimpleClientForm fr1 = new SimpleClientForm();
            fr1.Show();
        }

        private void addARDVToolStripMenuItem_Click(object sender, EventArgs e)
        {

            AddAnOppointment fr1 = new AddAnOppointment();


            fr1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Clear the main panel
            rootPanel.Controls.Clear();

            // Add the original dashboard controls back
            // Note: Order might matter depending on docking/anchoring. Add bottom/fill controls first.
            rootPanel.Controls.Add(this.tableLayoutPanel6);
            rootPanel.Controls.Add(this.tableLayoutPanel5);

            // Refresh dashboard data
            GetResumNumber();
            fillChart2();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            History history = new History();
            rootPanel.Controls.Clear();
            history.Dock = DockStyle.Fill;
            history.AutoScroll = true;

            this.rootPanel.Controls.Add(history);

            history.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log out?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);




            if (dr == DialogResult.Yes)
            {
                //
                Authentification fr1 = new Authentification();
                fr1.Show();
                this.Hide();
            }

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void chart1_Click_1(object sender, EventArgs e)
        {

        }


        private void fillChart2()
        {
            try
            {
                // Clear existing chart titles to avoid duplicates
                chart1.Titles.Clear();

                try
                {
                    // Use DatabaseConnection class to execute the query
                    string query = "Select Cout,CodeDent from Interventions";
                    DataTable dt = DatabaseConnection.ExecuteQuery(query);

                    // Set data source for the chart
                    chart1.DataSource = dt;

                    // Configure data series
                    chart1.Series["Amount"].XValueMember = "CodeDent";
                    chart1.Series["Amount"].YValueMembers = "Cout";
                    chart1.Titles.Add("Cost / Tooth");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error in fillChart2: " + ex.Message,
                        "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // Clear chart data
                    chart1.DataSource = null;
                    chart1.Titles.Add("No Data Available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred in fillChart2: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void usersbuttons_Click(object sender, EventArgs e)
        {



                 rootPanel.Controls.Clear();
            ClientList usersList = new ClientList();
            usersList.Dock = DockStyle.Fill;
            usersList.AutoScroll = true;

            this.rootPanel.Controls.Add(usersList);

            usersList.Show();

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            rootPanel.Controls.Clear();
            History usersList = new History();
            usersList.Dock = DockStyle.Fill;
            usersList.AutoScroll = true;

            this.rootPanel.Controls.Add(usersList);

            usersList.Show();
        }

        private void tableLayoutPanel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addDentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddDent fr1 = new AddDent();
            fr1.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Ask user for confirmation before exiting
            DialogResult dr = MessageBox.Show("هل أنت متأكد من أنك تريد إغلاق التطبيق؟", "إغلاق التطبيق",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                // Exit the application
                Application.Exit();
            }
        }
    }
}
