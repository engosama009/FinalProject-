﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MohamedNouriProject
{
    public partial class AddDent : Form
    {

        SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True");
        String connetionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";
        DataTable dt = new DataTable();
        public AddDent()
        {
            InitializeComponent();

            // Add FormClosing event handler to properly close the form
            this.FormClosing += new FormClosingEventHandler(AddDent_FormClosing);
        }

        /// <summary>
        /// Event handler for form closing
        /// </summary>
        private void AddDent_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Make sure the form actually closes and doesn't just hide
            this.Dispose();
        }

        // معرف السن المراد تعديله (إذا كان في وضع التعديل)
        public string DentID { get; set; }

        private void save_Click(object sender, EventArgs e)
        {
            // التحقق من وجود نوع العلاج
            if (string.IsNullOrWhiteSpace(TreatmentType.Text))
            {
                MessageBox.Show("Please enter treatment type", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // التحقق مما إذا كان النموذج في وضع التعديل أو الإضافة
            bool isEditMode = !string.IsNullOrEmpty(DentID) && this.Text.Contains("Edit");

            if (isEditMode)
            {
                // وضع التعديل - تحديث سن موجود
                try
                {
                    connection.Open();
                    string updateQuery = "UPDATE Dent SET TreatmentType = @TreatmentType, Cost = @Cost WHERE CodeDent = @CodeDent";

                    SqlCommand command = new SqlCommand(updateQuery, connection);
                    command.Parameters.AddWithValue("@TreatmentType", TreatmentType.Text);

                    // تحويل معرف السن إلى رقم صحيح
                    // نفترض أن معرف السن تم التحقق منه مسبقًا في DentsListe.cs
                    int dentIdValue = int.Parse(DentID);
                    command.Parameters.AddWithValue("@CodeDent", dentIdValue);

                    // تحويل التكلفة إلى قيمة عشرية، وتعيين القيمة الافتراضية 0 إذا فشل التحويل
                    decimal costValue;
                    if (!decimal.TryParse(Cost.Text, out costValue))
                    {
                        costValue = 0;
                    }
                    command.Parameters.AddWithValue("@Cost", costValue);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No records were updated", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
            else
            {
                // وضع الإضافة - إضافة سن جديد
                string query = "SELECT COUNT(*) from Dent WHERE TreatmentType = @TreatmentType";
                int returnValue = 0;

                using (SqlConnection con = new SqlConnection(connetionString))
                {
                    using (SqlCommand sqlcmd = new SqlCommand(query, con))
                    {
                        sqlcmd.Parameters.Add("@TreatmentType", SqlDbType.VarChar).Value = TreatmentType.Text;
                        con.Open();
                        returnValue = Convert.ToInt32(sqlcmd.ExecuteScalar());

                        // التحقق مما إذا كان نوع العلاج موجودًا بالفعل
                        if (returnValue > 0)
                        {
                            MessageBox.Show("This treatment type already exists", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }

                try
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO Dent (TreatmentType, Cost) VALUES (@TreatmentType, @Cost)";

                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@TreatmentType", TreatmentType.Text);

                    // تحويل التكلفة إلى قيمة عشرية، وتعيين القيمة الافتراضية 0 إذا فشل التحويل
                    decimal costValue;
                    if (!decimal.TryParse(Cost.Text, out costValue))
                    {
                        costValue = 0;
                    }
                    command.Parameters.AddWithValue("@Cost", costValue);

                    if (command.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Created successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No records were inserted", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }

        }

        private void Annuler_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
