تعليمات تثبيت مكتبة iTextSharp
==========================

لاستخدام وظيفة تصدير PDF المباشر، تحتاج إلى تثبيت مكتبة iTextSharp. اتبع الخطوات التالية:

1. قم بتنزيل حزمة iTextSharp من NuGet:
   - افتح Visual Studio
   - انقر بزر الماوس الأيمن على المشروع في Solution Explorer
   - اختر "Manage NuGet Packages"
   - ابحث عن "iTextSharp"
   - قم بتثبيت الإصدار 5.5.13.3

2. بدلاً من ذلك، يمكنك تنزيل الملف مباشرة من:
   https://www.nuget.org/packages/iTextSharp/5.5.13.3

3. ضع ملف itextsharp.dll في المجلد:
   MohamedNouriProject\packages\iTextSharp.5.5.13.3\lib\

4. تأكد من أن المرجع في ملف المشروع (.csproj) يشير إلى المسار الصحيح:
   <Reference Include="itextsharp">
     <HintPath>packages\iTextSharp.5.5.13.3\lib\itextsharp.dll</HintPath>
   </Reference>

ملاحظة: إذا واجهت أي مشاكل في التشغيل، تأكد من نسخ ملف itextsharp.dll إلى مجلد bin\Debug أيضاً.
