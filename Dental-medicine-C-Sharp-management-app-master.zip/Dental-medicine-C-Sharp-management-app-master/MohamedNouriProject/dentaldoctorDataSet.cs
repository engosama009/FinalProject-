﻿namespace MohamedNouriProject
{


    partial class dentaldoctorDataSet
    {
        partial class UsersDataTable
        {
        }
    }
}
