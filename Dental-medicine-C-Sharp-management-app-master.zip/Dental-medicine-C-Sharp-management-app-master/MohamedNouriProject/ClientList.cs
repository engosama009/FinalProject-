﻿using System;
using System.Windows.Forms;
using System.Data;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;
using MohamedNouriProject.db;
using MohamedNouriProject.Utils;

namespace MohamedNouriProject
{
    /// <summary>
    /// User interface for displaying and managing the client list
    /// </summary>
    public partial class ClientList : UserControl
    {
        /// <summary>
        /// Variable that determines if the user is in edit mode
        /// </summary>
        public static Boolean EditorAttribute = false;

        /// <summary>
        /// Currently selected client ID
        /// </summary>
        public static string iduser = "";

        /// <summary>
        /// Constructor - Initializes the user interface and sets up the data grid
        /// </summary>
        public ClientList()
        {
            // Initialize UI components
            InitializeComponent();
            Console.WriteLine("Hello there");

            // Load client data into the grid
            BindGrid("");

            // Add column to display total cost
            DataGridViewTextBoxColumn costColumn = new DataGridViewTextBoxColumn();
            costColumn.HeaderText = "Total Cost";
            costColumn.Name = "TotalCost";
            costColumn.DataPropertyName = "TotalCost";
            costColumn.DefaultCellStyle.Format = "N2"; // Numeric format with 2 decimal places
            costColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Right-align text
            dataGridView2.Columns.Add(costColumn);

            // Add delete button to the grid
            DataGridViewButtonColumn bcol = new DataGridViewButtonColumn();
            bcol.HeaderText = "Delete";
            bcol.Text = "Delete";
            bcol.Name = "Delete";
            bcol.UseColumnTextForButtonValue = true;
            bcol.DataPropertyName = "lnkColumn";
            dataGridView2.Columns.Add(bcol);

            // Add edit button to the grid
            DataGridViewButtonColumn MD = new DataGridViewButtonColumn();
            MD.HeaderText = "Edit";
            MD.Text = "Edit";
            MD.DataPropertyName = "lnkColumn";
            MD.Name = "Edit";
            MD.UseColumnTextForButtonValue = true;
            dataGridView2.Columns.Add(MD);

            // Adjust column sizes to fit the grid content
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }


        /// <summary>
        /// Database connection variable - replaced using the DatabaseConnection class
        /// </summary>
        // Using DatabaseConnection class instead of defining connection string here

        /// <summary>
        /// Load client data into the grid with filtering options
        /// </summary>
        /// <param name="nameLastName">Name or surname for filtering (optional)</param>
        /// <param name="codeClient">Client code for filtering (optional)</param>
        /// <param name="dateOfBirth">Date of birth for filtering (optional)</param>
        /// <param name="sexe">Gender for filtering (optional)</param>
        private void BindGrid(string nameLastName = null, string codeClient = null, DateTime? dateOfBirth = null, string sexe = null)
        {
            // Modify the query to add total costs for each client
            string baseQuery = @"SELECT c.*,
                               ISNULL((SELECT SUM(Cout) FROM Interventions WHERE CodeClient = c.CodeClient), 0) AS TotalCost
                               FROM Client c";

            // Build WHERE clause for the query
            string whereClause = "";
            bool firstCondition = true;

            // Add name or surname search condition
            if (!string.IsNullOrEmpty(nameLastName))
            {
                whereClause += (firstCondition ? " WHERE " : " AND ") + "(c.Name LIKE @nameLastName OR c.LastName LIKE @nameLastName)";
                firstCondition = false;
            }

            // Add client code search condition
            if (!string.IsNullOrEmpty(codeClient))
            {
                whereClause += (firstCondition ? " WHERE " : " AND ") + "c.CodeClient LIKE @codeClient";
                firstCondition = false;
            }

            // Add date of birth search condition
            if (dateOfBirth.HasValue)
            {
                whereClause += (firstCondition ? " WHERE " : " AND ") + "c.DateOfBirth = @dateOfBirth";
                firstCondition = false;
            }

            // Add gender search condition
            if (!string.IsNullOrEmpty(sexe))
            {
                whereClause += (firstCondition ? " WHERE " : " AND ") + "c.Sexe = @sexe";
                firstCondition = false;
            }

            // Combine base query with search conditions
            string finalQuery = baseQuery + whereClause;

            // Create parameters array for the query
            var parameters = new System.Collections.Generic.List<SqlParameter>();

            // Add name or surname search parameter
            if (!string.IsNullOrEmpty(nameLastName))
            {
                parameters.Add(new SqlParameter("@nameLastName", SqlDbType.VarChar) { Value = "%" + nameLastName + "%" });
            }

            // Add client code search parameter
            if (!string.IsNullOrEmpty(codeClient))
            {
                parameters.Add(new SqlParameter("@codeClient", SqlDbType.VarChar) { Value = "%" + codeClient + "%" });
            }

            // Add date of birth search parameter
            if (dateOfBirth.HasValue)
            {
                parameters.Add(new SqlParameter("@dateOfBirth", SqlDbType.DateTime) { Value = dateOfBirth.Value });
            }

            // Add gender search parameter
            if (!string.IsNullOrEmpty(sexe))
            {
                parameters.Add(new SqlParameter("@sexe", SqlDbType.VarChar) { Value = sexe });
            }

            // Use DatabaseConnection class to execute the query
            DataTable dt = DatabaseConnection.ExecuteQuery(finalQuery, parameters.Count > 0 ? parameters.ToArray() : null);

            // Display result count and update grid data source
            totlaNumbre.Text = dt.Rows.Count.ToString();
            dataGridView2.DataSource = dt;

            // Change column headers to English
            if (dataGridView2.Columns.Contains("CodeClient"))
                dataGridView2.Columns["CodeClient"].HeaderText = "Client ID";

            if (dataGridView2.Columns.Contains("Name"))
                dataGridView2.Columns["Name"].HeaderText = "First Name";

            if (dataGridView2.Columns.Contains("LastName"))
                dataGridView2.Columns["LastName"].HeaderText = "Last Name";

            if (dataGridView2.Columns.Contains("DateOfBirth"))
                dataGridView2.Columns["DateOfBirth"].HeaderText = "Date of Birth";

            if (dataGridView2.Columns.Contains("Sexe"))
                dataGridView2.Columns["Sexe"].HeaderText = "Gender";

            if (dataGridView2.Columns.Contains("Adresse"))
                dataGridView2.Columns["Adresse"].HeaderText = "Address";

            if (dataGridView2.Columns.Contains("Profession"))
                dataGridView2.Columns["Profession"].HeaderText = "Profession";

            if (dataGridView2.Columns.Contains("TelNumber"))
                dataGridView2.Columns["TelNumber"].HeaderText = "Phone";

            if (dataGridView2.Columns.Contains("Email"))
                dataGridView2.Columns["Email"].HeaderText = "Email";

            if (dataGridView2.Columns.Contains("Allergies"))
                dataGridView2.Columns["Allergies"].HeaderText = "Allergies";

            if (dataGridView2.Columns.Contains("CreatedAt"))
                dataGridView2.Columns["CreatedAt"].HeaderText = "Created At";

            if (dataGridView2.Columns.Contains("Status"))
                dataGridView2.Columns["Status"].HeaderText = "Status";
        }





        /// <summary>
        /// Delete a client from the database
        /// </summary>
        /// <param name="ID">ID of the client to delete</param>
        private void Delete_Click(string ID)
        {
            // Display confirmation message before deletion
            DialogResult dr = MessageBox.Show("Are you sure you want to delete client " + ID + "?\nThis will also delete all appointments related to this client.",
                "Delete Client", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // If user confirmed deletion
            if (dr == DialogResult.Yes)
            {
                try
                {
                    // First, delete related appointments (RDV)
                    string deleteRdvQuery = "DELETE FROM RDV WHERE ClientID = @ClientID";
                    SqlParameter[] rdvParameters = new SqlParameter[]
                    {
                        new SqlParameter("@ClientID", SqlDbType.Int) { Value = int.Parse(ID) }
                    };

                    // Execute the RDV deletion query
                    DatabaseConnection.ExecuteNonQuery(deleteRdvQuery, rdvParameters);

                    // Check if there are related interventions
                    string checkInterventionsQuery = "SELECT COUNT(*) FROM Interventions WHERE CodeClient = @CodeClient";
                    SqlParameter[] checkParameters = new SqlParameter[]
                    {
                        new SqlParameter("@CodeClient", SqlDbType.Int) { Value = int.Parse(ID) }
                    };

                    object result = DatabaseConnection.ExecuteScalar(checkInterventionsQuery, checkParameters);
                    int interventionCount = Convert.ToInt32(result);

                    if (interventionCount > 0)
                    {
                        // Delete related interventions
                        string deleteInterventionsQuery = "DELETE FROM Interventions WHERE CodeClient = @CodeClient";
                        SqlParameter[] interventionParameters = new SqlParameter[]
                        {
                            new SqlParameter("@CodeClient", SqlDbType.Int) { Value = int.Parse(ID) }
                        };

                        DatabaseConnection.ExecuteNonQuery(deleteInterventionsQuery, interventionParameters);
                    }

                    // Now, delete the client
                    string deleteClientQuery = "DELETE FROM Client WHERE CodeClient = @CodeClient";
                    SqlParameter[] clientParameters = new SqlParameter[]
                    {
                        new SqlParameter("@CodeClient", SqlDbType.Int) { Value = int.Parse(ID) }
                    };

                    // Execute the client deletion query
                    int rowsAffected = DatabaseConnection.ExecuteNonQuery(deleteClientQuery, clientParameters);

                    // Check if client deletion was successful
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Client and all related records deleted successfully", "Delete Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        BindGrid(); // Update grid after deletion
                    }
                    else
                    {
                        MessageBox.Show("No client records were deleted", "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException ex)
                {
                    // Display error message if deletion fails
                    MessageBox.Show("Database error: " + ex.Message, "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Invalid client ID format", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }




        /// <summary>
        /// Event handler for the reload data button click
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            // Call BindGrid without parameters to display all clients
            BindGrid();
        }

        /// <summary>
        /// Event handler for text change in the name search field
        /// </summary>
        private void comments_TextChanged(object sender, EventArgs e)
        {
            // Filter data by name or surname
            BindGrid(nameLastName: nomprenom.Text);
        }

        /// <summary>
        /// Event handler for text change in the client code search field
        /// </summary>
        private void CodeClient_TextChanged(object sender, EventArgs e)
        {
            // Filter data by client code
            BindGrid(codeClient: CodeClient.Text);
        }

        /// <summary>
        /// Event handler for date change in the date picker
        /// </summary>
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Filter data by date of birth
            BindGrid(dateOfBirth: dateTimePicker1.Value);
        }

        /// <summary>
        /// Event handler for the "Male" radio button state change
        /// </summary>
        private void hommeRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (hommeRadio.Checked)
            {
                // Filter data to show only male clients
                BindGrid(sexe: "Male");
            }
            else
            {
                // Clear gender filter
                BindGrid(sexe: null);
            }
        }

        /// <summary>
        /// Event handler for the "Female" radio button state change
        /// </summary>
        private void radioFemme_CheckedChanged(object sender, EventArgs e)
        {
            if (radioFemme.Checked)
            {
                // Filter data to show only female clients
                BindGrid(sexe: "Female");
            }
            else
            {
                // Clear gender filter
                BindGrid(sexe: null);
            }
        }

        /// <summary>
        /// Event handler for the export data to Excel button click
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            // Copy grid data to clipboard
            copyAlltoClipboard();

            // Create a new Excel application
            Microsoft.Office.Interop.Excel.Application xlexcel;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            // Initialize Excel application and make it visible
            xlexcel = new Excel.Application();
            xlexcel.Visible = true;

            // Create a new workbook and worksheet
            xlWorkBook = xlexcel.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            // Select the first cell and paste data
            Excel.Range CR = (Excel.Range)xlWorkSheet.Cells[1, 1];
            CR.Select();
            xlWorkSheet.PasteSpecial(CR, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);
        }

        /// <summary>
        /// Copy all grid data to clipboard
        /// </summary>
        private void copyAlltoClipboard()
        {
            // Hide row headers before copying
            dataGridView2.RowHeadersVisible = false;

            // Select all cells
            dataGridView2.SelectAll();

            // Get clipboard content
            DataObject dataObj = dataGridView2.GetClipboardContent();

            // Copy data to clipboard if available
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }

        /// <summary>
        /// Event handler for cell click in the grid
        /// </summary>
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Make sure the click is not on the column header
            if (e.RowIndex >= 0)
            {
                try
                {
                    // Get client ID from the CodeClient column
                    string clientId = "";

                    // Find the CodeClient column index
                    int codeClientColumnIndex = -1;
                    for (int i = 0; i < dataGridView2.Columns.Count; i++)
                    {
                        if (dataGridView2.Columns[i].Name == "CodeClient")
                        {
                            codeClientColumnIndex = i;
                            break;
                        }
                    }

                    // If CodeClient column was found, get its value
                    if (codeClientColumnIndex != -1)
                    {
                        clientId = dataGridView2.Rows[e.RowIndex].Cells[codeClientColumnIndex].Value.ToString();
                    }
                    else
                    {
                        // Fallback to the first column (which should be CodeClient)
                        clientId = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
                    }

                    // If the Edit button was clicked
                    if (dataGridView2.Columns[e.ColumnIndex].HeaderText == "Edit")
                    {
                        // Open new client form in edit mode
                        SimpleClientForm clientForm = new SimpleClientForm();

                        // Set edit variables
                        EditorAttribute = true;
                        iduser = clientId;

                        // Show the form
                        clientForm.Show();
                    }

                    // If the Delete button was clicked
                    if (dataGridView2.Columns[e.ColumnIndex].HeaderText == "Delete")
                    {
                        // Call the delete client function
                        Delete_Click(clientId);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error accessing client data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Event handler for clicking on the results count
        /// </summary>
        private void totlaNumbre_Click(object sender, EventArgs e)
        {
            // No specific action
        }

        /// <summary>
        /// تصدير بيانات العملاء إلى PDF
        /// </summary>
        private void exportPdfButton_Click(object sender, EventArgs e)
        {
            try
            {
                // التحقق من وجود بيانات للتصدير
                if (dataGridView2.Rows.Count == 0)
                {
                    MessageBox.Show("لا توجد بيانات للتصدير.", "خطأ في التصدير", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // تغيير مؤشر الماوس إلى علامة الانتظار
                Cursor.Current = Cursors.WaitCursor;

                try
                {
                    // تصدير البيانات مباشرة إلى PDF
                    string pdfPath = DirectPdfExporter.ExportDataGridViewToPdf(
                        dataGridView2,
                        "قائمة العملاء",
                        DateTime.Now.ToString("yyyyMMdd"),
                        WordExporter.TAB_CLIENTS);

                    // لا حاجة لعرض رسالة نجاح هنا لأنها تُعرض في الدالة ExportDataGridViewToPdf
                }
                finally
                {
                    // التأكد من استعادة مؤشر الماوس
                    Cursor.Current = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير البيانات إلى PDF: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
