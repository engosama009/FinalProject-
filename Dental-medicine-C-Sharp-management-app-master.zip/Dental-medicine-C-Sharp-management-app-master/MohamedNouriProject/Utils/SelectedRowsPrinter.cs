using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace MohamedNouriProject.Utils
{
    /// <summary>
    /// Clase utilitaria para imprimir solo las filas seleccionadas de un DataGridView
    /// </summary>
    public static class SelectedRowsPrinter
    {
        // Ruta para guardar archivos temporales
        private static readonly string TempFolderPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "DentalClinic", "Temp");

        /// <summary>
        /// Imprime solo las filas seleccionadas de un DataGridView
        /// </summary>
        /// <param name="dataGridView">El DataGridView que contiene las filas seleccionadas</param>
        /// <param name="title">Título del documento (opcional)</param>
        /// <returns>True si la impresión fue exitosa, False en caso contrario</returns>
        public static bool PrintSelectedRows(DataGridView dataGridView, string title = "Selected Data")
        {
            try
            {
                // Verificar si hay filas seleccionadas
                if (dataGridView.SelectedRows.Count == 0 && dataGridView.SelectedCells.Count == 0)
                {
                    MessageBox.Show("Por favor, seleccione al menos una fila para imprimir.", 
                        "No hay selección", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }

                // Crear directorio temporal si no existe
                if (!Directory.Exists(TempFolderPath))
                {
                    Directory.CreateDirectory(TempFolderPath);
                }

                // Usar Excel para la impresión
                return PrintViaExcel(dataGridView, title);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir las filas seleccionadas: " + ex.Message,
                    "Error de impresión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Imprime las filas seleccionadas usando Excel como intermediario
        /// </summary>
        private static bool PrintViaExcel(DataGridView dataGridView, string title)
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkbook = null;
            Excel.Worksheet xlWorksheet = null;

            try
            {
                // Inicializar Excel
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;

                // Crear nuevo libro y hoja
                xlWorkbook = xlApp.Workbooks.Add(Type.Missing);
                xlWorksheet = (Excel.Worksheet)xlWorkbook.Worksheets.get_Item(1);

                // Agregar título
                xlWorksheet.Cells[1, 1] = title;
                Excel.Range titleRange = xlWorksheet.Range["A1", "G1"];
                titleRange.Merge();
                titleRange.Font.Bold = true;
                titleRange.Font.Size = 14;
                titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                // Agregar fecha
                xlWorksheet.Cells[2, 1] = "Fecha: " + DateTime.Now.ToString("dd/MM/yyyy");
                Excel.Range dateRange = xlWorksheet.Range["A2", "G2"];
                dateRange.Merge();
                dateRange.Font.Bold = true;
                dateRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                // Agregar encabezados de columnas (fila 4)
                int colIndex = 1;
                List<int> visibleColumnIndices = new List<int>();

                // Determinar columnas visibles y su orden
                for (int i = 0; i < dataGridView.Columns.Count; i++)
                {
                    if (dataGridView.Columns[i] is DataGridViewButtonColumn || !dataGridView.Columns[i].Visible)
                        continue; // Omitir columnas de botones y columnas no visibles

                    visibleColumnIndices.Add(i);
                    xlWorksheet.Cells[4, colIndex] = dataGridView.Columns[i].HeaderText;
                    
                    // Dar formato a los encabezados
                    Excel.Range headerCell = xlWorksheet.Cells[4, colIndex];
                    headerCell.Font.Bold = true;
                    headerCell.Interior.Color = ColorTranslator.ToOle(Color.LightGray);
                    headerCell.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    headerCell.Borders.Weight = Excel.XlBorderWeight.xlThin;
                    headerCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                    
                    colIndex++;
                }

                // Obtener filas seleccionadas
                List<DataGridViewRow> selectedRows = new List<DataGridViewRow>();
                
                // Si hay filas completas seleccionadas
                if (dataGridView.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow row in dataGridView.SelectedRows)
                    {
                        selectedRows.Add(row);
                    }
                }
                // Si hay celdas seleccionadas pero no filas completas
                else if (dataGridView.SelectedCells.Count > 0)
                {
                    // Obtener filas únicas de las celdas seleccionadas
                    HashSet<int> uniqueRowIndices = new HashSet<int>();
                    foreach (DataGridViewCell cell in dataGridView.SelectedCells)
                    {
                        uniqueRowIndices.Add(cell.RowIndex);
                    }
                    
                    // Agregar las filas únicas a la lista
                    foreach (int rowIndex in uniqueRowIndices)
                    {
                        selectedRows.Add(dataGridView.Rows[rowIndex]);
                    }
                }

                // Agregar datos de las filas seleccionadas
                int rowIndex = 5; // Comenzar en la fila 5 (después de los encabezados)
                foreach (DataGridViewRow row in selectedRows)
                {
                    colIndex = 1;
                    foreach (int originalColIndex in visibleColumnIndices)
                    {
                        if (row.Cells[originalColIndex].Value != null)
                        {
                            object cellValue = row.Cells[originalColIndex].Value;
                            
                            // Manejar tipos de datos específicos
                            if (cellValue is DateTime)
                            {
                                xlWorksheet.Cells[rowIndex, colIndex] = ((DateTime)cellValue).ToString("dd/MM/yyyy");
                            }
                            else
                            {
                                xlWorksheet.Cells[rowIndex, colIndex] = cellValue.ToString();
                            }
                            
                            // Dar formato a las celdas de datos
                            Excel.Range dataCell = xlWorksheet.Cells[rowIndex, colIndex];
                            dataCell.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                            dataCell.Borders.Weight = Excel.XlBorderWeight.xlThin;
                        }
                        
                        colIndex++;
                    }
                    
                    rowIndex++;
                }

                // Ajustar ancho de columnas
                xlWorksheet.Columns.AutoFit();

                // Imprimir
                xlWorksheet.PrintOut();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al preparar la impresión: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                // Liberar recursos
                if (xlWorksheet != null)
                {
                    ReleaseComObject(xlWorksheet);
                }
                
                if (xlWorkbook != null)
                {
                    xlWorkbook.Close(false);
                    ReleaseComObject(xlWorkbook);
                }
                
                if (xlApp != null)
                {
                    xlApp.Quit();
                    ReleaseComObject(xlApp);
                }
                
                // Forzar recolección de basura
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        /// <summary>
        /// Libera objetos COM de manera segura
        /// </summary>
        private static void ReleaseComObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception ex)
            {
                obj = null;
                System.Diagnostics.Debug.WriteLine("Error al liberar objeto COM: " + ex.Message);
            }
        }
    }
}
