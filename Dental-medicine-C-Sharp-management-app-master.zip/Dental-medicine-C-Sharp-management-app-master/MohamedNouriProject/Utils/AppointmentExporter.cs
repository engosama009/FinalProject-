using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace MohamedNouriProject.Utils
{
    /// <summary>
    /// Clase para exportar citas a PDF
    /// </summary>
    public class AppointmentExporter
    {
        // Ruta de la plantilla de citas
        private static string TemplateFolder = Path.Combine(Application.StartupPath, "Templates");
        private static string AppointmentTemplatePath = Path.Combine(TemplateFolder, "AppointmentTemplate.docx");

        /// <summary>
        /// Exporta una cita a PDF
        /// </summary>
        /// <param name="clientName">Nombre del cliente</param>
        /// <param name="appointmentId">ID de la cita</param>
        /// <param name="appointmentDate">Fecha de la cita</param>
        /// <param name="appointmentTime">Hora de la cita</param>
        /// <param name="comments">Comentarios</param>
        /// <param name="tabName">Nombre de la pestaña actual</param>
        /// <returns>Ruta del archivo PDF generado</returns>
        public static string ExportAppointment(string clientName, string appointmentId, DateTime appointmentDate, 
            string appointmentTime, string comments, string tabName = WordExporter.TAB_APPOINTMENTS)
        {
            try
            {
                // Si no existe la plantilla de citas, usar la plantilla de facturas
                string templatePath = File.Exists(AppointmentTemplatePath) ? 
                    AppointmentTemplatePath : InvoiceExporter.GetInvoiceTemplatePath();

                // Verificar que la plantilla existe
                if (!File.Exists(templatePath))
                {
                    // Crear el directorio de plantillas si no existe
                    if (!Directory.Exists(TemplateFolder))
                    {
                        Directory.CreateDirectory(TemplateFolder);
                    }

                    MessageBox.Show("لم يتم العثور على ملف قالب المواعيد. يرجى وضع ملف 'AppointmentTemplate.docx' أو 'InvoiceTemplate.docx' في مجلد 'Templates'.", 
                        "ملف القالب غير موجود", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return null;
                }

                // Crear diccionario de marcadores
                Dictionary<string, string> bookmarks = new Dictionary<string, string>
                {
                    { "ClientName", clientName },
                    { "AppointmentId", appointmentId },
                    { "AppointmentDate", appointmentDate.ToString("dd/MM/yyyy") },
                    { "AppointmentTime", appointmentTime },
                    { "Comments", comments }
                };

                // Agregar marcadores compatibles con la plantilla de facturas
                bookmarks["InvoiceNumber"] = appointmentId;
                bookmarks["InvoiceDate"] = appointmentDate.ToString("dd/MM/yyyy");
                bookmarks["TotalAmount"] = "";

                // Exportar a PDF
                string pdfPath = WordExporter.ExportToPdf(templatePath, bookmarks, tabName, appointmentId);

                // Mostrar mensaje de éxito
                if (!string.IsNullOrEmpty(pdfPath))
                {
                    DialogResult result = MessageBox.Show(
                        "تم إنشاء ملف PDF بنجاح. هل تريد فتح الملف؟", 
                        "تم بنجاح", 
                        MessageBoxButtons.YesNo, 
                        MessageBoxIcon.Information);

                    if (result == DialogResult.Yes)
                    {
                        WordExporter.OpenPdf(pdfPath);
                    }
                }

                return pdfPath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير الموعد: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        /// <summary>
        /// Exporta una cita a PDF basada en un ID de cita
        /// </summary>
        /// <param name="appointmentId">ID de la cita</param>
        /// <param name="tabName">Nombre de la pestaña actual</param>
        /// <returns>Ruta del archivo PDF generado</returns>
        public static string ExportAppointmentById(string appointmentId, string tabName = WordExporter.TAB_APPOINTMENTS)
        {
            try
            {
                // Obtener datos de la cita
                string query = @"SELECT 
                                    RDV.CodeRDV,
                                    RDV.DateRDV,
                                    RDV.Time,
                                    RDV.Comments,
                                    Client.Name + ' ' + Client.LastName AS ClientName
                                FROM 
                                    RDV 
                                INNER JOIN 
                                    Client ON RDV.ClientID = Client.CodeClient
                                WHERE 
                                    RDV.CodeRDV = @AppointmentId";

                System.Data.SqlClient.SqlParameter[] parameters = new System.Data.SqlClient.SqlParameter[]
                {
                    new System.Data.SqlClient.SqlParameter("@AppointmentId", System.Data.SqlDbType.VarChar) { Value = appointmentId }
                };

                DataTable appointmentData = db.DatabaseConnection.ExecuteQuery(query, parameters);

                if (appointmentData.Rows.Count == 0)
                {
                    MessageBox.Show("لم يتم العثور على بيانات الموعد.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

                // Extraer datos
                string clientName = appointmentData.Rows[0]["ClientName"].ToString();
                DateTime appointmentDate = Convert.ToDateTime(appointmentData.Rows[0]["DateRDV"]);
                string appointmentTime = appointmentData.Rows[0]["Time"].ToString();
                string comments = appointmentData.Rows[0]["Comments"].ToString();

                // Exportar cita
                return ExportAppointment(clientName, appointmentId, appointmentDate, appointmentTime, comments, tabName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير الموعد: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}
