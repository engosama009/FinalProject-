using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;
using System.Reflection;

namespace MohamedNouriProject.Utils
{
    /// <summary>
    /// Clase utilitaria para exportar documentos Word a PDF
    /// </summary>
    public class WordExporter
    {
        // Constantes para los tipos de documentos
        public const string TAB_APPOINTMENTS = "مواعيد";
        public const string TAB_INVOICES = "فواتير";
        public const string TAB_CLIENTS = "عملاء";
        public const string TAB_HISTORY = "سجل";

        // Ruta de la carpeta de exportación
        private static string ExportFolderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "DentiPlus\\Exports");

        /// <summary>
        /// Exporta datos a un documento Word y lo convierte a PDF
        /// </summary>
        /// <param name="templatePath">Ruta de la plantilla Word</param>
        /// <param name="bookmarks">Diccionario de marcadores y sus valores</param>
        /// <param name="tabName">Nombre de la pestaña actual</param>
        /// <param name="documentId">ID del documento (opcional)</param>
        /// <returns>Ruta del archivo PDF generado</returns>
        public static string ExportToPdf(string templatePath, System.Collections.Generic.Dictionary<string, string> bookmarks, string tabName, string documentId = "")
        {
            // Verificar que la plantilla existe
            if (!File.Exists(templatePath))
            {
                MessageBox.Show("لم يتم العثور على ملف القالب: " + templatePath, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            // Crear la carpeta de exportación si no existe
            if (!Directory.Exists(ExportFolderPath))
            {
                Directory.CreateDirectory(ExportFolderPath);
            }

            // Generar nombre de archivo basado en la pestaña actual
            string fileName = GenerateFileName(tabName, documentId);
            string wordFilePath = Path.Combine(ExportFolderPath, fileName + ".docx");
            string pdfFilePath = Path.Combine(ExportFolderPath, fileName + ".pdf");

            // Variables para los objetos de Word
            Microsoft.Office.Interop.Word.Application wordApp = null;
            Microsoft.Office.Interop.Word.Document wordDoc = null;

            try
            {
                // Inicializar la aplicación Word
                wordApp = new Microsoft.Office.Interop.Word.Application();
                wordApp.Visible = false;

                // Abrir la plantilla
                wordDoc = wordApp.Documents.Open(templatePath);

                // Reemplazar los marcadores con los valores correspondientes
                foreach (var bookmark in bookmarks)
                {
                    if (wordDoc.Bookmarks.Exists(bookmark.Key))
                    {
                        wordDoc.Bookmarks[bookmark.Key].Range.Text = bookmark.Value;
                    }
                }

                // Guardar como documento Word
                wordDoc.SaveAs2(wordFilePath);

                // Exportar a PDF
                wordDoc.ExportAsFixedFormat(pdfFilePath, WdExportFormat.wdExportFormatPDF);

                // Cerrar el documento
                wordDoc.Close(false);

                return pdfFilePath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء إنشاء ملف PDF: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            finally
            {
                // Liberar recursos de manera más segura
                if (wordDoc != null)
                {
                    try
                    {
                        // Asegurarse de que el documento esté cerrado
                        if (wordDoc.Windows.Count > 0)
                        {
                            wordDoc.Close(false);
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine("Error al cerrar documento Word: " + ex.Message);
                    }

                    try
                    {
                        ReleaseComObject(wordDoc);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine("Error al liberar documento Word: " + ex.Message);
                    }

                    wordDoc = null;
                }

                if (wordApp != null)
                {
                    try
                    {
                        // Asegurarse de que la aplicación se cierre
                        wordApp.Quit(false);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine("Error al cerrar aplicación Word: " + ex.Message);
                    }

                    try
                    {
                        ReleaseComObject(wordApp);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine("Error al liberar aplicación Word: " + ex.Message);
                    }

                    wordApp = null;
                }

                // Forzar la recolección de basura dos veces para asegurar la liberación de recursos COM
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        /// <summary>
        /// Genera un nombre de archivo basado en la pestaña actual y el ID del documento
        /// </summary>
        /// <param name="tabName">Nombre de la pestaña</param>
        /// <param name="documentId">ID del documento (opcional)</param>
        /// <returns>Nombre del archivo</returns>
        private static string GenerateFileName(string tabName, string documentId)
        {
            string dateStr = DateTime.Now.ToString("yyyy-MM-dd");

            switch (tabName)
            {
                case TAB_APPOINTMENTS:
                    return $"{TAB_APPOINTMENTS}_{dateStr}";

                case TAB_INVOICES:
                    if (!string.IsNullOrEmpty(documentId))
                        return $"{TAB_INVOICES}_رقم{documentId}_{dateStr}";
                    return $"{TAB_INVOICES}_{dateStr}";

                case TAB_CLIENTS:
                    if (!string.IsNullOrEmpty(documentId))
                        return $"{TAB_CLIENTS}_{documentId}_{dateStr}";
                    return $"{TAB_CLIENTS}_{dateStr}";

                case TAB_HISTORY:
                    return $"{TAB_HISTORY}_{dateStr}";

                default:
                    return $"DentiPlus_{dateStr}";
            }
        }

        /// <summary>
        /// Libera un objeto COM de manera segura
        /// </summary>
        /// <param name="obj">Objeto COM a liberar</param>
        private static void ReleaseComObject(object obj)
        {
            try
            {
                if (obj != null && System.Runtime.InteropServices.Marshal.IsComObject(obj))
                {
                    // Liberar todas las referencias al objeto COM
                    int refCount;
                    do
                    {
                        refCount = System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                    }
                    while (refCount > 0);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error al liberar objeto COM: " + ex.Message);
            }
            finally
            {
                obj = null;
            }
        }

        /// <summary>
        /// Abre un archivo PDF con la aplicación predeterminada
        /// </summary>
        /// <param name="pdfPath">Ruta del archivo PDF</param>
        public static void OpenPdf(string pdfPath)
        {
            if (string.IsNullOrEmpty(pdfPath))
            {
                MessageBox.Show("La ruta del archivo PDF es inválida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (File.Exists(pdfPath))
            {
                try
                {
                    // Usar ProcessStartInfo para más control
                    System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = pdfPath,
                        UseShellExecute = true
                    };

                    System.Diagnostics.Process.Start(psi);
                }
                catch (System.ComponentModel.Win32Exception ex)
                {
                    // Error específico cuando no hay aplicación asociada
                    MessageBox.Show("No se encontró una aplicación para abrir archivos PDF. " + ex.Message,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al abrir el archivo PDF: " + ex.Message,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No se encontró el archivo PDF: " + pdfPath,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
