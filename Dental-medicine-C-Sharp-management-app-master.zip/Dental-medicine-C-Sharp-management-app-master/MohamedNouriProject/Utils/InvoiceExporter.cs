using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace MohamedNouriProject.Utils
{
    /// <summary>
    /// Clase para exportar facturas a PDF
    /// </summary>
    public class InvoiceExporter
    {
        // Ruta de la plantilla de factura
        private static string TemplateFolder = Path.Combine(Application.StartupPath, "Templates");
        private static string InvoiceTemplatePath = Path.Combine(TemplateFolder, "InvoiceTemplate.docx");

        /// <summary>
        /// Obtiene la ruta de la plantilla de facturas
        /// </summary>
        /// <returns>Ruta de la plantilla de facturas</returns>
        public static string GetInvoiceTemplatePath()
        {
            return InvoiceTemplatePath;
        }

        /// <summary>
        /// Obtiene la ruta de la carpeta de plantillas
        /// </summary>
        /// <returns>Ruta de la carpeta de plantillas</returns>
        public static string GetTemplateFolder()
        {
            return TemplateFolder;
        }

        /// <summary>
        /// Exporta una factura a PDF
        /// </summary>
        /// <param name="clientName">Nombre del cliente</param>
        /// <param name="invoiceNumber">Número de factura</param>
        /// <param name="invoiceDate">Fecha de factura</param>
        /// <param name="totalAmount">Monto total</param>
        /// <param name="items">Elementos de la factura (opcional)</param>
        /// <param name="tabName">Nombre de la pestaña actual</param>
        /// <returns>Ruta del archivo PDF generado</returns>
        public static string ExportInvoice(string clientName, string invoiceNumber, DateTime invoiceDate,
            decimal totalAmount, DataTable items = null, string tabName = WordExporter.TAB_INVOICES)
        {
            try
            {
                // Verificar que la plantilla existe
                if (!File.Exists(InvoiceTemplatePath))
                {
                    // Crear el directorio de plantillas si no existe
                    if (!Directory.Exists(TemplateFolder))
                    {
                        Directory.CreateDirectory(TemplateFolder);
                    }

                    MessageBox.Show("لم يتم العثور على ملف قالب الفاتورة. يرجى وضع ملف 'InvoiceTemplate.docx' في مجلد 'Templates'.",
                        "ملف القالب غير موجود", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return null;
                }

                // Crear diccionario de marcadores
                Dictionary<string, string> bookmarks = new Dictionary<string, string>
                {
                    { "ClientName", clientName },
                    { "InvoiceNumber", invoiceNumber },
                    { "InvoiceDate", invoiceDate.ToString("dd/MM/yyyy") },
                    { "TotalAmount", totalAmount.ToString("N2") + " $" }
                };

                // Exportar a PDF
                string pdfPath = WordExporter.ExportToPdf(InvoiceTemplatePath, bookmarks, tabName, invoiceNumber);

                // Mostrar mensaje de éxito
                if (!string.IsNullOrEmpty(pdfPath))
                {
                    DialogResult result = MessageBox.Show(
                        "تم إنشاء ملف PDF بنجاح. هل تريد فتح الملف؟",
                        "تم بنجاح",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                    if (result == DialogResult.Yes)
                    {
                        WordExporter.OpenPdf(pdfPath);
                    }
                }

                return pdfPath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير الفاتورة: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        /// <summary>
        /// Exporta una factura a PDF basada en un ID de cliente
        /// </summary>
        /// <param name="clientId">ID del cliente</param>
        /// <param name="tabName">Nombre de la pestaña actual</param>
        /// <returns>Ruta del archivo PDF generado</returns>
        public static string ExportInvoiceByClientId(string clientId, string tabName = WordExporter.TAB_INVOICES)
        {
            try
            {
                // Obtener datos del cliente
                string query = @"SELECT
                                    Client.Name + ' ' + Client.LastName AS ClientName,
                                    Client.CodeClient AS ClientId,
                                    ISNULL((SELECT SUM(Cout) FROM Interventions WHERE CodeClient = Client.CodeClient), 0) AS TotalAmount
                                FROM
                                    Client
                                WHERE
                                    Client.CodeClient = @ClientId";

                System.Data.SqlClient.SqlParameter[] parameters = new System.Data.SqlClient.SqlParameter[]
                {
                    new System.Data.SqlClient.SqlParameter("@ClientId", System.Data.SqlDbType.VarChar) { Value = clientId }
                };

                DataTable clientData = db.DatabaseConnection.ExecuteQuery(query, parameters);

                if (clientData.Rows.Count == 0)
                {
                    MessageBox.Show("لم يتم العثور على بيانات العميل.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

                // Extraer datos
                string clientName = clientData.Rows[0]["ClientName"].ToString();
                string invoiceNumber = clientId;
                decimal totalAmount = Convert.ToDecimal(clientData.Rows[0]["TotalAmount"]);

                // Exportar factura
                return ExportInvoice(clientName, invoiceNumber, DateTime.Now, totalAmount, null, tabName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير الفاتورة: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}
