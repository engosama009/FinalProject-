using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;
using System.Collections.Generic;
using System.Text;
using Microsoft.Office.Interop.Excel;

namespace MohamedNouriProject.Utils
{
    /// <summary>
    /// يقوم بتصدير البيانات مباشرة إلى Excel ثم تحويلها إلى PDF
    /// </summary>
    public class DirectPdfExporter
    {
        // مسار مجلد التصدير
        private static string ExportFolderPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "DentiPlus\\Exports");

        /// <summary>
        /// تصدير بيانات DataGridView إلى ملف PDF عبر Excel
        /// </summary>
        /// <param name="dataGridView">جدول البيانات المراد تصديره</param>
        /// <param name="title">عنوان المستند</param>
        /// <param name="documentId">معرف المستند (اختياري)</param>
        /// <param name="tabName">اسم التبويب الحالي</param>
        /// <returns>مسار ملف PDF المنشأ</returns>
        public static string ExportDataGridViewToPdf(DataGridView dataGridView, string title,
            string documentId = "", string tabName = "")
        {
            // إنشاء مجلد التصدير إذا لم يكن موجوداً
            if (!Directory.Exists(ExportFolderPath))
            {
                Directory.CreateDirectory(ExportFolderPath);
            }

            // إنشاء اسم الملف بناءً على التبويب الحالي
            string fileName = GenerateFileName(tabName, documentId);
            string excelFilePath = Path.Combine(ExportFolderPath, fileName + ".xlsx");
            string pdfFilePath = Path.Combine(ExportFolderPath, fileName + ".pdf");

            // متغيرات لتطبيق Excel
            Microsoft.Office.Interop.Excel.Application xlApp = null;
            Microsoft.Office.Interop.Excel.Workbook xlWorkbook = null;
            Microsoft.Office.Interop.Excel.Worksheet xlWorksheet = null;

            try
            {
                // إنشاء تطبيق Excel
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlApp.DisplayAlerts = false; // تعطيل التنبيهات
                xlApp.Visible = false; // جعل التطبيق غير مرئي

                // إنشاء مصنف وورقة عمل جديدة
                xlWorkbook = xlApp.Workbooks.Add(Type.Missing);
                xlWorksheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkbook.Worksheets.get_Item(1);

                // إضافة رؤوس الأعمدة (بدءاً من الصف 4)
                int colIndex = 1;
                List<int> visibleColumnIndices = new List<int>();

                // أولاً، تحديد الأعمدة المرئية وترتيبها
                for (int i = 0; i < dataGridView.Columns.Count; i++)
                {
                    if (dataGridView.Columns[i] is DataGridViewButtonColumn || !dataGridView.Columns[i].Visible)
                        continue; // تخطي أعمدة الأزرار والأعمدة غير المرئية

                    visibleColumnIndices.Add(i);
                }

                // تحديد عدد الأعمدة للعنوان
                int columnCount = Math.Max(8, visibleColumnIndices.Count);
                string lastColumn = GetExcelColumnName(columnCount);

                // إضافة العنوان بتنسيق محسّن
                Microsoft.Office.Interop.Excel.Range titleRange = xlWorksheet.Range["A1:" + lastColumn + "1"];
                titleRange.Merge();
                titleRange.Value = title;
                titleRange.Font.Size = 18;
                titleRange.Font.Bold = true;
                titleRange.Font.Name = "Arial";
                titleRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                titleRange.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                titleRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(0, 112, 192)); // لون أزرق أكثر جاذبية
                titleRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                titleRange.RowHeight = 30; // ارتفاع أكبر للعنوان

                // إضافة حدود للعنوان
                titleRange.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                titleRange.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                // إضافة التاريخ بتنسيق محسّن
                xlWorksheet.Cells[2, 1] = "تاريخ التصدير: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm");
                Microsoft.Office.Interop.Excel.Range dateRange = xlWorksheet.Range["A2:" + lastColumn + "2"];
                dateRange.Merge();
                dateRange.Font.Size = 10;
                dateRange.Font.Bold = true;
                dateRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                dateRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                dateRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 230, 241)); // لون خلفية فاتح

                // إضافة رؤوس الأعمدة مع تنسيق محسّن
                foreach (int i in visibleColumnIndices)
                {
                    xlWorksheet.Cells[4, colIndex] = dataGridView.Columns[i].HeaderText;

                    // تنسيق رؤوس الأعمدة
                    Microsoft.Office.Interop.Excel.Range headerCell = xlWorksheet.Cells[4, colIndex];
                    headerCell.Font.Bold = true;
                    headerCell.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.MidnightBlue);
                    headerCell.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    headerCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    headerCell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                    colIndex++;
                }

                // إضافة بيانات الصفوف (بدءاً من الصف 5) مع تنسيق محسّن
                decimal totalCost = 0;
                bool hasCostColumn = false;
                int costColumnIndex = -1;

                // البحث عن عمود التكلفة إن وجد
                for (int i = 0; i < visibleColumnIndices.Count; i++)
                {
                    string headerText = dataGridView.Columns[visibleColumnIndices[i]].HeaderText.ToLower();
                    if (headerText.Contains("cost") || headerText.Contains("cout") ||
                        headerText.Contains("price") || headerText.Contains("تكلفة") ||
                        headerText.Contains("سعر") || headerText.Contains("ثمن"))
                    {
                        hasCostColumn = true;
                        costColumnIndex = i;
                        break;
                    }
                }

                // إضافة بيانات الصفوف مع تنسيق محسّن
                for (int i = 0; i < dataGridView.Rows.Count; i++)
                {
                    colIndex = 1;

                    // تطبيق تنسيق متناوب للصفوف
                    Microsoft.Office.Interop.Excel.Range rowRange = xlWorksheet.Range[
                        xlWorksheet.Cells[i + 5, 1],
                        xlWorksheet.Cells[i + 5, visibleColumnIndices.Count]];

                    if (i % 2 == 0)
                    {
                        rowRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(240, 240, 240));
                    }

                    // إضافة بيانات الخلايا
                    for (int j = 0; j < visibleColumnIndices.Count; j++)
                    {
                        int originalColumnIndex = visibleColumnIndices[j];
                        if (dataGridView.Rows[i].Cells[originalColumnIndex].Value != null)
                        {
                            // تحويل القيم إلى الأنواع المناسبة لـ Excel
                            object cellValue = dataGridView.Rows[i].Cells[originalColumnIndex].Value;

                            // معالجة خاصة للتواريخ
                            if (cellValue is DateTime)
                            {
                                xlWorksheet.Cells[i + 5, j + 1] = ((DateTime)cellValue).ToString("dd/MM/yyyy");
                            }
                            // معالجة خاصة للأرقام والتكاليف
                            else if (hasCostColumn && j == costColumnIndex)
                            {
                                decimal cost;
                                if (decimal.TryParse(cellValue.ToString().Replace("$", "").Replace("TND", "").Trim(), out cost))
                                {
                                    xlWorksheet.Cells[i + 5, j + 1] = cost.ToString("N2") + " $";
                                    totalCost += cost;

                                    // تنسيق خلية التكلفة
                                    Microsoft.Office.Interop.Excel.Range costCell = xlWorksheet.Cells[i + 5, j + 1];
                                    costCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                                    costCell.Font.Bold = true;
                                }
                                else
                                {
                                    xlWorksheet.Cells[i + 5, j + 1] = cellValue.ToString();
                                }
                            }
                            else
                            {
                                xlWorksheet.Cells[i + 5, j + 1] = cellValue.ToString();
                            }

                            // تنسيق الخلية
                            Microsoft.Office.Interop.Excel.Range cell = xlWorksheet.Cells[i + 5, j + 1];
                            cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                            // تنسيق خاص للأعمدة المختلفة
                            string columnHeader = dataGridView.Columns[originalColumnIndex].HeaderText.ToLower();
                            if (columnHeader.Contains("name") || columnHeader.Contains("nom") ||
                                columnHeader.Contains("اسم") || columnHeader.Contains("lastname") ||
                                columnHeader.Contains("الاسم"))
                            {
                                cell.Font.Bold = true;
                                cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            }
                            else if (columnHeader.Contains("gender") || columnHeader.Contains("sexe") ||
                                     columnHeader.Contains("جنس") || columnHeader.Contains("نوع"))
                            {
                                cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            }
                            else if (columnHeader.Contains("date") || columnHeader.Contains("تاريخ"))
                            {
                                cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            }
                            else if (columnHeader.Contains("id") || columnHeader.Contains("code") ||
                                     columnHeader.Contains("رمز") || columnHeader.Contains("رقم"))
                            {
                                cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            }
                            else
                            {
                                cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            }
                        }
                        colIndex++;
                    }
                }

                // إضافة إجمالي التكلفة إذا كان هناك عمود تكلفة
                int totalRow = dataGridView.Rows.Count + 5;
                if (hasCostColumn && dataGridView.Rows.Count > 0)
                {
                    // إضافة خط فاصل
                    Microsoft.Office.Interop.Excel.Range separatorRange = xlWorksheet.Range[
                        xlWorksheet.Cells[totalRow, 1],
                        xlWorksheet.Cells[totalRow, visibleColumnIndices.Count]];
                    separatorRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].LineStyle =
                        Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    separatorRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight =
                        Microsoft.Office.Interop.Excel.XlBorderWeight.xlMedium;

                    // إضافة صف الإجمالي
                    xlWorksheet.Cells[totalRow + 1, costColumnIndex + 1] = totalCost.ToString("N2") + " $";
                    xlWorksheet.Cells[totalRow + 1, costColumnIndex] = "الإجمالي:";

                    // تنسيق خلية الإجمالي
                    Microsoft.Office.Interop.Excel.Range totalCell = xlWorksheet.Cells[totalRow + 1, costColumnIndex + 1];
                    totalCell.Font.Bold = true;
                    totalCell.Font.Size = 12;
                    totalCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    Microsoft.Office.Interop.Excel.Range totalLabelCell = xlWorksheet.Cells[totalRow + 1, costColumnIndex];
                    totalLabelCell.Font.Bold = true;
                    totalLabelCell.Font.Size = 12;
                    totalLabelCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                }

                // تنسيق الجدول بالكامل
                int lastRow = dataGridView.Rows.Count + 4;
                int lastCol = visibleColumnIndices.Count;

                if (lastRow > 4 && lastCol > 0)
                {
                    Microsoft.Office.Interop.Excel.Range dataRange = xlWorksheet.Range[
                        xlWorksheet.Cells[4, 1],
                        xlWorksheet.Cells[lastRow, lastCol]];

                    // إضافة حدود للجدول
                    dataRange.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    dataRange.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                    // تنسيق تلقائي للأعمدة
                    dataRange.Columns.AutoFit();
                }

                // حفظ كملف Excel
                xlWorkbook.SaveAs(
                    excelFilePath,
                    Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook,
                    Type.Missing,
                    Type.Missing,
                    false,
                    false,
                    Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing
                );

                // تصدير إلى PDF
                xlWorksheet.ExportAsFixedFormat(
                    Microsoft.Office.Interop.Excel.XlFixedFormatType.xlTypePDF,
                    pdfFilePath,
                    Microsoft.Office.Interop.Excel.XlFixedFormatQuality.xlQualityStandard,
                    true,
                    false,
                    Type.Missing,
                    Type.Missing,
                    false,
                    Type.Missing
                );

                // إغلاق المصنف
                xlWorkbook.Close(false);

                // عرض رسالة نجاح
                DialogResult result = MessageBox.Show(
                    "تم إنشاء ملف PDF بنجاح. هل تريد فتح الملف؟",
                    "تم بنجاح",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);

                if (result == DialogResult.Yes)
                {
                    OpenPdf(pdfFilePath);
                }

                return pdfFilePath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء إنشاء ملف PDF: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            finally
            {
                // تحرير الموارد
                if (xlWorkbook != null)
                {
                    try
                    {
                        xlWorkbook.Close(false);
                    }
                    catch { }
                }

                if (xlApp != null)
                {
                    try
                    {
                        xlApp.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                    }
                    catch { }
                }

                // إجبار جامع القمامة على التنظيف
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        /// <summary>
        /// إنشاء اسم ملف بناءً على التبويب الحالي
        /// </summary>
        private static string GenerateFileName(string tabName, string documentId)
        {
            string prefix = string.IsNullOrEmpty(tabName) ? "Document" : tabName;
            string suffix = string.IsNullOrEmpty(documentId) ? DateTime.Now.ToString("yyyyMMdd_HHmmss") : documentId;
            return prefix + "_" + suffix;
        }

        /// <summary>
        /// فتح ملف PDF
        /// </summary>
        public static void OpenPdf(string pdfPath)
        {
            if (File.Exists(pdfPath))
            {
                try
                {
                    // استخدام ProcessStartInfo للتحكم بشكل أفضل
                    System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = pdfPath,
                        UseShellExecute = true
                    };

                    System.Diagnostics.Process.Start(psi);
                }
                catch (System.ComponentModel.Win32Exception ex)
                {
                    // خطأ محدد عندما لا يوجد تطبيق مرتبط
                    MessageBox.Show("لم يتم العثور على تطبيق لفتح ملفات PDF. " + ex.Message,
                        "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("حدث خطأ أثناء فتح ملف PDF: " + ex.Message,
                        "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("لم يتم العثور على ملف PDF: " + pdfPath,
                    "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// تحويل رقم العمود إلى اسم عمود Excel (مثل 1 -> A، 2 -> B، 27 -> AA)
        /// </summary>
        /// <param name="columnNumber">رقم العمود (يبدأ من 1)</param>
        /// <returns>اسم العمود في Excel</returns>
        private static string GetExcelColumnName(int columnNumber)
        {
            string columnName = string.Empty;

            while (columnNumber > 0)
            {
                int remainder = (columnNumber - 1) % 26;
                char letter = (char)('A' + remainder);
                columnName = letter + columnName;
                columnNumber = (columnNumber - 1) / 26;
            }

            return columnName;
        }
    }
}
