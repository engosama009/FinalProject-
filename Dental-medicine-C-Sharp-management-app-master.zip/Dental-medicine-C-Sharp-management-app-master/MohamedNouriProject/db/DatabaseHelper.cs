﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس مساعد للتعامل مع قاعدة البيانات
    /// </summary>
    public static class DatabaseHelper
    {
        // سلسلة الاتصال بقاعدة البيانات
        private static string ConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";

        // كائن الاتصال بقاعدة البيانات
        private static SqlConnection _connection;

        /// <summary>
        /// الحصول على كائن الاتصال بقاعدة البيانات
        /// </summary>
        public static SqlConnection Connection
        {
            get
            {
                // إنشاء كائن الاتصال إذا لم يكن موجودًا
                if (_connection == null)
                {
                    _connection = new SqlConnection(ConnectionString);
                }
                return _connection;
            }
        }

        /// <summary>
        /// فتح الاتصال بقاعدة البيانات إذا كان مغلقًا
        /// </summary>
        public static void OpenConnection()
        {
            // التحقق من حالة الاتصال
            if (Connection.State == ConnectionState.Closed || Connection.State == ConnectionState.Broken)
            {
                try
                {
                    // فتح الاتصال
                    Connection.Open();
                }
                catch (Exception ex)
                {
                    // عرض رسالة الخطأ
                    System.Windows.Forms.MessageBox.Show("خطأ في فتح الاتصال بقاعدة البيانات: " + ex.Message,
                        "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Error);

                    // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                    throw;
                }
            }
        }

        /// <summary>
        /// إغلاق الاتصال بقاعدة البيانات إذا كان مفتوحًا
        /// </summary>
        public static void CloseConnection()
        {
            // التحقق من حالة الاتصال
            if (Connection.State == ConnectionState.Open)
            {
                try
                {
                    // إغلاق الاتصال
                    Connection.Close();
                }
                catch (Exception ex)
                {
                    // عرض رسالة الخطأ
                    System.Windows.Forms.MessageBox.Show("خطأ في إغلاق الاتصال بقاعدة البيانات: " + ex.Message,
                        "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Error);

                    // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                    throw;
                }
            }
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع DataTable
        /// </summary>
        /// <param name="query">نص الاستعلام SQL</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>جدول بيانات يحتوي على نتائج الاستعلام</returns>
        public static DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            DataTable dataTable = new DataTable();

            try
            {
                // فتح الاتصال
                OpenConnection();

                // إنشاء أمر SQL
                using (SqlCommand command = new SqlCommand(query, Connection))
                {
                    // إضافة المعلمات إذا كانت موجودة
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    // إنشاء محول بيانات
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        // ملء جدول البيانات بنتائج الاستعلام
                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return dataTable;
        }

        /// <summary>
        /// تنفيذ أمر SQL (إدراج، تحديث، حذف) وإرجاع عدد الصفوف المتأثرة
        /// </summary>
        /// <param name="query">نص الأمر SQL</param>
        /// <param name="parameters">معلمات الأمر (اختياري)</param>
        /// <returns>عدد الصفوف المتأثرة</returns>
        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            int rowsAffected = 0;

            try
            {
                // فتح الاتصال
                OpenConnection();

                // إنشاء أمر SQL
                using (SqlCommand command = new SqlCommand(query, Connection))
                {
                    // إضافة المعلمات إذا كانت موجودة
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    // تنفيذ الأمر وإرجاع عدد الصفوف المتأثرة
                    rowsAffected = command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الأمر: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return rowsAffected;
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع قيمة واحدة (الصف الأول، العمود الأول)
        /// </summary>
        /// <param name="query">نص الاستعلام SQL</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>القيمة الناتجة من الاستعلام</returns>
        public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            object result = null;

            try
            {
                // فتح الاتصال
                OpenConnection();

                // إنشاء أمر SQL
                using (SqlCommand command = new SqlCommand(query, Connection))
                {
                    // إضافة المعلمات إذا كانت موجودة
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    // تنفيذ الاستعلام وإرجاع القيمة الأولى
                    result = command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return result;
        }
    }
}
