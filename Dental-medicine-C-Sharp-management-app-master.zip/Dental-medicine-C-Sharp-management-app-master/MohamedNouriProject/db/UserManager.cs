using System;
using System.Data;
using System.Data.SqlClient;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس ثابت (static) للتعامل مع عمليات المستخدمين في قاعدة البيانات
    /// يوفر هذا الكلاس واجهة موحدة للتعامل مع بيانات المستخدمين من جميع أجزاء التطبيق
    /// </summary>
    public static class UserManager
    {
        /// <summary>
        /// التحقق من صحة بيانات تسجيل الدخول للمستخدم
        /// </summary>
        /// <param name="username">اسم المستخدم المدخل</param>
        /// <param name="password">كلمة المرور المدخلة</param>
        /// <returns>دور المستخدم (مثل "Admin") إذا كانت بيانات الدخول صحيحة، وإلا فسلسلة فارغة</returns>
        /// <remarks>
        /// تستخدم هذه الدالة للتحقق من صحة بيانات المستخدم عند تسجيل الدخول
        /// وإرجاع دور المستخدم لتحديد الصلاحيات المناسبة
        /// </remarks>
        public static string AuthenticateUser(string username, string password)
        {
            // استعلام SQL للتحقق من صحة بيانات المستخدم
            string query = "SELECT role FROM Users WHERE Login = @username AND Password = @password";

            // إنشاء مصفوفة المعلمات للاستعلام
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@username", SqlDbType.VarChar) { Value = username },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = password }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع القيمة الأولى باستخدام كلاس DatabaseConnection
                object result = DatabaseConnection.ExecuteScalar(query, parameters);

                // إرجاع دور المستخدم إذا كان موجودًا، وإلا فسلسلة فارغة
                return result != null ? result.ToString().Trim() : string.Empty;
            }
            catch (Exception)
            {
                // إرجاع سلسلة فارغة في حالة حدوث خطأ
                return string.Empty;
            }
        }

        /// <summary>
        /// الحصول على قائمة جميع المستخدمين في النظام
        /// </summary>
        /// <returns>جدول بيانات يحتوي على معلومات جميع المستخدمين</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لعرض قائمة المستخدمين في واجهة إدارة المستخدمين
        /// </remarks>
        public static DataTable GetAllUsers()
        {
            // استعلام SQL للحصول على جميع المستخدمين (مع استبعاد كلمة المرور لأسباب أمنية)
            string query = "SELECT UserID, Login, role FROM Users";

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج باستخدام كلاس DatabaseConnection
                return DatabaseConnection.ExecuteQuery(query);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// إضافة مستخدم جديد إلى النظام
        /// </summary>
        /// <param name="login">اسم المستخدم الجديد</param>
        /// <param name="password">كلمة المرور للمستخدم الجديد</param>
        /// <param name="role">دور المستخدم (مثل "Admin" أو "User")</param>
        /// <returns>true إذا تمت الإضافة بنجاح، وإلا false</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لإنشاء حسابات مستخدمين جديدة في النظام
        /// </remarks>
        public static bool AddUser(string login, string password, string role)
        {
            // استعلام SQL لإضافة مستخدم جديد
            string query = "INSERT INTO Users (Login, Password, role) VALUES (@login, @password, @role)";

            // إنشاء مصفوفة المعلمات للاستعلام
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@login", SqlDbType.VarChar) { Value = login },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = password },
                new SqlParameter("@role", SqlDbType.VarChar) { Value = role }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة باستخدام كلاس DatabaseConnection
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                // إرجاع true إذا تم إضافة صف واحد على الأقل
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// تحديث بيانات مستخدم موجود في النظام
        /// </summary>
        /// <param name="userId">معرف المستخدم المراد تحديثه</param>
        /// <param name="login">اسم المستخدم الجديد</param>
        /// <param name="password">كلمة المرور الجديدة</param>
        /// <param name="role">دور المستخدم الجديد</param>
        /// <returns>true إذا تم التحديث بنجاح، وإلا false</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لتعديل بيانات المستخدمين الموجودين في النظام
        /// </remarks>
        public static bool UpdateUser(int userId, string login, string password, string role)
        {
            // استعلام SQL لتحديث بيانات المستخدم
            string query = "UPDATE Users SET Login = @login, Password = @password, role = @role WHERE UserID = @userId";

            // إنشاء مصفوفة المعلمات للاستعلام
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@userId", SqlDbType.Int) { Value = userId },
                new SqlParameter("@login", SqlDbType.VarChar) { Value = login },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = password },
                new SqlParameter("@role", SqlDbType.VarChar) { Value = role }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة باستخدام كلاس DatabaseConnection
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                // إرجاع true إذا تم تحديث صف واحد على الأقل
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// حذف مستخدم من النظام
        /// </summary>
        /// <param name="userId">معرف المستخدم المراد حذفه</param>
        /// <returns>true إذا تم الحذف بنجاح، وإلا false</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لإزالة حسابات المستخدمين من النظام
        /// </remarks>
        public static bool DeleteUser(int userId)
        {
            // استعلام SQL لحذف المستخدم
            string query = "DELETE FROM Users WHERE UserID = @userId";

            // إنشاء مصفوفة المعلمات للاستعلام
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@userId", SqlDbType.Int) { Value = userId }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة باستخدام كلاس DatabaseConnection
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                // إرجاع true إذا تم حذف صف واحد على الأقل
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }
    }
}
