using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس لإدارة الاتصال بقاعدة البيانات
    /// </summary>
    public static class ConnectionManager
    {
        // استرجاع سلسلة الاتصال من ملف الإعدادات
        private static string DefaultConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";

        /// <summary>
        /// الحصول على اتصال جديد باستخدام سلسلة الاتصال الافتراضية
        /// </summary>
        /// <returns>كائن اتصال جديد بقاعدة البيانات</returns>
        public static SqlConnection GetConnection()
        {
            // إنشاء اتصال جديد باستخدام سلسلة الاتصال الافتراضية
            return new SqlConnection(DefaultConnectionString);
        }

        /// <summary>
        /// الحصول على اتصال جديد باستخدام سلسلة اتصال مخصصة
        /// </summary>
        /// <param name="connectionString">سلسلة الاتصال المخصصة</param>
        /// <returns>كائن اتصال جديد بقاعدة البيانات</returns>
        public static SqlConnection GetConnection(string connectionString)
        {
            // إنشاء اتصال جديد باستخدام سلسلة الاتصال المخصصة
            return new SqlConnection(connectionString);
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع DataTable
        /// </summary>
        /// <param name="query">نص الاستعلام SQL</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>جدول بيانات يحتوي على نتائج الاستعلام</returns>
        public static System.Data.DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            // إنشاء جدول بيانات جديد
            System.Data.DataTable dataTable = new System.Data.DataTable();

            try
            {
                // إنشاء اتصال جديد
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // إنشاء محول بيانات
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // ملء جدول البيانات بنتائج الاستعلام
                            adapter.Fill(dataTable);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return dataTable;
        }

        /// <summary>
        /// تنفيذ أمر SQL (إدراج، تحديث، حذف) وإرجاع عدد الصفوف المتأثرة
        /// </summary>
        /// <param name="query">نص الأمر SQL</param>
        /// <param name="parameters">معلمات الأمر (اختياري)</param>
        /// <returns>عدد الصفوف المتأثرة</returns>
        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            int rowsAffected = 0;

            try
            {
                // إنشاء اتصال جديد
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // فتح الاتصال
                        connection.Open();

                        // تنفيذ الأمر وإرجاع عدد الصفوف المتأثرة
                        rowsAffected = command.ExecuteNonQuery();

                        // إغلاق الاتصال
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الأمر: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return rowsAffected;
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع قيمة واحدة (الصف الأول، العمود الأول)
        /// </summary>
        /// <param name="query">نص الاستعلام SQL</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>القيمة الناتجة من الاستعلام</returns>
        public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            object result = null;

            try
            {
                // إنشاء اتصال جديد
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // فتح الاتصال
                        connection.Open();

                        // تنفيذ الاستعلام وإرجاع القيمة الأولى
                        result = command.ExecuteScalar();

                        // إغلاق الاتصال
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            return result;
        }
    }
}
