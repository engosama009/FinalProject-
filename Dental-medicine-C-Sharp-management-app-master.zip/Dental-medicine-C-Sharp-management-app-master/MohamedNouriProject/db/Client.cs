﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس يمثل العميل (المريض) في النظام
    /// </summary>
    public class Client
    {
        // خصائص العميل

        /// <summary>
        /// معرف العميل
        /// </summary>
        public int ClientID { get; set; }

        /// <summary>
        /// رمز العميل
        /// </summary>
        public string CodeClient { get; set; }

        /// <summary>
        /// الاسم الأول للعميل
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// الاسم الأخير للعميل
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// تاريخ ميلاد العميل
        /// </summary>
        public DateTime BirthDate { get; set; }

        /// <summary>
        /// عنوان العميل
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// رقم هاتف العميل
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// البريد الإلكتروني للعميل
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// ملاحظات حول العميل
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// إنشاء كائن عميل جديد
        /// </summary>
        public Client()
        {
            // المنشئ الافتراضي
        }

        /// <summary>
        /// إنشاء كائن عميل جديد بقيم محددة
        /// </summary>
        /// <param name="clientID">معرف العميل</param>
        /// <param name="codeClient">رمز العميل</param>
        /// <param name="firstName">الاسم الأول</param>
        /// <param name="lastName">الاسم الأخير</param>
        /// <param name="birthDate">تاريخ الميلاد</param>
        /// <param name="address">العنوان</param>
        /// <param name="phone">رقم الهاتف</param>
        /// <param name="email">البريد الإلكتروني</param>
        /// <param name="notes">ملاحظات</param>
        public Client(int clientID, string codeClient, string firstName, string lastName, DateTime birthDate, string address, string phone, string email, string notes)
        {
            // تعيين قيم الخصائص
            ClientID = clientID;
            CodeClient = codeClient;
            FirstName = firstName;
            LastName = lastName;
            BirthDate = birthDate;
            Address = address;
            Phone = phone;
            Email = email;
            Notes = notes;
        }

        /// <summary>
        /// الحصول على قائمة جميع العملاء
        /// </summary>
        /// <returns>جدول بيانات يحتوي على جميع العملاء</returns>
        public static DataTable GetAllClients()
        {
            // استعلام SQL للحصول على جميع العملاء
            string query = "SELECT * FROM Clients ORDER BY LastName, FirstName";

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// البحث عن العملاء بواسطة الاسم
        /// </summary>
        /// <param name="searchText">نص البحث</param>
        /// <returns>جدول بيانات يحتوي على نتائج البحث</returns>
        public static DataTable SearchClients(string searchText)
        {
            // استعلام SQL للبحث عن العملاء بواسطة الاسم
            string query = "SELECT * FROM Clients WHERE FirstName LIKE @searchText OR LastName LIKE @searchText ORDER BY LastName, FirstName";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@searchText", SqlDbType.VarChar) { Value = "%" + searchText + "%" }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query, parameters);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// الحصول على عميل بواسطة المعرف
        /// </summary>
        /// <param name="clientID">معرف العميل</param>
        /// <returns>كائن العميل إذا تم العثور عليه، وإلا فارغ</returns>
        public static Client GetClientByID(int clientID)
        {
            // استعلام SQL للحصول على العميل بواسطة المعرف
            string query = "SELECT * FROM Clients WHERE ClientID = @clientID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@clientID", SqlDbType.Int) { Value = clientID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                DataTable result = DatabaseConnection.ExecuteQuery(query, parameters);

                // التحقق من وجود نتائج
                if (result.Rows.Count > 0)
                {
                    // إنشاء كائن عميل جديد من البيانات
                    DataRow row = result.Rows[0];
                    return new Client(
                        Convert.ToInt32(row["ClientID"]),
                        row["CodeClient"].ToString(),
                        row["FirstName"].ToString(),
                        row["LastName"].ToString(),
                        Convert.ToDateTime(row["BirthDate"]),
                        row["Address"].ToString(),
                        row["Phone"].ToString(),
                        row["Email"].ToString(),
                        row["Notes"].ToString()
                    );
                }

                // إرجاع فارغ إذا لم يتم العثور على العميل
                return null;
            }
            catch (Exception)
            {
                // إرجاع فارغ في حالة حدوث خطأ
                return null;
            }
        }

        /// <summary>
        /// الحصول على عميل بواسطة الرمز
        /// </summary>
        /// <param name="codeClient">رمز العميل</param>
        /// <returns>كائن العميل إذا تم العثور عليه، وإلا فارغ</returns>
        public static Client GetClientByCode(string codeClient)
        {
            // استعلام SQL للحصول على العميل بواسطة الرمز
            string query = "SELECT * FROM Clients WHERE CodeClient = @codeClient";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@codeClient", SqlDbType.VarChar) { Value = codeClient }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                DataTable result = DatabaseConnection.ExecuteQuery(query, parameters);

                // التحقق من وجود نتائج
                if (result.Rows.Count > 0)
                {
                    // إنشاء كائن عميل جديد من البيانات
                    DataRow row = result.Rows[0];
                    return new Client(
                        Convert.ToInt32(row["ClientID"]),
                        row["CodeClient"].ToString(),
                        row["FirstName"].ToString(),
                        row["LastName"].ToString(),
                        Convert.ToDateTime(row["BirthDate"]),
                        row["Address"].ToString(),
                        row["Phone"].ToString(),
                        row["Email"].ToString(),
                        row["Notes"].ToString()
                    );
                }

                // إرجاع فارغ إذا لم يتم العثور على العميل
                return null;
            }
            catch (Exception)
            {
                // إرجاع فارغ في حالة حدوث خطأ
                return null;
            }
        }

        /// <summary>
        /// إضافة عميل جديد
        /// </summary>
        /// <returns>true إذا تمت الإضافة بنجاح، وإلا false</returns>
        public bool Add()
        {
            // استعلام SQL لإضافة عميل جديد
            string query = @"INSERT INTO Clients (CodeClient, FirstName, LastName, BirthDate, Address, Phone, Email, Notes)
                           VALUES (@codeClient, @firstName, @lastName, @birthDate, @address, @phone, @email, @notes)";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@codeClient", SqlDbType.VarChar) { Value = CodeClient },
                new SqlParameter("@firstName", SqlDbType.VarChar) { Value = FirstName },
                new SqlParameter("@lastName", SqlDbType.VarChar) { Value = LastName },
                new SqlParameter("@birthDate", SqlDbType.Date) { Value = BirthDate },
                new SqlParameter("@address", SqlDbType.VarChar) { Value = Address },
                new SqlParameter("@phone", SqlDbType.VarChar) { Value = Phone },
                new SqlParameter("@email", SqlDbType.VarChar) { Value = Email },
                new SqlParameter("@notes", SqlDbType.VarChar) { Value = Notes }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// تحديث بيانات العميل
        /// </summary>
        /// <returns>true إذا تم التحديث بنجاح، وإلا false</returns>
        public bool Update()
        {
            // استعلام SQL لتحديث بيانات العميل
            string query = @"UPDATE Clients
                           SET CodeClient = @codeClient,
                               FirstName = @firstName,
                               LastName = @lastName,
                               BirthDate = @birthDate,
                               Address = @address,
                               Phone = @phone,
                               Email = @email,
                               Notes = @notes
                           WHERE ClientID = @clientID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@clientID", SqlDbType.Int) { Value = ClientID },
                new SqlParameter("@codeClient", SqlDbType.VarChar) { Value = CodeClient },
                new SqlParameter("@firstName", SqlDbType.VarChar) { Value = FirstName },
                new SqlParameter("@lastName", SqlDbType.VarChar) { Value = LastName },
                new SqlParameter("@birthDate", SqlDbType.Date) { Value = BirthDate },
                new SqlParameter("@address", SqlDbType.VarChar) { Value = Address },
                new SqlParameter("@phone", SqlDbType.VarChar) { Value = Phone },
                new SqlParameter("@email", SqlDbType.VarChar) { Value = Email },
                new SqlParameter("@notes", SqlDbType.VarChar) { Value = Notes }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// حذف العميل
        /// </summary>
        /// <returns>true إذا تم الحذف بنجاح، وإلا false</returns>
        public bool Delete()
        {
            // استعلام SQL لحذف العميل
            string query = "DELETE FROM Clients WHERE ClientID = @clientID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@clientID", SqlDbType.Int) { Value = ClientID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// الحصول على الاسم الكامل للعميل
        /// </summary>
        /// <returns>الاسم الكامل للعميل</returns>
        public string GetFullName()
        {
            // إرجاع الاسم الكامل للعميل
            return FirstName + " " + LastName;
        }
    }
}
