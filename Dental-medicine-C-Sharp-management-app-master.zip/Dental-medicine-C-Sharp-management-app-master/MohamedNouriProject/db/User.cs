﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس يمثل المستخدم في النظام
    /// </summary>
    public class User
    {
        // خصائص المستخدم

        /// <summary>
        /// معرف المستخدم
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// اسم تسجيل الدخول
        /// </summary>
        public string Login { get; set; }

        /// <summary>
        /// كلمة المرور
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// دور المستخدم (مدير، طبيب، سكرتير)
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// إنشاء كائن مستخدم جديد
        /// </summary>
        public User()
        {
            // المنشئ الافتراضي
        }

        /// <summary>
        /// إنشاء كائن مستخدم جديد بقيم محددة
        /// </summary>
        /// <param name="userID">معرف المستخدم</param>
        /// <param name="login">اسم تسجيل الدخول</param>
        /// <param name="password">كلمة المرور</param>
        /// <param name="role">دور المستخدم</param>
        public User(int userID, string login, string password, string role)
        {
            // تعيين قيم الخصائص
            UserID = userID;
            Login = login;
            Password = password;
            Role = role;
        }

        /// <summary>
        /// التحقق من صحة بيانات تسجيل الدخول
        /// </summary>
        /// <param name="username">اسم المستخدم</param>
        /// <param name="password">كلمة المرور</param>
        /// <returns>دور المستخدم إذا كانت بيانات الدخول صحيحة، وإلا فارغ</returns>
        public static string AuthenticateUser(string username, string password)
        {
            // استعلام SQL للتحقق من صحة بيانات المستخدم
            string query = "SELECT role FROM Users WHERE Login = @username AND Password = @password";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@username", SqlDbType.VarChar) { Value = username },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = password }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع القيمة الأولى
                object result = DatabaseConnection.ExecuteScalar(query, parameters);

                // إرجاع دور المستخدم إذا كان موجودًا، وإلا فارغ
                return result != null ? result.ToString().Trim() : string.Empty;
            }
            catch (Exception)
            {
                // إرجاع فارغ في حالة حدوث خطأ
                return string.Empty;
            }
        }

        /// <summary>
        /// الحصول على قائمة جميع المستخدمين
        /// </summary>
        /// <returns>جدول بيانات يحتوي على جميع المستخدمين</returns>
        public static DataTable GetAllUsers()
        {
            // استعلام SQL للحصول على جميع المستخدمين
            string query = "SELECT UserID, Login, role FROM Users";

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// الحصول على مستخدم بواسطة المعرف
        /// </summary>
        /// <param name="userID">معرف المستخدم</param>
        /// <returns>كائن المستخدم إذا تم العثور عليه، وإلا فارغ</returns>
        public static User GetUserByID(int userID)
        {
            // استعلام SQL للحصول على المستخدم بواسطة المعرف
            string query = "SELECT UserID, Login, Password, role FROM Users WHERE UserID = @userID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@userID", SqlDbType.Int) { Value = userID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                DataTable result = DatabaseConnection.ExecuteQuery(query, parameters);

                // التحقق من وجود نتائج
                if (result.Rows.Count > 0)
                {
                    // إنشاء كائن مستخدم جديد من البيانات
                    DataRow row = result.Rows[0];
                    return new User(
                        Convert.ToInt32(row["UserID"]),
                        row["Login"].ToString(),
                        row["Password"].ToString(),
                        row["role"].ToString()
                    );
                }

                // إرجاع فارغ إذا لم يتم العثور على المستخدم
                return null;
            }
            catch (Exception)
            {
                // إرجاع فارغ في حالة حدوث خطأ
                return null;
            }
        }

        /// <summary>
        /// إضافة مستخدم جديد
        /// </summary>
        /// <returns>true إذا تمت الإضافة بنجاح، وإلا false</returns>
        public bool Add()
        {
            // استعلام SQL لإضافة مستخدم جديد
            string query = "INSERT INTO Users (Login, Password, role) VALUES (@login, @password, @role)";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@login", SqlDbType.VarChar) { Value = Login },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = Password },
                new SqlParameter("@role", SqlDbType.VarChar) { Value = Role }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// تحديث بيانات المستخدم
        /// </summary>
        /// <returns>true إذا تم التحديث بنجاح، وإلا false</returns>
        public bool Update()
        {
            // استعلام SQL لتحديث بيانات المستخدم
            string query = "UPDATE Users SET Login = @login, Password = @password, role = @role WHERE UserID = @userID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@userID", SqlDbType.Int) { Value = UserID },
                new SqlParameter("@login", SqlDbType.VarChar) { Value = Login },
                new SqlParameter("@password", SqlDbType.VarChar) { Value = Password },
                new SqlParameter("@role", SqlDbType.VarChar) { Value = Role }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// حذف المستخدم
        /// </summary>
        /// <returns>true إذا تم الحذف بنجاح، وإلا false</returns>
        public bool Delete()
        {
            // استعلام SQL لحذف المستخدم
            string query = "DELETE FROM Users WHERE UserID = @userID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@userID", SqlDbType.Int) { Value = UserID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }
    }
}
