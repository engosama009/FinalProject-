using System;
using System.Data;
using System.Data.SqlClient;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس ثابت (static) للتعامل مع الاتصال بقاعدة البيانات وتنفيذ العمليات عليها
    /// يوفر هذا الكلاس واجهة موحدة للتعامل مع قاعدة البيانات من جميع أجزاء التطبيق
    /// </summary>
    public static class DatabaseConnection
    {
        /// <summary>
        /// سلسلة الاتصال بقاعدة البيانات
        /// تحتوي على معلومات الاتصال بالخادم وقاعدة البيانات
        /// </summary>
        private static string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";

        /// <summary>
        /// الحصول على اتصال جديد بقاعدة البيانات
        /// </summary>
        /// <returns>كائن اتصال جديد بقاعدة البيانات جاهز للاستخدام</returns>
        /// <remarks>
        /// يجب إغلاق الاتصال بعد الانتهاء من استخدامه لتحرير الموارد
        /// يفضل استخدام عبارة using عند استخدام هذه الدالة
        /// </remarks>
        public static SqlConnection GetConnection()
        {
            // إنشاء اتصال جديد باستخدام سلسلة الاتصال
            return new SqlConnection(connectionString);
        }

        /// <summary>
        /// تنفيذ استعلام SQL وإرجاع النتائج في جدول بيانات
        /// </summary>
        /// <param name="query">نص الاستعلام SQL المراد تنفيذه</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>جدول بيانات يحتوي على نتائج الاستعلام</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لتنفيذ استعلامات SELECT وإرجاع النتائج في جدول بيانات
        /// مثال: DataTable dt = DatabaseConnection.ExecuteQuery("SELECT * FROM Client");
        /// </remarks>
        public static DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            DataTable dataTable = new DataTable();

            try
            {
                // إنشاء اتصال جديد بقاعدة البيانات
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL مع الاستعلام والاتصال
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إلى الأمر إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // إنشاء محول بيانات لتنفيذ الاستعلام وملء الجدول
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // فتح الاتصال بقاعدة البيانات
                            connection.Open();

                            // ملء جدول البيانات بنتائج الاستعلام
                            adapter.Fill(dataTable);

                            // إغلاق الاتصال بقاعدة البيانات
                            connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ للمستخدم
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            // إرجاع جدول البيانات المملوء بالنتائج
            return dataTable;
        }

        /// <summary>
        /// تنفيذ أمر SQL (إدراج، تحديث، حذف) وإرجاع عدد الصفوف المتأثرة
        /// </summary>
        /// <param name="query">نص الأمر SQL المراد تنفيذه</param>
        /// <param name="parameters">معلمات الأمر (اختياري)</param>
        /// <returns>عدد الصفوف المتأثرة بالأمر</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لتنفيذ أوامر تعديل البيانات مثل INSERT و UPDATE و DELETE
        /// مثال: int rowsAffected = DatabaseConnection.ExecuteNonQuery("DELETE FROM Client WHERE CodeClient = @id", parameters);
        /// </remarks>
        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            // متغير لتخزين عدد الصفوف المتأثرة
            int rowsAffected = 0;

            try
            {
                // إنشاء اتصال جديد بقاعدة البيانات
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL مع الاستعلام والاتصال
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إلى الأمر إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // فتح الاتصال بقاعدة البيانات
                        connection.Open();

                        // تنفيذ الأمر وإرجاع عدد الصفوف المتأثرة
                        rowsAffected = command.ExecuteNonQuery();

                        // إغلاق الاتصال بقاعدة البيانات
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ للمستخدم
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الأمر: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            // إرجاع عدد الصفوف المتأثرة
            return rowsAffected;
        }

        /// <summary>
        /// تنفيذ استعلام SQL وإرجاع قيمة واحدة (الصف الأول، العمود الأول)
        /// </summary>
        /// <param name="query">نص الاستعلام SQL المراد تنفيذه</param>
        /// <param name="parameters">معلمات الاستعلام (اختياري)</param>
        /// <returns>القيمة الناتجة من الاستعلام أو null إذا لم تكن هناك نتائج</returns>
        /// <remarks>
        /// تستخدم هذه الدالة لتنفيذ استعلامات تُرجع قيمة واحدة مثل COUNT() أو MAX() أو MIN()
        /// مثال: object count = DatabaseConnection.ExecuteScalar("SELECT COUNT(*) FROM Client");
        /// </remarks>
        public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            // متغير لتخزين نتيجة الاستعلام
            object result = null;

            try
            {
                // إنشاء اتصال جديد بقاعدة البيانات
                using (SqlConnection connection = GetConnection())
                {
                    // إنشاء أمر SQL مع الاستعلام والاتصال
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // إضافة المعلمات إلى الأمر إذا كانت موجودة
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // فتح الاتصال بقاعدة البيانات
                        connection.Open();

                        // تنفيذ الاستعلام وإرجاع القيمة الأولى (الصف الأول، العمود الأول)
                        result = command.ExecuteScalar();

                        // إغلاق الاتصال بقاعدة البيانات
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // عرض رسالة الخطأ للمستخدم
                System.Windows.Forms.MessageBox.Show("خطأ في تنفيذ الاستعلام: " + ex.Message,
                    "خطأ في قاعدة البيانات", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);

                // إعادة إلقاء الاستثناء للتعامل معه في المستوى الأعلى
                throw;
            }

            // إرجاع نتيجة الاستعلام
            return result;
        }
    }
}
