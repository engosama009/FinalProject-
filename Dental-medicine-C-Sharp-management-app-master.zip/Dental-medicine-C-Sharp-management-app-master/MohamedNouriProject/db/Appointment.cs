﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MohamedNouriProject.db
{
    /// <summary>
    /// كلاس يمثل موعد في النظام
    /// </summary>
    public class Appointment
    {
        // خصائص الموعد

        /// <summary>
        /// معرف الموعد
        /// </summary>
        public int AppointmentID { get; set; }

        /// <summary>
        /// رمز الموعد
        /// </summary>
        public string CodeAppointment { get; set; }

        /// <summary>
        /// معرف العميل
        /// </summary>
        public int ClientID { get; set; }

        /// <summary>
        /// تاريخ الموعد
        /// </summary>
        public DateTime AppointmentDate { get; set; }

        /// <summary>
        /// وقت بدء الموعد
        /// </summary>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        /// وقت انتهاء الموعد
        /// </summary>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// حالة الموعد (محجوز، ملغى، مكتمل)
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// ملاحظات حول الموعد
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// إنشاء كائن موعد جديد
        /// </summary>
        public Appointment()
        {
            // المنشئ الافتراضي
        }

        /// <summary>
        /// إنشاء كائن موعد جديد بقيم محددة
        /// </summary>
        /// <param name="appointmentID">معرف الموعد</param>
        /// <param name="codeAppointment">رمز الموعد</param>
        /// <param name="clientID">معرف العميل</param>
        /// <param name="appointmentDate">تاريخ الموعد</param>
        /// <param name="startTime">وقت بدء الموعد</param>
        /// <param name="endTime">وقت انتهاء الموعد</param>
        /// <param name="status">حالة الموعد</param>
        /// <param name="notes">ملاحظات</param>
        public Appointment(int appointmentID, string codeAppointment, int clientID, DateTime appointmentDate, TimeSpan startTime, TimeSpan endTime, string status, string notes)
        {
            // تعيين قيم الخصائص
            AppointmentID = appointmentID;
            CodeAppointment = codeAppointment;
            ClientID = clientID;
            AppointmentDate = appointmentDate;
            StartTime = startTime;
            EndTime = endTime;
            Status = status;
            Notes = notes;
        }

        /// <summary>
        /// الحصول على قائمة جميع المواعيد
        /// </summary>
        /// <returns>جدول بيانات يحتوي على جميع المواعيد</returns>
        public static DataTable GetAllAppointments()
        {
            // استعلام SQL للحصول على جميع المواعيد
            string query = @"SELECT a.*, c.FirstName, c.LastName
                           FROM Appointments a
                           INNER JOIN Clients c ON a.ClientID = c.ClientID
                           ORDER BY a.AppointmentDate DESC, a.StartTime";

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// الحصول على مواعيد اليوم
        /// </summary>
        /// <returns>جدول بيانات يحتوي على مواعيد اليوم</returns>
        public static DataTable GetTodayAppointments()
        {
            // استعلام SQL للحصول على مواعيد اليوم
            string query = @"SELECT a.*, c.FirstName, c.LastName
                           FROM Appointments a
                           INNER JOIN Clients c ON a.ClientID = c.ClientID
                           WHERE CONVERT(date, a.AppointmentDate) = CONVERT(date, GETDATE())
                           ORDER BY a.StartTime";

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// الحصول على مواعيد عميل معين
        /// </summary>
        /// <param name="clientID">معرف العميل</param>
        /// <returns>جدول بيانات يحتوي على مواعيد العميل</returns>
        public static DataTable GetClientAppointments(int clientID)
        {
            // استعلام SQL للحصول على مواعيد عميل معين
            string query = @"SELECT a.*, c.FirstName, c.LastName
                           FROM Appointments a
                           INNER JOIN Clients c ON a.ClientID = c.ClientID
                           WHERE a.ClientID = @clientID
                           ORDER BY a.AppointmentDate DESC, a.StartTime";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@clientID", SqlDbType.Int) { Value = clientID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                return DatabaseConnection.ExecuteQuery(query, parameters);
            }
            catch (Exception)
            {
                // إرجاع جدول بيانات فارغ في حالة حدوث خطأ
                return new DataTable();
            }
        }

        /// <summary>
        /// الحصول على موعد بواسطة المعرف
        /// </summary>
        /// <param name="appointmentID">معرف الموعد</param>
        /// <returns>كائن الموعد إذا تم العثور عليه، وإلا فارغ</returns>
        public static Appointment GetAppointmentByID(int appointmentID)
        {
            // استعلام SQL للحصول على الموعد بواسطة المعرف
            string query = "SELECT * FROM Appointments WHERE AppointmentID = @appointmentID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@appointmentID", SqlDbType.Int) { Value = appointmentID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتائج
                DataTable result = DatabaseConnection.ExecuteQuery(query, parameters);

                // التحقق من وجود نتائج
                if (result.Rows.Count > 0)
                {
                    // إنشاء كائن موعد جديد من البيانات
                    DataRow row = result.Rows[0];
                    return new Appointment(
                        Convert.ToInt32(row["AppointmentID"]),
                        row["CodeAppointment"].ToString(),
                        Convert.ToInt32(row["ClientID"]),
                        Convert.ToDateTime(row["AppointmentDate"]),
                        (TimeSpan)row["StartTime"],
                        (TimeSpan)row["EndTime"],
                        row["Status"].ToString(),
                        row["Notes"].ToString()
                    );
                }

                // إرجاع فارغ إذا لم يتم العثور على الموعد
                return null;
            }
            catch (Exception)
            {
                // إرجاع فارغ في حالة حدوث خطأ
                return null;
            }
        }

        /// <summary>
        /// إضافة موعد جديد
        /// </summary>
        /// <returns>true إذا تمت الإضافة بنجاح، وإلا false</returns>
        public bool Add()
        {
            // استعلام SQL لإضافة موعد جديد
            string query = @"INSERT INTO Appointments (CodeAppointment, ClientID, AppointmentDate, StartTime, EndTime, Status, Notes)
                           VALUES (@codeAppointment, @clientID, @appointmentDate, @startTime, @endTime, @status, @notes)";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@codeAppointment", SqlDbType.VarChar) { Value = CodeAppointment },
                new SqlParameter("@clientID", SqlDbType.Int) { Value = ClientID },
                new SqlParameter("@appointmentDate", SqlDbType.Date) { Value = AppointmentDate },
                new SqlParameter("@startTime", SqlDbType.Time) { Value = StartTime },
                new SqlParameter("@endTime", SqlDbType.Time) { Value = EndTime },
                new SqlParameter("@status", SqlDbType.VarChar) { Value = Status },
                new SqlParameter("@notes", SqlDbType.VarChar) { Value = Notes }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// تحديث بيانات الموعد
        /// </summary>
        /// <returns>true إذا تم التحديث بنجاح، وإلا false</returns>
        public bool Update()
        {
            // استعلام SQL لتحديث بيانات الموعد
            string query = @"UPDATE Appointments
                           SET CodeAppointment = @codeAppointment,
                               ClientID = @clientID,
                               AppointmentDate = @appointmentDate,
                               StartTime = @startTime,
                               EndTime = @endTime,
                               Status = @status,
                               Notes = @notes
                           WHERE AppointmentID = @appointmentID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@appointmentID", SqlDbType.Int) { Value = AppointmentID },
                new SqlParameter("@codeAppointment", SqlDbType.VarChar) { Value = CodeAppointment },
                new SqlParameter("@clientID", SqlDbType.Int) { Value = ClientID },
                new SqlParameter("@appointmentDate", SqlDbType.Date) { Value = AppointmentDate },
                new SqlParameter("@startTime", SqlDbType.Time) { Value = StartTime },
                new SqlParameter("@endTime", SqlDbType.Time) { Value = EndTime },
                new SqlParameter("@status", SqlDbType.VarChar) { Value = Status },
                new SqlParameter("@notes", SqlDbType.VarChar) { Value = Notes }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// حذف الموعد
        /// </summary>
        /// <returns>true إذا تم الحذف بنجاح، وإلا false</returns>
        public bool Delete()
        {
            // استعلام SQL لحذف الموعد
            string query = "DELETE FROM Appointments WHERE AppointmentID = @appointmentID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@appointmentID", SqlDbType.Int) { Value = AppointmentID }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }

        /// <summary>
        /// تحديث حالة الموعد
        /// </summary>
        /// <param name="status">الحالة الجديدة</param>
        /// <returns>true إذا تم التحديث بنجاح، وإلا false</returns>
        public bool UpdateStatus(string status)
        {
            // استعلام SQL لتحديث حالة الموعد
            string query = "UPDATE Appointments SET Status = @status WHERE AppointmentID = @appointmentID";

            // إنشاء مصفوفة المعلمات
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@appointmentID", SqlDbType.Int) { Value = AppointmentID },
                new SqlParameter("@status", SqlDbType.VarChar) { Value = status }
            };

            try
            {
                // تنفيذ الاستعلام وإرجاع النتيجة
                int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                // تحديث الحالة في الكائن الحالي
                if (rowsAffected > 0)
                {
                    Status = status;
                }

                return rowsAffected > 0;
            }
            catch (Exception)
            {
                // إرجاع false في حالة حدوث خطأ
                return false;
            }
        }
    }
}
