﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MohamedNouriProject.db;

namespace MohamedNouriProject
{
    /// <summary>
    /// واجهة مستخدم لعرض وإدارة قائمة الأسنان
    /// </summary>
    public partial class DentsListe : UserControl
    {
        /// <summary>
        /// متغير اتصال قاعدة البيانات - تم استبداله باستخدام كلاس DatabaseConnection
        /// </summary>
        // استخدام كلاس DatabaseConnection بدلاً من تعريف سلسلة الاتصال هنا

        /// <summary>
        /// المُنشئ - يقوم بتهيئة واجهة المستخدم وإعداد جدول البيانات
        /// </summary>
        public DentsListe()
        {
            // تهيئة مكونات واجهة المستخدم
            InitializeComponent();

            // ضبط حجم الأعمدة ليناسب محتوى الجدول
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // تحميل بيانات الأسنان في الجدول
            BindGrid("SELECT * FROM Dent ");

            // إضافة زر التعديل إلى الجدول
            DataGridViewButtonColumn Editlink = new DataGridViewButtonColumn();
            Editlink.HeaderText = "Edit";
            Editlink.DataPropertyName = "lnkColumn";
            Editlink.Text = "Edit";
            Editlink.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(Editlink);

            // إضافة زر الحذف إلى الجدول
            DataGridViewButtonColumn Deletelink = new DataGridViewButtonColumn();
            Deletelink.HeaderText = "Delete";
            Deletelink.DataPropertyName = "lnkColumn";
            Deletelink.Text = "Delete";
            Deletelink.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(Deletelink);
        }
        /// <summary>
        /// تحميل بيانات الأسنان في الجدول
        /// </summary>
        /// <param name="query">استعلام SQL لجلب البيانات</param>
        private void BindGrid(String query)
        {
            // استخدام كلاس DatabaseConnection لتنفيذ الاستعلام
            DataTable dt = DatabaseConnection.ExecuteQuery(query);

            // عرض عدد النتائج
            totlaNumbre.Text = dt.Rows.Count.ToString();

            // تعيين مصدر البيانات للجدول
            dataGridView1.DataSource = dt;

            // Change column headers to English
            if (dataGridView1.Columns.Contains("CodeDent"))
                dataGridView1.Columns["CodeDent"].HeaderText = "Tooth ID";

            if (dataGridView1.Columns.Contains("description"))
                dataGridView1.Columns["description"].HeaderText = "Description";

            if (dataGridView1.Columns.Contains("prix"))
                dataGridView1.Columns["prix"].HeaderText = "Price";
        }

        /// <summary>
        /// حذف سن من قاعدة البيانات
        /// </summary>
        /// <param name="ID">معرف السن المراد حذفه</param>
        private void Delete_Click(string ID)
        {
            // عرض رسالة تأكيد قبل الحذف
            DialogResult dr = MessageBox.Show("Are you sure you want to delete " + ID, "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

            // إذا أكد المستخدم الحذف
            if (dr == DialogResult.Yes)
            {
                // استعلام SQL لحذف السن مع استخدام معلمات لمنع SQL Injection
                String query = "DELETE FROM Dent WHERE CodeDent = @CodeDent";

                try
                {
                    // إنشاء مصفوفة المعلمات للاستعلام
                    // نفترض أن معرف السن تم التحقق منه مسبقًا في دالة dataGridView1_CellContentClick
                    int dentId = int.Parse(ID);

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@CodeDent", SqlDbType.Int) { Value = dentId }
                    };

                    // استخدام كلاس DatabaseConnection لتنفيذ الأمر
                    int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                    // التحقق من نجاح عملية الحذف
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Delete successful");
                        // تحديث الجدول بعد الحذف
                        BindGrid("SELECT * FROM Dent");
                    }
                    else
                    {
                        MessageBox.Show("No records were deleted");
                    }
                }
                catch (SqlException ex)
                {
                    // عرض رسالة الخطأ في حالة فشل الحذف
                    MessageBox.Show(ex.Message);
                }
                catch (FormatException)
                {
                    // عرض رسالة خطأ في حالة عدم صحة تنسيق المعرف
                    MessageBox.Show("Invalid ID format");
                }
            }
        }

        /// <summary>
        /// تعديل سن في قاعدة البيانات
        /// </summary>
        /// <param name="ID">معرف السن المراد تعديله</param>
        private void Edit_Click(string ID)
        {
            try
            {
                // استعلام SQL للحصول على بيانات السن
                string query = "SELECT * FROM Dent WHERE CodeDent = @CodeDent";

                // إنشاء مصفوفة المعلمات للاستعلام
                // نفترض أن معرف السن تم التحقق منه مسبقًا في دالة dataGridView1_CellContentClick
                int dentId = int.Parse(ID);

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@CodeDent", SqlDbType.Int) { Value = dentId }
                };

                // استخدام كلاس DatabaseConnection لتنفيذ الاستعلام
                DataTable dt = DatabaseConnection.ExecuteQuery(query, parameters);

                if (dt.Rows.Count > 0)
                {
                    // إنشاء نموذج تعديل السن
                    // بدلاً من استخدام EditDent، سنستخدم AddDent مع تعديل بسيط
                    AddDent editForm = new AddDent();
                    editForm.Text = "Edit Tooth";

                    // تعيين معرف السن في النموذج
                    editForm.DentID = ID;

                    // تعيين بيانات السن في النموذج
                    editForm.TreatmentType.Text = dt.Rows[0]["TreatmentType"].ToString();

                    // تعيين تكلفة السن (إذا كانت موجودة)
                    if (dt.Rows[0]["Cost"] != DBNull.Value)
                    {
                        editForm.Cost.Text = dt.Rows[0]["Cost"].ToString();
                    }

                    // تغيير نص زر الحفظ
                    editForm.save.Text = "Update";

                    // عرض النموذج
                    editForm.ShowDialog();

                    // تحديث الجدول بعد التعديل
                    BindGrid("SELECT * FROM Dent");
                }
                else
                {
                    MessageBox.Show("Tooth not found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        /// <summary>
        /// معالج حدث النقر على خلية في الجدول
        /// </summary>
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // التأكد من أن النقر ليس على رأس العمود
            if (e.RowIndex >= 0)
            {
                // التحقق مما إذا كان النقر على زر "تعديل" أو "حذف"
                if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Edit" ||
                    dataGridView1.Columns[e.ColumnIndex].HeaderText == "Delete")
                {
                    // الحصول على معرف السن من عمود "Tooth ID" (CodeDent)
                    if (dataGridView1.Columns.Contains("CodeDent"))
                    {
                        // التحقق من أن قيمة الخلية ليست فارغة
                        if (dataGridView1.Rows[e.RowIndex].Cells["CodeDent"].Value == null)
                        {
                            MessageBox.Show("Invalid tooth ID: The ID value is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // التحقق من أن قيمة المعرف هي رقم صحيح
                        int dentId;
                        string toothIdStr = dataGridView1.Rows[e.RowIndex].Cells["CodeDent"].Value.ToString();
                        if (!int.TryParse(toothIdStr, out dentId))
                        {
                            MessageBox.Show("Invalid tooth ID format: '" + toothIdStr + "'. Please ensure the ID is a valid number.", "Format Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // استخدام القيمة الرقمية
                        string index = dentId.ToString();

                        // التحقق مما إذا كان النقر على زر "تعديل"
                        if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Edit")
                        {
                            // استدعاء دالة تعديل السن
                            Edit_Click(index);
                        }
                        // التحقق مما إذا كان النقر على زر "حذف"
                        else if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Delete")
                        {
                            // استدعاء دالة حذف السن
                            Delete_Click(index);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Tooth ID column not found in the grid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        /// <summary>
        /// معالج حدث تغيير النص في حقل البحث بالوصف
        /// </summary>
        private void comments_TextChanged(object sender, EventArgs e)
        {
            // إنشاء استعلام للبحث عن الأسنان حسب الوصف
            String searchQuery = " SELECT * FROM Dent  Where   description like '#replace#%' ";

            // استبدال النص المؤقت بنص البحث الفعلي
            String result = searchQuery.Replace("#replace#", description.Text);

            // تحديث الجدول بنتائج البحث
            BindGrid(result);
        }

        /// <summary>
        /// معالج حدث النقر على زر إعادة تحميل البيانات
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            // إعادة تحميل جميع بيانات الأسنان
            BindGrid("SELECT * FROM Dent ");
        }
    }
}
