using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace MohamedNouriProject
{
    public partial class SimpleClientForm : Form
    {
        public SimpleClientForm()
        {
            InitializeComponent();

            // Add FormClosing event handler
            this.FormClosing += new FormClosingEventHandler(SimpleClientForm_FormClosing);

            // Set the form title and button text based on whether we're adding or editing
            if (ClientList.EditorAttribute)
            {
                this.Text = "Edit Client";
                addButton.Text = "Update";

                // Load client data if in edit mode
                LoadClientData(ClientList.iduser);
            }
            else
            {
                this.Text = "Add New Client";
                addButton.Text = "Add";

                // Clear all fields to ensure we're starting fresh
                ClearAllFields();
            }
        }

        /// <summary>
        /// Clears all input fields
        /// </summary>
        private void ClearAllFields()
        {
            nameTextBox.Text = "";
            lastNameTextBox.Text = "";
            emailTextBox.Text = "";
            phoneTextBox.Text = "";
            addressTextBox.Text = "";
            dobPicker.Value = DateTime.Now.AddYears(-30); // Default to 30 years ago
            maleRadio.Checked = true;
            professionTextBox.Text = "";
            allergiesTextBox.Text = "";
        }

        /// <summary>
        /// Loads client data for editing
        /// </summary>
        private void LoadClientData(string clientId)
        {
            try
            {
                string query = "SELECT * FROM Client WHERE CodeClient = @ClientID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ClientID", SqlDbType.VarChar) { Value = clientId }
                };

                DataTable dt = new DataTable();
                using (SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True"))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        foreach (SqlParameter parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    nameTextBox.Text = row["Name"].ToString();
                    lastNameTextBox.Text = row["LastName"].ToString();
                    emailTextBox.Text = row["Email"].ToString();
                    phoneTextBox.Text = row["TelNumber"].ToString();
                    addressTextBox.Text = row["Adresse"].ToString();

                    if (row["DateOfBirth"] != DBNull.Value)
                    {
                        dobPicker.Value = Convert.ToDateTime(row["DateOfBirth"]);
                    }

                    string gender = row["Sexe"].ToString();
                    maleRadio.Checked = (gender == "Male");
                    femaleRadio.Checked = (gender == "Female");

                    professionTextBox.Text = row["Profession"].ToString();
                    allergiesTextBox.Text = row["Allergies"].ToString();
                }
                else
                {
                    MessageBox.Show("Client not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading client data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SimpleClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Make sure the form actually closes and doesn't just hide
            this.Dispose();
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.addressLabel = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.dobLabel = new System.Windows.Forms.Label();
            this.dobPicker = new System.Windows.Forms.DateTimePicker();
            this.genderLabel = new System.Windows.Forms.Label();
            this.maleRadio = new System.Windows.Forms.RadioButton();
            this.femaleRadio = new System.Windows.Forms.RadioButton();
            this.professionLabel = new System.Windows.Forms.Label();
            this.professionTextBox = new System.Windows.Forms.TextBox();
            this.allergiesLabel = new System.Windows.Forms.Label();
            this.allergiesTextBox = new System.Windows.Forms.TextBox();
            this.addButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();

            // nameLabel
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(20, 20);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(80, 17);
            this.nameLabel.Text = "First Name";

            // nameTextBox
            this.nameTextBox.Location = new System.Drawing.Point(20, 40);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(350, 22);
            this.nameTextBox.TabIndex = 0;
            this.nameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.nameTextBox_Validating);

            // lastNameLabel
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(20, 70);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(76, 17);
            this.lastNameLabel.Text = "Last Name";

            // lastNameTextBox
            this.lastNameTextBox.Location = new System.Drawing.Point(20, 90);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(350, 22);
            this.lastNameTextBox.TabIndex = 1;
            this.lastNameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.lastNameTextBox_Validating);

            // emailLabel
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(20, 120);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(42, 17);
            this.emailLabel.Text = "Email";

            // emailTextBox
            this.emailTextBox.Location = new System.Drawing.Point(20, 140);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(350, 22);
            this.emailTextBox.TabIndex = 2;
            this.emailTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.emailTextBox_Validating);

            // phoneLabel
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(20, 170);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(103, 17);
            this.phoneLabel.Text = "Phone Number";

            // phoneTextBox
            this.phoneTextBox.Location = new System.Drawing.Point(20, 190);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(350, 22);
            this.phoneTextBox.TabIndex = 3;
            this.phoneTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.phoneTextBox_Validating);

            // addressLabel
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(20, 220);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(60, 17);
            this.addressLabel.Text = "Address";

            // addressTextBox
            this.addressTextBox.Location = new System.Drawing.Point(20, 240);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(350, 22);
            this.addressTextBox.TabIndex = 4;
            this.addressTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.addressTextBox_Validating);

            // dobLabel
            this.dobLabel.AutoSize = true;
            this.dobLabel.Location = new System.Drawing.Point(20, 270);
            this.dobLabel.Name = "dobLabel";
            this.dobLabel.Size = new System.Drawing.Size(90, 17);
            this.dobLabel.Text = "Date of Birth";

            // dobPicker
            this.dobPicker.Location = new System.Drawing.Point(20, 290);
            this.dobPicker.Name = "dobPicker";
            this.dobPicker.Size = new System.Drawing.Size(350, 22);
            this.dobPicker.TabIndex = 5;

            // genderLabel
            this.genderLabel.AutoSize = true;
            this.genderLabel.Location = new System.Drawing.Point(20, 320);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(56, 17);
            this.genderLabel.Text = "Gender";

            // maleRadio
            this.maleRadio.AutoSize = true;
            this.maleRadio.Checked = true;
            this.maleRadio.Location = new System.Drawing.Point(20, 340);
            this.maleRadio.Name = "maleRadio";
            this.maleRadio.Size = new System.Drawing.Size(59, 21);
            this.maleRadio.TabIndex = 6;
            this.maleRadio.TabStop = true;
            this.maleRadio.Text = "Male";
            this.maleRadio.UseVisualStyleBackColor = true;

            // femaleRadio
            this.femaleRadio.AutoSize = true;
            this.femaleRadio.Location = new System.Drawing.Point(100, 340);
            this.femaleRadio.Name = "femaleRadio";
            this.femaleRadio.Size = new System.Drawing.Size(75, 21);
            this.femaleRadio.TabIndex = 7;
            this.femaleRadio.Text = "Female";
            this.femaleRadio.UseVisualStyleBackColor = true;

            // professionLabel
            this.professionLabel.AutoSize = true;
            this.professionLabel.Location = new System.Drawing.Point(20, 370);
            this.professionLabel.Name = "professionLabel";
            this.professionLabel.Size = new System.Drawing.Size(79, 17);
            this.professionLabel.Text = "Profession";

            // professionTextBox
            this.professionTextBox.Location = new System.Drawing.Point(20, 390);
            this.professionTextBox.Name = "professionTextBox";
            this.professionTextBox.Size = new System.Drawing.Size(350, 22);
            this.professionTextBox.TabIndex = 8;
            this.professionTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.professionTextBox_Validating);

            // allergiesLabel
            this.allergiesLabel.AutoSize = true;
            this.allergiesLabel.Location = new System.Drawing.Point(20, 420);
            this.allergiesLabel.Name = "allergiesLabel";
            this.allergiesLabel.Size = new System.Drawing.Size(65, 17);
            this.allergiesLabel.Text = "Allergies";

            // allergiesTextBox
            this.allergiesTextBox.Location = new System.Drawing.Point(20, 440);
            this.allergiesTextBox.Multiline = true;
            this.allergiesTextBox.Name = "allergiesTextBox";
            this.allergiesTextBox.Size = new System.Drawing.Size(350, 60);
            this.allergiesTextBox.TabIndex = 9;

            // addButton
            this.addButton.BackColor = System.Drawing.SystemColors.HotTrack;
            this.addButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addButton.Location = new System.Drawing.Point(20, 520);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(350, 40);
            this.addButton.TabIndex = 10;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);

            // cancelButton
            this.cancelButton.Location = new System.Drawing.Point(20, 570);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(350, 40);
            this.cancelButton.TabIndex = 11;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);

            // errorProvider
            this.errorProvider.ContainerControl = this;

            // SimpleClientForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 630);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(this.dobLabel);
            this.Controls.Add(this.dobPicker);
            this.Controls.Add(this.genderLabel);
            this.Controls.Add(this.maleRadio);
            this.Controls.Add(this.femaleRadio);
            this.Controls.Add(this.professionLabel);
            this.Controls.Add(this.professionTextBox);
            this.Controls.Add(this.allergiesLabel);
            this.Controls.Add(this.allergiesTextBox);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.cancelButton);
            this.Name = "SimpleClientForm";
            this.Text = "Add New Client";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void nameTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(nameTextBox, e);
        }

        private void lastNameTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(lastNameTextBox, e);
        }

        private void emailTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(emailTextBox, e);
        }

        private void phoneTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(phoneTextBox, e);
        }

        private void addressTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(addressTextBox, e);
        }

        private void professionTextBox_Validating(object sender, CancelEventArgs e)
        {
            ValidateField(professionTextBox, e);
        }

        private void ValidateField(TextBox textBox, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                e.Cancel = true;
                textBox.Focus();
                errorProvider.SetError(textBox, "This field cannot be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(textBox, "");
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                string gender = maleRadio.Checked ? "Male" : "Female";

                try
                {
                    if (ClientList.EditorAttribute)
                    {
                        UpdateClient(ClientList.iduser, nameTextBox.Text, lastNameTextBox.Text, dobPicker.Value.Date,
                            gender, addressTextBox.Text, professionTextBox.Text, phoneTextBox.Text,
                            emailTextBox.Text, allergiesTextBox.Text);
                    }
                    else
                    {
                        InsertClient(nameTextBox.Text, lastNameTextBox.Text, dobPicker.Value.Date,
                            gender, addressTextBox.Text, professionTextBox.Text, phoneTextBox.Text,
                            emailTextBox.Text, allergiesTextBox.Text);
                    }

                    // Reset the editor attribute after completing the operation
                    ClientList.EditorAttribute = false;
                    ClientList.iduser = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error processing client data: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please check your input and try again!", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            // Reset the editor attribute
            ClientList.EditorAttribute = false;
            ClientList.iduser = "";

            // Directly dispose and close the form
            this.Dispose();
            this.Close();
        }

        private void UpdateClient(string id, string firstName, string lastName, DateTime dateOfBirth,
            string gender, string address, string profession, string phone, string email, string allergies)
        {
            string query = "UPDATE Client SET Name = @CLIENT_Name, LastName = @CLIENT_LastName, " +
                "DateOfBirth = @CLIENT_DateOfBirth, Sexe = @CLIENT_SEXE, Adresse = @CLIENT_Adresse, " +
                "Profession = @CLIENT_Profession, TelNumber = @CLIENT_TelNumber, Email = @CLIENT_Email, " +
                "Allergies = @CLIENT_Allergies, Status = 'Active' WHERE CodeClient = @fn";

            using (SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True"))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CLIENT_Name", firstName);
                        command.Parameters.AddWithValue("@CLIENT_LastName", lastName);
                        command.Parameters.AddWithValue("@CLIENT_SEXE", gender);
                        command.Parameters.AddWithValue("@CLIENT_DateOfBirth", dateOfBirth);
                        command.Parameters.AddWithValue("@CLIENT_Adresse", address);
                        command.Parameters.AddWithValue("@CLIENT_Profession", profession);
                        command.Parameters.AddWithValue("@CLIENT_TelNumber", phone);
                        command.Parameters.AddWithValue("@CLIENT_Email", email);
                        command.Parameters.AddWithValue("@CLIENT_Allergies", allergies);
                        command.Parameters.AddWithValue("@fn", id);

                        if (command.ExecuteNonQuery() == 0)
                        {
                            throw new ApplicationException("No rows were updated. Please check your parameters!");
                        }
                        else
                        {
                            MessageBox.Show("Client updated successfully!", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Reset the editor attribute
                            ClientList.EditorAttribute = false;
                            ClientList.iduser = "";

                            // Directly dispose and close the form
                            this.Dispose();
                            this.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating client: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void InsertClient(string firstName, string lastName, DateTime dateOfBirth,
            string gender, string address, string profession, string phone, string email, string allergies)
        {
            string query = "INSERT INTO Client (Name, LastName, DateOfBirth, Sexe, Adresse, Profession, " +
                "TelNumber, Email, Allergies, CreatedAt, Status) VALUES (" +
                "@CLIENT_Name, @CLIENT_LastName, @CLIENT_DateOfBirth, @CLIENT_SEXE, @CLIENT_Adresse, " +
                "@CLIENT_Profession, @CLIENT_TelNumber, @CLIENT_Email, @CLIENT_Allergies, " +
                "@CLIENT_CreatedAt, @CLIENT_Status)";

            using (SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True"))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CLIENT_Name", firstName);
                        command.Parameters.AddWithValue("@CLIENT_LastName", lastName);
                        command.Parameters.AddWithValue("@CLIENT_SEXE", gender);
                        command.Parameters.AddWithValue("@CLIENT_DateOfBirth", dateOfBirth);
                        command.Parameters.AddWithValue("@CLIENT_Adresse", address);
                        command.Parameters.AddWithValue("@CLIENT_Profession", profession);
                        command.Parameters.AddWithValue("@CLIENT_TelNumber", phone);
                        command.Parameters.AddWithValue("@CLIENT_Email", email);
                        command.Parameters.AddWithValue("@CLIENT_Allergies", allergies);
                        command.Parameters.AddWithValue("@CLIENT_CreatedAt", DateTime.Now);
                        command.Parameters.AddWithValue("@CLIENT_Status", "Active");

                        if (command.ExecuteNonQuery() == 0)
                        {
                            throw new ApplicationException("No rows were inserted. Please check your parameters!");
                        }
                        else
                        {
                            MessageBox.Show("Client created successfully!", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Reset the editor attribute
                            ClientList.EditorAttribute = false;
                            ClientList.iduser = "";

                            // Directly dispose and close the form
                            this.Dispose();
                            this.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating client: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label dobLabel;
        private System.Windows.Forms.DateTimePicker dobPicker;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.RadioButton maleRadio;
        private System.Windows.Forms.RadioButton femaleRadio;
        private System.Windows.Forms.Label professionLabel;
        private System.Windows.Forms.TextBox professionTextBox;
        private System.Windows.Forms.Label allergiesLabel;
        private System.Windows.Forms.TextBox allergiesTextBox;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider;

        // Override Dispose to clean up the component list
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
