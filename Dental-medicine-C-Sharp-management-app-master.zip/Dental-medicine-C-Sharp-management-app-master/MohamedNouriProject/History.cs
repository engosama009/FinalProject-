﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Excel = Microsoft.Office.Interop.Excel;
using MohamedNouriProject.db;
namespace MohamedNouriProject
{
    public partial class History : UserControl
    {
        public History()
        {
            InitializeComponent();

            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            BindGrid("");

            DataGridViewButtonColumn Deletelink = new DataGridViewButtonColumn();

            Deletelink.HeaderText = "Delete";
            Deletelink.DataPropertyName = "lnkColumn";

           Deletelink.Text = "Delete";




            Deletelink.UseColumnTextForButtonValue = true;

            dataGridView2.Columns.Add(Deletelink);



        }
        /// <summary>
        /// Event handler for cell click in the grid
        /// </summary>
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Make sure the click is not on the column header
            if (e.RowIndex >= 0)
            {
                try
                {
                    // Get intervention ID from the CodeInt column (first column)
                    string interventionId = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();

                    // If the Delete button was clicked
                    if (dataGridView2.Columns[e.ColumnIndex].HeaderText == "Delete")
                    {
                        // Call the delete intervention function
                        Delete_Click(interventionId);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error accessing intervention data: " + ex.Message,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        /// <summary>
        /// Delete an intervention record from the database
        /// </summary>
        /// <param name="ID">ID of the intervention to delete</param>
        private void Delete_Click(string ID)
        {
            // Display confirmation message before deletion
            DialogResult dr = MessageBox.Show("Are you sure you want to delete intervention record " + ID + "?",
                "Delete Intervention", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);



            // If user confirmed deletion
            if (dr == DialogResult.Yes)
            {
                //

                // Use parameters to prevent SQL Injection
                String query = "DELETE FROM Interventions WHERE CodeInt = @CodeInt";

                try
                {
                    // Create parameters array
                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@CodeInt", SqlDbType.Int) { Value = int.Parse(ID) }
                    };

                    // Use DatabaseConnection class to execute the command
                    int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                    // Check if deletion was successful
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Intervention record deleted successfully", "Delete Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Update grid after deletion
                        BindGrid("");
                    }
                    else
                    {
                        MessageBox.Show("No records were deleted. The record may have been deleted already.",
                            "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message,
                        "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Invalid ID format. Please try again.",
                        "Format Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message,
                        "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }



        }
        // Using DatabaseConnection class instead of defining connection string here



        private void BindGrid(String query)
        {

            // Build the query
            string sqlQuery = "SELECT Interventions.CodeInt,Interventions.Date, Client.CodeClient,Client.Name,Client.LastName FROM Interventions INNER JOIN Client ON Interventions.CodeClient = Client.CodeClient " + query + "ORDER BY Interventions.Date";

            // Use DatabaseConnection class to execute the query
            DataTable dt = DatabaseConnection.ExecuteQuery(sqlQuery);

            // Display result count
            totlaNumbre.Text = dt.Rows.Count.ToString();

            // Set data source for the grid
            dataGridView2.DataSource = dt;

            // Change column headers to English
            if (dataGridView2.Columns.Contains("CodeInt"))
                dataGridView2.Columns["CodeInt"].HeaderText = "Intervention ID";

            if (dataGridView2.Columns.Contains("Date"))
                dataGridView2.Columns["Date"].HeaderText = "Date";

            if (dataGridView2.Columns.Contains("CodeClient"))
                dataGridView2.Columns["CodeClient"].HeaderText = "Client ID";

            if (dataGridView2.Columns.Contains("Name"))
                dataGridView2.Columns["Name"].HeaderText = "First Name";

            if (dataGridView2.Columns.Contains("LastName"))
                dataGridView2.Columns["LastName"].HeaderText = "Last Name";
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (stardatev.Value == DateTimePicker.MinimumDateTime)
            {
                stardatev.Value = DateTime.Now; // This is required in order to show current month/year when user reopens the date popup.
                stardatev.Format = DateTimePickerFormat.Custom;
                stardatev.CustomFormat = " ";
            }
            else
            {
                stardatev.Format = DateTimePickerFormat.Short;
            }
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            stardatev.Value = DateTimePicker.MinimumDateTime;
        }

        private void CodeClient_TextChanged(object sender, EventArgs e)
        {
            String query = " Where  Interventions.CodeInt like '#replace#%' ";


            var result = query.Replace("#replace#", CodeRDV.Text);

            BindGrid(result);
        }

        private void NomClient_TextChanged(object sender, EventArgs e)
        {
            String query = " Where  Client.Name like '#replace#%' OR  Client.LastName like '#replace#%' ";


            var result = query.Replace("#replace#", NomClient.Text);

            BindGrid(result);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            String query = " where Interventions.Date between '" + stardatev.Value  + "'AND'" + EndDate.Value  + "'";
            BindGrid(query);
        }

        private void EndDate_ValueChanged(object sender, EventArgs e)
        {
            String query = " where Date between '" + stardatev.Value + "' AND'" + EndDate.Value + "'";
            BindGrid(query);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BindGrid("");
        }

        /// <summary>
        /// Export DataGridView data to Excel
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if there's data to export
                if (dataGridView2.Rows.Count == 0)
                {
                    MessageBox.Show("No data to export to Excel.", "Export Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Create Excel objects
                Microsoft.Office.Interop.Excel.Application xlexcel;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                // Initialize Excel application and make it visible
                xlexcel = new Excel.Application();
                xlexcel.Visible = true;

                // Create a new workbook and worksheet
                xlWorkBook = xlexcel.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                // Add column headers
                for (int i = 0; i < dataGridView2.Columns.Count - 1; i++) // Skip the Delete button column
                {
                    xlWorkSheet.Cells[1, i + 1] = dataGridView2.Columns[i].HeaderText;
                    // Format header cells
                    ((Excel.Range)xlWorkSheet.Cells[1, i + 1]).Font.Bold = true;
                }

                // Add data rows
                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView2.Columns.Count - 1; j++) // Skip the Delete button column
                    {
                        // Check if the cell value is not null
                        if (dataGridView2.Rows[i].Cells[j].Value != null)
                        {
                            xlWorkSheet.Cells[i + 2, j + 1] = dataGridView2.Rows[i].Cells[j].Value.ToString();
                        }
                        else
                        {
                            xlWorkSheet.Cells[i + 2, j + 1] = "";
                        }
                    }
                }

                // Format the data
                xlWorkSheet.Columns.AutoFit();

                // Apply borders to the data
                Excel.Range dataRange = xlWorkSheet.Range[xlWorkSheet.Cells[1, 1],
                    xlWorkSheet.Cells[dataGridView2.Rows.Count + 1, dataGridView2.Columns.Count]];
                dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                dataRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                // Set the first row as header
                Excel.Range headerRange = xlWorkSheet.Range[xlWorkSheet.Cells[1, 1],
                    xlWorkSheet.Cells[1, dataGridView2.Columns.Count - 1]];
                headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);

                // Select cell A1
                xlWorkSheet.Cells[1, 1].Select();

                // Show success message
                MessageBox.Show("Data exported to Excel successfully!", "Export Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting to Excel: " + ex.Message, "Export Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        /// <summary>
        /// Copy all grid data to clipboard
        /// Note: This method is kept for potential future use but is no longer used for Excel export
        /// </summary>
        private void copyAlltoClipboard()
        {
            try
            {
                // Hide row headers before copying
                dataGridView2.RowHeadersVisible = false;

                // Select all cells
                dataGridView2.SelectAll();

                // Get clipboard content
                DataObject dataObj = dataGridView2.GetClipboardContent();

                // Copy data to clipboard if available
                if (dataObj != null)
                {
                    Clipboard.SetDataObject(dataObj);
                }
                else
                {
                    MessageBox.Show("No data available to copy to clipboard.", "Export Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error copying data to clipboard: " + ex.Message, "Copy Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
