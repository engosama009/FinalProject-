﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using MohamedNouriProject.db;

namespace MohamedNouriProject
{
    /// <summary>
    /// Login window for the application
    /// </summary>
    public partial class Authentification : Form
    {
        /// <summary>
        /// Current username
        /// </summary>
        public string usernameValue
        {
            get { return "Ahmed"; }
        }


        public Authentification()
        {
            // Initialize UI components
            InitializeComponent();

            // Automatically select the username field
            this.login.Select();

            // Initialize password field
            password.Text = "";
            // Set asterisk character to hide password
            password.PasswordChar = '*';
            // Set maximum password length
            password.MaxLength = 14;

            // Add FormClosing event handler to properly close the application
            this.FormClosing += new FormClosingEventHandler(Authentification_FormClosing);
        }

        /// <summary>
        /// Event handler for form closing
        /// </summary>
        private void Authentification_FormClosing(object sender, FormClosingEventArgs e)
        {
            // If this is the main form and user clicked X, exit the application
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit();
            }
        }

        /// <summary>
        /// Called when the window is shown
        /// </summary>
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
        }

        /// <summary>
        /// Event handler for login button click
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            // Validate input data
            if (ValidateChildren(ValidationConstraints.Selectable))
            {
                // Attempt to login
                loginUser();
            }
        }



        /// <summary>
        /// Validate user credentials and attempt to login
        /// </summary>
        private void loginUser()
        {
            try
            {
                // SQL query to validate user credentials (no longer used directly)
                string query = "SELECT role from Users WHERE Login = @username and Password=@password";
                string returnValue = "";

                try
                {
                    // Use UserManager class to validate user credentials
                    returnValue = UserManager.AuthenticateUser(login.Text, password.Text);

                    // Check if a result was found
                    if (String.IsNullOrEmpty(returnValue))
                    {
                        // Display error message if login credentials are incorrect
                        MessageBox.Show("Incorrect username or password");
                        return;
                    }

                    // Trim extra spaces from user role
                    returnValue = returnValue.Trim();

                    // Check user role
                    if (returnValue == "Admin")
                    {
                        // Open admin home page
                        Home fr1 = new Home();
                        fr1.usernameValue = login.Text; // Use username instead of role
                        fr1.Show();
                        this.Hide();
                    }
                    else
                    {
                        // Open home page for any other role
                        Home fr1 = new Home();
                        fr1.usernameValue = login.Text;
                        fr1.Show();
                        this.Hide();
                    }
                    // More roles can be added here
                    // Example: else if (returnValue == "User") { ... }
                }
                catch (SqlException ex)
                {
                    // Display error message if there is a database problem
                    MessageBox.Show("Database error: " + ex.Message,
                        "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                // Display error message if there is a general problem
                MessageBox.Show("An error occurred during login: " + ex.Message,
                    "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Comment: The following code is currently disabled and can be used to add support for regular user role
        //else if (returnValue == "User")
        //{
        //  MessageBox.Show("You are logged in as a User");
        //  UserHome fr2 = new UserHome();
        //  fr2.Show();
        //  this.Hide();
        //}

        /// <summary>
        /// Event handler for additional button click (not currently used)
        /// </summary>
        private void button1_Click_1(object sender, EventArgs e)
        {
            // No specific action
        }

        /// <summary>
        /// Validate username field
        /// </summary>
        private void userLogin_Validating(object sender, CancelEventArgs e)
        {
            // Check that username field is not empty
            if (string.IsNullOrWhiteSpace(login.Text))
            {
                // Cancel operation and display error message
                e.Cancel = true;
                login.Focus();
                errorProviderApp.SetError(login, "login should not be left blank!");
                erroLogin.Text = "Login should not be left blank!";
            }
            else
            {
                // Remove error message if field is valid
                e.Cancel = false;
                errorProviderApp.SetError(login, "");
                erroLogin.Text = "";
            }
        }

        /// <summary>
        /// Validate password field
        /// </summary>
        private void userpassword_Validating(object sender, CancelEventArgs e)
        {
            // Check that password field is not empty
            if (string.IsNullOrWhiteSpace(password.Text))
            {
                // Cancel operation and display error message
                e.Cancel = true;
                password.Focus();
                errorProviderApp.SetError(password, "Name should not be left blank!");
                errorpassword.Text = "password should not be left blank!";
            }
            else
            {
                // Remove error message if field is valid
                e.Cancel = false;
                errorProviderApp.SetError(password, "");
                errorpassword.Text = "";
            }
        }

        /// <summary>
        /// Layout panel paint event handler (not currently used)
        /// </summary>
        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {
            // No specific action
        }

        /// <summary>
        /// Event handler for the show password checkbox
        /// </summary>
        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            // Toggle password character visibility based on checkbox state
            if (showPasswordCheckBox.Checked)
            {
                // Show password as plain text
                password.PasswordChar = '\0';
            }
            else
            {
                // Hide password with asterisks
                password.PasswordChar = '*';
            }
        }
    }
}
