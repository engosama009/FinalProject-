﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using MohamedNouriProject.Resources;
using MohamedNouriProject.Utils;
using Excel = Microsoft.Office.Interop.Excel;
using MohamedNouriProject.db;
namespace MohamedNouriProject
{
    public partial class Oppointment : UserControl
    {

        // استخدام كلاس DatabaseConnection بدلاً من تعريف سلسلة الاتصال هنا




        public static Boolean EditorAttribute = false;
        public static string iduser = "";
        public static string CodeClientS = "";



        public Oppointment()
        {



            InitializeComponent();


            BindGrid("");



            DataGridViewButtonColumn bcol = new DataGridViewButtonColumn();
            bcol.HeaderText = "Delete";
            bcol.Text = "Delete";
            bcol.Name = "Delete";
            bcol.UseColumnTextForButtonValue = true;
            bcol.DataPropertyName = "lnkColumn";




            DataGridViewButtonColumn MD = new DataGridViewButtonColumn();
            MD.HeaderText = "Edit";
            MD.Text = "Edit";
            MD.DataPropertyName = "lnkColumn";
            MD.Name = "Edit";
            MD.UseColumnTextForButtonValue = true;



            DataGridViewButtonColumn regler = new DataGridViewButtonColumn();
            regler.HeaderText = "Pay";
            regler.Text = "Pay";
            regler.DataPropertyName = "lnkColumn";
            regler.Name = "Pay";
            regler.UseColumnTextForButtonValue = true;

            dataGridView1.Columns.Add(regler);
            dataGridView1.Columns.Add(MD);
            dataGridView1.Columns.Add(bcol);






            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


        }




        private void  Delete_Click(string ID)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to delete " + ID, "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);



            if (dr == DialogResult.Yes)
            {
                //

                // استخدام معلمات لمنع SQL Injection
                String query = "DELETE FROM RDV WHERE CodeRDV = @CodeRDV";

                try
                {
                    // إنشاء مصفوفة المعلمات
                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@CodeRDV", SqlDbType.Int) { Value = int.Parse(ID) }
                    };

                    // استخدام كلاس DatabaseConnection لتنفيذ الأمر
                    int rowsAffected = DatabaseConnection.ExecuteNonQuery(query, parameters);

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Delete successful");
                        // تحديث الجدول بعد الحذف
                        BindGrid("");
                    }
                    else
                    {
                        MessageBox.Show("No records were deleted");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Invalid ID format");
                }


            }



        }


        private void Edit_Click(string ID)
        {

            AddAnOppointment fr1 = new AddAnOppointment();



            fr1.Show();

        }
        private void Reg_Click(string ID)
        {

            AddIntervontion fr1 = new AddIntervontion();


            fr1.Show();

        }
        void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {

        }

        private void Oppointment_Load(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {


                int orderno = 0;
                Int32.TryParse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString(), out orderno);



                if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Edit")
            {
                string index = dataGridView1.Rows[e.RowIndex].Cells["CodeRDV"].Value.ToString();
                    EditorAttribute = true;
                iduser = index;

                Edit_Click(index);

            }


            if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Delete")
            {
                string index = dataGridView1.Rows[e.RowIndex].Cells["CodeRDV"].Value.ToString();


                    Delete_Click(index);
            }

            if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Pay")
            {
                    EditorAttribute = true;

                    string id = dataGridView1.Rows[e.RowIndex].Cells["CodeRDV"].Value.ToString();
                    iduser = id;
                    string code = dataGridView1.Rows[e.RowIndex].Cells["CodeClient"].Value.ToString();
                    CodeClientS = code;

                    Reg_Click(CodeClientS);
            }


            }



        }
        private void BindGrid(String query)
        {
           // this.dataGridView1.DataSource = null;
           //  this.dataGridView1.Rows.Clear();

            //ORDER BY RDV.DateRDV , RDV.Time
            // بناء الاستعلام
            string sqlQuery = "SELECT CodeRDV, Client.CodeClient, Name, LastName, Time, Comments FROM RDV INNER JOIN Client ON RDV.ClientID = Client.CodeClient";

            // إضافة شرط WHERE إذا كان موجودًا
            if (!string.IsNullOrEmpty(query))
            {
                sqlQuery += " WHERE " + query;
            }

            // استخدام كلاس DatabaseConnection لتنفيذ الاستعلام
            DataTable dt = DatabaseConnection.ExecuteQuery(sqlQuery);

            // تعيين مصدر البيانات للجدول
            dataGridView1.DataSource = dt;

            // تغيير عناوين الأعمدة إلى اللغة الإنجليزية
            if (dataGridView1.Columns.Contains("CodeRDV"))
                dataGridView1.Columns["CodeRDV"].HeaderText = "Appointment ID";

            if (dataGridView1.Columns.Contains("CodeClient"))
                dataGridView1.Columns["CodeClient"].HeaderText = "Client ID";

            if (dataGridView1.Columns.Contains("Name"))
                dataGridView1.Columns["Name"].HeaderText = "First Name";

            if (dataGridView1.Columns.Contains("LastName"))
                dataGridView1.Columns["LastName"].HeaderText = "Last Name";

            if (dataGridView1.Columns.Contains("Time"))
                dataGridView1.Columns["Time"].HeaderText = "Time";

            if (dataGridView1.Columns.Contains("Comments"))
                dataGridView1.Columns["Comments"].HeaderText = "Comments";

            // عرض عدد النتائج
            totlaNumbre.Text = dt.Rows.Count.ToString();
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void telNumber_TextChanged(object sender, EventArgs e)
        {
            // Buscar por código de cita
            if (string.IsNullOrEmpty(CodeClient.Text))
            {
                // Si el campo está vacío, mostrar todos los registros
                BindGrid("");
                return;
            }

            String query = "RDV.CodeRDV LIKE '" + CodeClient.Text + "%'";
            BindGrid(query);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)


        {

            // Buscar por nombre del cliente
            if (string.IsNullOrEmpty(comments.Text))
            {
                // Si el campo está vacío, mostrar todos los registros
                BindGrid("");
                return;
            }

            String query = "Client.Name LIKE '" + comments.Text + "%'";
            BindGrid(query);






        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {






            foreach (DataGridViewRow Myrow in dataGridView1.Rows)

            {

                String valur = Myrow.Cells[1].Value.ToString();

                if (valur.Length > 1)
                {
                    Myrow.DefaultCellStyle.BackColor = Color.AliceBlue;
                }
                else
                {
                    Myrow.DefaultCellStyle.BackColor = Color.IndianRed;
                }
            }





        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt = this.dateTimePicker1.Value.Date;

            // Formato de fecha para SQL Server (yyyy-MM-dd)
            string formattedDate = dt.ToString("yyyy-MM-dd");

            // Usar parámetros para evitar problemas de formato de fecha
            String query = "RDV.DateRDV = '" + formattedDate + "'";

            BindGrid(query);
        }

        private void hommeRadio_CheckedChanged(object sender, EventArgs e)
        {

            String query = "Client.Sexe Like 'Male%' ";




            BindGrid(query);
        }

        private void radioFemme_CheckedChanged(object sender, EventArgs e)
        {
            String query = "Client.Sexe Like 'Female%' ";




            BindGrid(query);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // This method is intentionally left empty
            // The following code is commented out as it was unreachable
            /*
            AddIntervontion usersList = new AddIntervontion();
            usersList.Show();
            */
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Get the client ID from the selected row
                string clientId = dataGridView1.Rows[e.RowIndex].Cells["CodeClient"].Value.ToString();

                // Show detailed information for the selected client
                ShowClientDetails(clientId);
            }
        }

        private void ShowClientDetails(string clientId)
        {
            try
            {
                // Build the query to get detailed client information
                string query = @"SELECT
                                    Client.*,
                                    RDV.CodeRDV,
                                    RDV.DateRDV,
                                    RDV.Time,
                                    RDV.Comments
                                FROM
                                    Client
                                LEFT JOIN
                                    RDV ON Client.CodeClient = RDV.ClientID
                                WHERE
                                    Client.CodeClient = @ClientID";

                // Create parameters
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ClientID", SqlDbType.VarChar) { Value = clientId }
                };

                // Execute the query
                DataTable dt = DatabaseConnection.ExecuteQuery(query, parameters);

                if (dt.Rows.Count > 0)
                {
                    // Create a form to display the detailed information
                    Form detailsForm = new Form();
                    detailsForm.Text = "Client Details";
                    detailsForm.Size = new Size(500, 400);
                    detailsForm.StartPosition = FormStartPosition.CenterScreen;

                    // Create a TableLayoutPanel to organize the information
                    TableLayoutPanel panel = new TableLayoutPanel();
                    panel.Dock = DockStyle.Fill;
                    panel.ColumnCount = 2;
                    panel.RowCount = 10;
                    panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
                    panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));

                    // Add client information to the panel
                    DataRow row = dt.Rows[0];

                    AddDetailRow(panel, 0, "Client ID:", row["CodeClient"].ToString());
                    AddDetailRow(panel, 1, "Name:", row["Name"].ToString());
                    AddDetailRow(panel, 2, "Last Name:", row["LastName"].ToString());
                    AddDetailRow(panel, 3, "Date of Birth:", Convert.ToDateTime(row["DateOfBirth"]).ToShortDateString());
                    AddDetailRow(panel, 4, "Gender:", row["Sexe"].ToString());
                    AddDetailRow(panel, 5, "Address:", row["Adresse"].ToString());
                    AddDetailRow(panel, 6, "Profession:", row["Profession"].ToString());
                    AddDetailRow(panel, 7, "Phone:", row["TelNumber"].ToString());
                    AddDetailRow(panel, 8, "Email:", row["Email"].ToString());
                    AddDetailRow(panel, 9, "Allergies:", row["Allergies"].ToString());

                    // Add appointment information if available
                    if (row["CodeRDV"] != DBNull.Value)
                    {
                        AddDetailRow(panel, 10, "Appointment ID:", row["CodeRDV"].ToString());
                        AddDetailRow(panel, 11, "Appointment Date:", Convert.ToDateTime(row["DateRDV"]).ToShortDateString());
                        AddDetailRow(panel, 12, "Appointment Time:", row["Time"].ToString());
                        AddDetailRow(panel, 13, "Comments:", row["Comments"].ToString());
                    }

                    // Add a close button
                    Button closeButton = new Button();
                    closeButton.Text = "Close";
                    closeButton.Dock = DockStyle.Bottom;
                    closeButton.Click += (s, e) => detailsForm.Close();

                    // Add controls to the form
                    detailsForm.Controls.Add(panel);
                    detailsForm.Controls.Add(closeButton);

                    // Show the form
                    detailsForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Client not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving client details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddDetailRow(TableLayoutPanel panel, int rowIndex, string label, string value)
        {
            // Create label control
            Label lblControl = new Label();
            lblControl.Text = label;
            lblControl.Font = new Font(lblControl.Font, FontStyle.Bold);
            lblControl.Dock = DockStyle.Fill;

            // Create value control
            Label valueControl = new Label();
            valueControl.Text = value;
            valueControl.Dock = DockStyle.Fill;

            // Add controls to the panel
            panel.Controls.Add(lblControl, 0, rowIndex);
            panel.Controls.Add(valueControl, 1, rowIndex);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Check if there's data to export
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("No data to export.", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Excel.Application xlApp = null;
            Excel.Workbook xlWorkbook = null;
            Excel.Worksheet xlWorksheet = null;

            try
            {
                // Create Excel application
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false; // Disable alerts
                xlApp.Visible = true;

                // Create a new workbook
                xlWorkbook = xlApp.Workbooks.Add(Type.Missing);
                xlWorksheet = (Excel.Worksheet)xlWorkbook.Worksheets.get_Item(1);

                // Add column headers
                int colIndex = 1;
                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    if (dataGridView1.Columns[i] is DataGridViewButtonColumn)
                        continue; // Skip button columns

                    xlWorksheet.Cells[1, colIndex] = dataGridView1.Columns[i].HeaderText;
                    colIndex++;
                }

                // Add data rows
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    colIndex = 1;
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (dataGridView1.Columns[j] is DataGridViewButtonColumn)
                            continue; // Skip button columns

                        if (dataGridView1.Rows[i].Cells[j].Value != null)
                        {
                            // Convert values to appropriate types for Excel
                            object cellValue = dataGridView1.Rows[i].Cells[j].Value;
                            if (cellValue is DateTime)
                            {
                                xlWorksheet.Cells[i + 2, colIndex] = ((DateTime)cellValue).ToShortDateString();
                            }
                            else
                            {
                                xlWorksheet.Cells[i + 2, colIndex] = cellValue.ToString();
                            }
                        }
                        colIndex++;
                    }
                }

                // Format as a table with headers (with error handling)
                Excel.Range range = null;
                Excel.Range headerRow = null;

                try
                {
                    // Get the used range
                    range = xlWorksheet.UsedRange;

                    // Apply borders if range is valid
                    if (range != null)
                    {
                        range.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                        range.Borders.Weight = Excel.XlBorderWeight.xlThin;
                    }

                    // Format header row
                    headerRow = xlWorksheet.get_Range("A1", Type.Missing);
                    if (headerRow != null)
                    {
                        // Find the last used column in row 1
                        int lastCol = 0;
                        for (int i = 1; i <= 100; i++) // Reasonable limit
                        {
                            if (xlWorksheet.Cells[1, i].Value == null)
                            {
                                lastCol = i - 1;
                                break;
                            }
                        }

                        if (lastCol > 0)
                        {
                            // Get the header range from A1 to the last column
                            string lastColLetter = GetExcelColumnName(lastCol);
                            headerRow = xlWorksheet.get_Range("A1", lastColLetter + "1");

                            // Apply formatting
                            headerRow.Font.Bold = true;
                            headerRow.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                        }
                    }

                    // Auto-fit columns
                    xlWorksheet.Columns.AutoFit();
                }
                catch (Exception ex)
                {
                    // Log the error but continue with export
                    System.Diagnostics.Debug.WriteLine("Error formatting Excel: " + ex.Message);
                }
                finally
                {
                    // Clean up any COM objects created during formatting
                    try
                    {
                        if (headerRow != null && System.Runtime.InteropServices.Marshal.IsComObject(headerRow))
                        {
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(headerRow);
                            headerRow = null;
                        }

                        if (range != null && System.Runtime.InteropServices.Marshal.IsComObject(range))
                        {
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(range);
                            range = null;
                        }
                    }
                    catch
                    {
                        // Ignore errors during cleanup
                    }
                }

                // Save the workbook
                string fileName = "Appointments_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";
                string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + fileName;

                try
                {
                    // Use proper SaveAs with all parameters to avoid COM issues
                    xlWorkbook.SaveAs(
                        filePath,                  // Filename
                        Type.Missing,              // FileFormat
                        Type.Missing,              // Password
                        Type.Missing,              // WriteResPassword
                        false,                     // ReadOnlyRecommended
                        false,                     // CreateBackup
                        Excel.XlSaveAsAccessMode.xlNoChange, // AccessMode
                        Type.Missing,              // ConflictResolution
                        false,                     // AddToMru
                        Type.Missing,              // TextCodepage
                        Type.Missing,              // TextVisualLayout
                        Type.Missing               // Local
                    );

                    MessageBox.Show("Data exported successfully to " + filePath, "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving Excel file: " + ex.Message, "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting data to Excel: " + ex.Message, "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Clean up COM resources to prevent memory leaks
                try
                {
                    // Release all Excel objects in reverse order
                    // First check if they're null to avoid NullReferenceException

                    // Release any other Excel objects that might have been created
                    Excel.Range range = null;
                    Excel.Range headerRow = null;

                    // Release worksheet
                    if (xlWorksheet != null)
                    {
                        try
                        {
                            // Make sure we're not trying to release a null object
                            if (System.Runtime.InteropServices.Marshal.IsComObject(xlWorksheet))
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorksheet);
                        }
                        catch (Exception) { /* Ignore errors during cleanup */ }
                        xlWorksheet = null;
                    }

                    // Close and release workbook
                    if (xlWorkbook != null)
                    {
                        try
                        {
                            // Only try to close if Excel app is still running
                            if (xlApp != null)
                                xlWorkbook.Close(false); // Don't save changes

                            // Make sure we're not trying to release a null object
                            if (System.Runtime.InteropServices.Marshal.IsComObject(xlWorkbook))
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkbook);
                        }
                        catch (Exception) { /* Ignore errors during cleanup */ }
                        xlWorkbook = null;
                    }

                    // Quit and release Excel application
                    if (xlApp != null)
                    {
                        try
                        {
                            xlApp.Quit();

                            // Make sure we're not trying to release a null object
                            if (System.Runtime.InteropServices.Marshal.IsComObject(xlApp))
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                        }
                        catch (Exception) { /* Ignore errors during cleanup */ }
                        xlApp = null;
                    }
                }
                catch (Exception)
                {
                    // Ignore any errors in cleanup process
                }
                finally
                {
                    // Force garbage collection twice to ensure COM objects are released
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }





        private void button2_Click(object sender, EventArgs e)
        {
            BindGrid("");
        }

        /// <summary>
        /// تصدير بيانات المواعيد إلى PDF
        /// </summary>
        private void exportPdfButton_Click(object sender, EventArgs e)
        {
            try
            {
                // التحقق من وجود بيانات للتصدير
                if (dataGridView1.Rows.Count == 0)
                {
                    MessageBox.Show("لا توجد بيانات للتصدير.", "خطأ في التصدير", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // تغيير مؤشر الماوس إلى علامة الانتظار
                Cursor.Current = Cursors.WaitCursor;

                try
                {
                    // تصدير البيانات مباشرة إلى PDF
                    string pdfPath = DirectPdfExporter.ExportDataGridViewToPdf(
                        dataGridView1,
                        "قائمة المواعيد",
                        DateTime.Now.ToString("yyyyMMdd"),
                        WordExporter.TAB_APPOINTMENTS);

                    // لا حاجة لعرض رسالة نجاح هنا لأنها تُعرض في الدالة ExportDataGridViewToPdf
                }
                finally
                {
                    // التأكد من استعادة مؤشر الماوس
                    Cursor.Current = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء تصدير البيانات إلى PDF: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void totlaNumbre_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Converts a column number to Excel column name (e.g., 1 = A, 27 = AA)
        /// </summary>
        /// <param name="columnNumber">The column number to convert (1-based)</param>
        /// <returns>The Excel column name</returns>
        private string GetExcelColumnName(int columnNumber)
        {
            string columnName = string.Empty;

            while (columnNumber > 0)
            {
                int remainder = (columnNumber - 1) % 26;
                char letter = (char)('A' + remainder);
                columnName = letter + columnName;
                columnNumber = (columnNumber - 1) / 26;
            }

            return columnName;
        }
    }
}


/*
  dataGridView1.AutoGenerateColumns = false;

                            //Set Columns Count
                            dataGridView1.ColumnCount = 6 ;

                            //Add Columns

                            dataGridView1.Columns[0].HeaderText = "Appointment ID";
                            dataGridView1.Columns[0].Name = "CodeRDV";
                            dataGridView1.Columns[0].DataPropertyName = "CodeRDV";


                            dataGridView1.Columns[1].Name = "DateRDV";
                            dataGridView1.Columns[1].HeaderText = "Appointment Date";
                            dataGridView1.Columns[1].DataPropertyName = "DateRDV";



                            dataGridView1.Columns[2].Name = "Comments";
                            dataGridView1.Columns[2].HeaderText = "Comments";
                            dataGridView1.Columns[2].DataPropertyName = "Comments";



                            dataGridView1.Columns[3].Name = "Name";
                            dataGridView1.Columns[3].HeaderText = "Name";
                            dataGridView1.Columns[3].DataPropertyName = "Name";




                            dataGridView1.Columns[4].Name = "LastName";
                            dataGridView1.Columns[4].HeaderText = "LastName";
                            dataGridView1.Columns[4].DataPropertyName = "LastName";

                            dataGridView1.Columns[5].Name = "Time";
                            dataGridView1.Columns[5].HeaderText = "Time";
                            dataGridView1.Columns[5].DataPropertyName = "Time";
*/
