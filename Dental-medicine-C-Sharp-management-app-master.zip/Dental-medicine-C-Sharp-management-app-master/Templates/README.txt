INSTRUCCIONES PARA PLANTILLAS DE DOCUMENTOS
===========================================

Para utilizar la funcionalidad de exportación a PDF, coloque los siguientes archivos de plantilla en esta carpeta:

1. InvoiceTemplate.docx - Plantilla para facturas
   - Debe contener los siguientes marcadores (bookmarks):
     * ClientName - Nombre del cliente
     * InvoiceNumber - Número de factura
     * InvoiceDate - Fecha de la factura
     * TotalAmount - Monto total

2. AppointmentTemplate.docx - Plantilla para citas (opcional)
   - Debe contener los siguientes marcadores (bookmarks):
     * ClientName - Nombre del cliente
     * AppointmentId - ID de la cita
     * AppointmentDate - Fecha de la cita
     * AppointmentTime - Hora de la cita
     * Comments - Comentarios

Si no se encuentra la plantilla AppointmentTemplate.docx, se utilizará InvoiceTemplate.docx para las citas.

Los archivos PDF generados se guardarán en la carpeta "DentiPlus\Exports" dentro de la carpeta "Mis Documentos".
