-- Insert data into History table
USE [dentaldoctor]
GO

-- Add sample data to History table
-- Get the first client ID
DECLARE @ClientID INT;
SELECT TOP 1 @ClientID = CodeClient FROM Client;

-- Only insert if we have a client
IF @ClientID IS NOT NULL
BEGIN
    -- Insert records without specifying DateVisite (it's a timestamp)
    INSERT INTO History (CodeHist, CauseOFVisite, CodeClient)
    VALUES (1, 'Initial Checkup', @ClientID);
    
    INSERT INTO History (CodeHist, CauseOFVisite, CodeClient)
    VALUES (2, 'Tooth Pain', @ClientID);
    
    PRINT 'Added sample history records.';
END
ELSE
BEGIN
    PRINT 'No clients found in the database. Cannot add history records.';
END

PRINT 'History data insertion completed.';
GO
