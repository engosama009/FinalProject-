-- Update History table structure and relationships
USE [dentaldoctor]
GO

-- Check if History table exists
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'History')
BEGIN
    -- Drop the table if it has incorrect structure
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('History') AND name = 'CodeHist' AND TYPE_NAME(system_type_id) = 'nchar')
    BEGIN
        -- Table exists with incorrect structure, drop it
        DROP TABLE History;
        PRINT 'Dropped existing History table with incorrect structure.';
    END
END

-- Create History table with proper structure if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'History')
BEGIN
    CREATE TABLE History (
        CodeHist INT IDENTITY(1,1) PRIMARY KEY,
        CauseOFVisite NVARCHAR(255) NOT NULL,
        DateVisite DATETIME DEFAULT GETDATE(),
        CodeClient INT NOT NULL,
        Notes NVARCHAR(MAX) NULL,
        TreatmentProvided NVARCHAR(255) NULL,
        CONSTRAINT FK_History_Client FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient)
    );
    
    PRINT 'Created History table with proper structure and relationship to Client table.';
END
ELSE
BEGIN
    -- Table exists but might need column updates
    
    -- Check if CodeClient is INT
    DECLARE @DataType NVARCHAR(128);
    SELECT @DataType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('History') AND name = 'CodeClient';
    
    IF @DataType != 'int'
    BEGIN
        -- Need to recreate the table with proper structure
        -- First, save existing data
        SELECT * INTO History_Backup FROM History;
        PRINT 'Backed up existing History data to History_Backup table.';
        
        -- Drop the table
        DROP TABLE History;
        
        -- Recreate with proper structure
        CREATE TABLE History (
            CodeHist INT IDENTITY(1,1) PRIMARY KEY,
            CauseOFVisite NVARCHAR(255) NOT NULL,
            DateVisite DATETIME DEFAULT GETDATE(),
            CodeClient INT NOT NULL,
            Notes NVARCHAR(MAX) NULL,
            TreatmentProvided NVARCHAR(255) NULL,
            CONSTRAINT FK_History_Client FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient)
        );
        
        PRINT 'Recreated History table with proper structure and relationship to Client table.';
        
        -- Try to migrate data if possible
        PRINT 'Note: You will need to manually migrate data from History_Backup to the new History table.';
    END
    ELSE
    BEGIN
        -- Check if foreign key exists
        IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_History_Client')
        BEGIN
            -- Add foreign key constraint
            ALTER TABLE History ADD CONSTRAINT FK_History_Client 
            FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient);
            
            PRINT 'Added foreign key constraint to link History table with Client table.';
        END
        
        -- Check for additional columns
        IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('History') AND name = 'Notes')
        BEGIN
            ALTER TABLE History ADD Notes NVARCHAR(MAX) NULL;
            PRINT 'Added Notes column to History table.';
        END
        
        IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('History') AND name = 'TreatmentProvided')
        BEGIN
            ALTER TABLE History ADD TreatmentProvided NVARCHAR(255) NULL;
            PRINT 'Added TreatmentProvided column to History table.';
        END
        
        PRINT 'Updated History table structure.';
    END
END

-- Add sample data if table is empty
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'History') AND NOT EXISTS (SELECT TOP 1 * FROM History)
BEGIN
    -- Get the first client ID
    DECLARE @ClientID INT;
    SELECT TOP 1 @ClientID = CodeClient FROM Client;
    
    -- Only insert if we have a client
    IF @ClientID IS NOT NULL
    BEGIN
        INSERT INTO History (CauseOFVisite, DateVisite, CodeClient, Notes, TreatmentProvided)
        VALUES ('Initial Checkup', GETDATE(), @ClientID, 'Patient came in for regular checkup', 'Dental cleaning');
        
        INSERT INTO History (CauseOFVisite, DateVisite, CodeClient, Notes, TreatmentProvided)
        VALUES ('Tooth Pain', DATEADD(day, -30, GETDATE()), @ClientID, 'Patient complained of pain in lower right molar', 'Prescribed pain medication');
        
        PRINT 'Added sample history records.';
    END
END

PRINT 'History table update completed successfully.';
GO
