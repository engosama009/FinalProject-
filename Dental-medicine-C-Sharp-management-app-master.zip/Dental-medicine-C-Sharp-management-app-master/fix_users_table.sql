-- Fix Users table structure
USE [dentaldoctor]
GO

-- Check if we need to modify the Users table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    -- First check if Login is the primary key
    IF EXISTS (SELECT * FROM sys.key_constraints 
               WHERE name = 'PK_Users' 
               AND parent_object_id = OBJECT_ID('Users')
               AND type = 'PK')
    BEGIN
        -- Create a temporary table to hold the data
        CREATE TABLE Users_Temp (
            CodeUser INT IDENTITY(1,1) PRIMARY KEY,
            Name NVARCHAR(50) NOT NULL,
            LastName NVARCHAR(50) NOT NULL,
            Login NVARCHAR(50) NOT NULL UNIQUE,
            Password NVARCHAR(50) NOT NULL,
            role NVARCHAR(20) NOT NULL
        );
        
        -- Copy data from Users to Users_Temp
        INSERT INTO Users_Temp (Name, LastName, Login, Password, role)
        SELECT Name, LastName, Login, Password, role FROM Users;
        
        -- Drop the original Users table
        DROP TABLE Users;
        
        -- Rename Users_Temp to Users
        EXEC sp_rename 'Users_Temp', 'Users';
        
        PRINT 'Users table structure has been fixed.';
    END
    ELSE
    BEGIN
        PRINT 'Users table already has the correct structure.';
    END
END
ELSE
BEGIN
    -- Create Users table if it doesn't exist
    CREATE TABLE Users (
        CodeUser INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        Login NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(50) NOT NULL,
        role NVARCHAR(20) NOT NULL
    );
    
    -- Insert default admin user
    INSERT INTO Users (Name, LastName, Login, Password, role)
    VALUES ('Admin', 'User', 'admin', 'admin', 'Admin');
    
    PRINT 'Users table has been created with default admin user.';
END
GO
