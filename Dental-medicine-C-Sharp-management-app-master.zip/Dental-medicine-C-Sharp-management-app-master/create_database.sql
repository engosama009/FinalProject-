-- Create the database if it doesn't exist
IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'dentaldoctor')
BEGIN
    CREATE DATABASE dentaldoctor;
END
GO

USE dentaldoctor;
GO

-- Create Users table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        UserID INT IDENTITY(1,1) PRIMARY KEY,
        Login NVARCHAR(50) NOT NULL,
        Password NVARCHAR(50) NOT NULL,
        role NVARCHAR(20) NOT NULL
    );

    -- Insert default admin user
    INSERT INTO Users (Login, Password, role)
    VALUES ('admin', 'admin', 'Admin');
END
GO

-- Create Client table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Client')
BEGIN
    CREATE TABLE Client (
        CodeClient INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        LastName NVARCHAR(100) NOT NULL,
        DateOfBirth DATE,
        Sexe NVARCHAR(10),
        Adresse NVARCHAR(255),
        Profession NVARCHAR(100),
        TelNumber NVARCHAR(20),
        Email NVARCHAR(100),
        Allergies NVARCHAR(255),
        CreatedAt DATETIME DEFAULT GETDATE(),
        Status NVARCHAR(20) DEFAULT 'Active'
    );

    -- Insert sample client data
    INSERT INTO Client (Name, LastName, DateOfBirth, Sexe, Adresse, Profession, TelNumber, Email, Allergies, CreatedAt, Status)
    VALUES ('John', 'Doe', '1980-01-01', 'Male', '123 Main St', 'Engineer', '555-1234', 'john@example.com', 'None', GETDATE(), 'Active');
END
GO

-- Create Dent table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Dent')
BEGIN
    CREATE TABLE Dent (
        CodeDent INT IDENTITY(1,1) PRIMARY KEY,
        TreatmentType NVARCHAR(100) NOT NULL,
        Cost DECIMAL(10, 2) DEFAULT 0,
        description NVARCHAR(255)
    );

    -- Insert sample dental treatments
    INSERT INTO Dent (TreatmentType, Cost, description)
    VALUES ('Cleaning', 50.00, 'Regular dental cleaning');

    INSERT INTO Dent (TreatmentType, Cost, description)
    VALUES ('Filling', 100.00, 'Dental filling procedure');

    INSERT INTO Dent (TreatmentType, Cost, description)
    VALUES ('Root Canal', 300.00, 'Root canal treatment');
END
GO

-- Create RDV (Appointment) table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'RDV')
BEGIN
    CREATE TABLE RDV (
        CodeRDV INT IDENTITY(1,1) PRIMARY KEY,
        DateRDV DATE NOT NULL,
        Time NVARCHAR(20) NOT NULL,
        ClientID INT NOT NULL,
        Comments NVARCHAR(255),
        FOREIGN KEY (ClientID) REFERENCES Client(CodeClient)
    );

    -- Insert sample appointment
    INSERT INTO RDV (DateRDV, Time, ClientID, Comments)
    VALUES (GETDATE(), '09:00 - 10:00', 1, 'Regular checkup');
END
GO

-- Create Interventions table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Interventions')
BEGIN
    CREATE TABLE Interventions (
        CodeInt INT IDENTITY(1,1) PRIMARY KEY,
        Date DATETIME DEFAULT GETDATE(),
        CodeClient INT NOT NULL,
        CodeDent INT NOT NULL,
        Cout DECIMAL(10, 2) DEFAULT 0,
        Nbre INT DEFAULT 1,
        Acte NVARCHAR(100),
        observation NVARCHAR(255),
        FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient),
        FOREIGN KEY (CodeDent) REFERENCES Dent(CodeDent)
    );

    -- Insert sample intervention
    INSERT INTO Interventions (Date, CodeClient, CodeDent, Cout, Nbre, Acte, observation)
    VALUES (GETDATE(), 1, 1, 50.00, 1, 'Cleaning', 'Regular cleaning performed');
END
GO
