-- Create a simple History table with relationship to Client
USE [dentaldoctor]
GO

-- Drop the History table if it exists
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'History')
BEGIN
    DROP TABLE History;
    PRINT 'Dropped existing History table.';
END

-- Create History table with proper structure
CREATE TABLE History (
    CodeHist INT IDENTITY(1,1) PRIMARY KEY,
    CauseOFVisite NVARCHAR(255) NOT NULL,
    DateVisite DATETIME DEFAULT GETDATE(),
    CodeClient INT NOT NULL,
    CONSTRAINT FK_History_Client FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient)
);

PRINT 'Created History table with proper structure and relationship to Client table.';

-- Add sample data
-- Get the first client ID
DECLARE @ClientID INT;
SELECT TOP 1 @ClientID = CodeClient FROM Client;

-- Only insert if we have a client
IF @ClientID IS NOT NULL
BEGIN
    INSERT INTO History (CauseOFVisite, DateVisite, CodeClient)
    VALUES ('Initial Checkup', GETDATE(), @ClientID);
    
    INSERT INTO History (CauseOFVisite, DateVisite, CodeClient)
    VALUES ('Tooth Pain', DATEADD(day, -30, GETDATE()), @ClientID);
    
    PRINT 'Added sample history records.';
END

PRINT 'History table update completed successfully.';
GO
