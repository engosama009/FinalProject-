-- Add relationship between History and Client tables
USE [dentaldoctor]
GO

-- Check if the foreign key already exists
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_History_Client')
BEGIN
    -- Check if the columns exist and have compatible types
    DECLARE @HistoryClientType NVARCHAR(128), @ClientCodeType NVARCHAR(128);
    
    SELECT @HistoryClientType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('History') AND name = 'CodeClient';
    
    SELECT @ClientCodeType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Client') AND name = 'CodeClient';
    
    -- If the column types are not compatible, alter the History.CodeClient column
    IF @HistoryClientType != @ClientCodeType
    BEGIN
        -- If History.CodeClient is nchar, convert it to int
        IF @HistoryClientType = 'nchar' AND @ClientCodeType = 'int'
        BEGIN
            -- Create a temporary table to hold the data
            CREATE TABLE History_Temp (
                CodeHist INT IDENTITY(1,1) PRIMARY KEY,
                CauseOFVisite NVARCHAR(255) NOT NULL,
                DateVisite DATETIME DEFAULT GETDATE(),
                CodeClient INT NOT NULL
            );
            
            -- Copy data from History to History_Temp, converting CodeClient to int
            INSERT INTO History_Temp (CauseOFVisite, CodeClient)
            SELECT 
                CauseOFVisite,
                CAST(LTRIM(RTRIM(CodeClient)) AS INT) -- Convert nchar to int
            FROM History;
            
            -- Drop the original History table
            DROP TABLE History;
            
            -- Rename History_Temp to History
            EXEC sp_rename 'History_Temp', 'History';
            
            PRINT 'History table structure has been updated.';
        END
    END
    
    -- Add the foreign key constraint
    ALTER TABLE History ADD CONSTRAINT FK_History_Client 
    FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient);
    
    PRINT 'Added FK_History_Client constraint.';
END
ELSE
BEGIN
    PRINT 'FK_History_Client constraint already exists.';
END

-- Verify the relationship
SELECT 
    fk.name AS ForeignKeyName,
    OBJECT_NAME(fk.parent_object_id) AS TableName,
    COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS ColumnName,
    OBJECT_NAME(fk.referenced_object_id) AS ReferencedTableName,
    COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS ReferencedColumnName
FROM 
    sys.foreign_keys AS fk
INNER JOIN 
    sys.foreign_key_columns AS fkc ON fk.object_id = fkc.constraint_object_id
WHERE 
    fk.name = 'FK_History_Client';
GO
