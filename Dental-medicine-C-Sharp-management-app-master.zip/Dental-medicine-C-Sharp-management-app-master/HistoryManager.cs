using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Dental_Clinic_Management
{
    public class HistoryManager
    {
        // Connection string
        private string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=dentaldoctor;Integrated Security=True";

        // Constructor
        public HistoryManager()
        {
            // Ensure the History table is properly linked to Client table
            EnsureHistoryClientRelationship();
        }

        // Method to ensure the relationship between History and Client tables
        private void EnsureHistoryClientRelationship()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the foreign key constraint exists
                    string checkConstraintQuery = @"
                        SELECT COUNT(*) 
                        FROM sys.foreign_keys 
                        WHERE name = 'FK_History_Client'";

                    SqlCommand checkCommand = new SqlCommand(checkConstraintQuery, connection);
                    int constraintExists = (int)checkCommand.ExecuteScalar();

                    // If constraint doesn't exist, create it
                    if (constraintExists == 0)
                    {
                        // First check column types
                        string checkColumnTypeQuery = @"
                            SELECT 
                                TYPE_NAME(h.system_type_id) AS HistoryClientType,
                                TYPE_NAME(c.system_type_id) AS ClientCodeType
                            FROM 
                                sys.columns h
                                CROSS JOIN sys.columns c
                            WHERE 
                                h.object_id = OBJECT_ID('History') 
                                AND h.name = 'CodeClient'
                                AND c.object_id = OBJECT_ID('Client') 
                                AND c.name = 'CodeClient'";

                        SqlCommand typeCheckCommand = new SqlCommand(checkColumnTypeQuery, connection);
                        SqlDataReader reader = typeCheckCommand.ExecuteReader();
                        
                        string historyClientType = "";
                        string clientCodeType = "";
                        
                        if (reader.Read())
                        {
                            historyClientType = reader["HistoryClientType"].ToString();
                            clientCodeType = reader["ClientCodeType"].ToString();
                        }
                        reader.Close();

                        // If types are incompatible, update the History.CodeClient column
                        if (historyClientType != clientCodeType)
                        {
                            string updateColumnQuery = @"
                                -- Create a temporary table with correct structure
                                SELECT 
                                    CodeHist,
                                    CauseOFVisite,
                                    DateVisite,
                                    CAST(LTRIM(RTRIM(CodeClient)) AS INT) AS CodeClient
                                INTO 
                                    History_Temp
                                FROM 
                                    History;
                                
                                -- Drop the original table
                                DROP TABLE History;
                                
                                -- Rename the temp table
                                EXEC sp_rename 'History_Temp', 'History';
                                
                                -- Add primary key
                                ALTER TABLE History 
                                ADD CONSTRAINT PK_History PRIMARY KEY (CodeHist);";

                            SqlCommand updateCommand = new SqlCommand(updateColumnQuery, connection);
                            updateCommand.ExecuteNonQuery();
                        }

                        // Add the foreign key constraint
                        string addConstraintQuery = @"
                            ALTER TABLE History 
                            ADD CONSTRAINT FK_History_Client 
                            FOREIGN KEY (CodeClient) 
                            REFERENCES Client(CodeClient)";

                        SqlCommand addConstraintCommand = new SqlCommand(addConstraintQuery, connection);
                        addConstraintCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ensuring History-Client relationship: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to get all history records
        public DataTable GetAllHistoryRecords()
        {
            DataTable historyTable = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                        SELECT 
                            h.CodeHist,
                            h.CauseOFVisite,
                            h.DateVisite,
                            c.Name + ' ' + c.LastName AS ClientName,
                            h.CodeClient
                        FROM 
                            History h
                            INNER JOIN Client c ON h.CodeClient = c.CodeClient
                        ORDER BY 
                            h.DateVisite DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(historyTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving history records: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return historyTable;
        }

        // Method to get history records for a specific client
        public DataTable GetClientHistory(int clientId)
        {
            DataTable historyTable = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                        SELECT 
                            h.CodeHist,
                            h.CauseOFVisite,
                            h.DateVisite
                        FROM 
                            History h
                        WHERE 
                            h.CodeClient = @ClientId
                        ORDER BY 
                            h.DateVisite DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@ClientId", clientId);
                    adapter.Fill(historyTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving client history: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return historyTable;
        }

        // Method to add a new history record
        public bool AddHistoryRecord(string causeOfVisit, int clientId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        INSERT INTO History (CauseOFVisite, CodeClient)
                        VALUES (@CauseOfVisit, @ClientId);
                        
                        SELECT SCOPE_IDENTITY();";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CauseOfVisit", causeOfVisit);
                    command.Parameters.AddWithValue("@ClientId", clientId);

                    int newHistoryId = Convert.ToInt32(command.ExecuteScalar());
                    return newHistoryId > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding history record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Method to update a history record
        public bool UpdateHistoryRecord(int historyId, string causeOfVisit)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        UPDATE History
                        SET CauseOFVisite = @CauseOfVisit
                        WHERE CodeHist = @HistoryId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CauseOfVisit", causeOfVisit);
                    command.Parameters.AddWithValue("@HistoryId", historyId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating history record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Method to delete a history record
        public bool DeleteHistoryRecord(int historyId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        DELETE FROM History
                        WHERE CodeHist = @HistoryId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@HistoryId", historyId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting history record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
