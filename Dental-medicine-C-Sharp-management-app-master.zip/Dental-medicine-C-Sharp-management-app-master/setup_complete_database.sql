-- Complete Database Setup Script for Dental Clinic Application
-- This script will create or update the entire database structure

USE [master]
GO

-- Create the database if it doesn't exist
IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'dentaldoctor')
BEGIN
    CREATE DATABASE dentaldoctor;
    PRINT 'Database dentaldoctor created.';
END
ELSE
BEGIN
    PRINT 'Database dentaldoctor already exists.';
END
GO

USE [dentaldoctor]
GO

PRINT 'Starting database setup...';

-- Drop foreign key constraints first to avoid conflicts when modifying tables
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Interventions_Client')
BEGIN
    ALTER TABLE Interventions DROP CONSTRAINT FK_Interventions_Client;
    PRINT 'Dropped FK_Interventions_Client constraint.';
END

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Interventions_Dent')
BEGIN
    ALTER TABLE Interventions DROP CONSTRAINT FK_Interventions_Dent;
    PRINT 'Dropped FK_Interventions_Dent constraint.';
END

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RDV_Client')
BEGIN
    ALTER TABLE RDV DROP CONSTRAINT FK_RDV_Client;
    PRINT 'Dropped FK_RDV_Client constraint.';
END

-- Fix Users table structure
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    -- Check if Login is the primary key
    IF EXISTS (SELECT * FROM sys.key_constraints 
               WHERE name = 'PK_Users' 
               AND parent_object_id = OBJECT_ID('Users')
               AND type = 'PK')
    BEGIN
        -- Create a temporary table to hold the data
        CREATE TABLE Users_Temp (
            CodeUser INT IDENTITY(1,1) PRIMARY KEY,
            Name NVARCHAR(50) NOT NULL,
            LastName NVARCHAR(50) NOT NULL,
            Login NVARCHAR(50) NOT NULL UNIQUE,
            Password NVARCHAR(50) NOT NULL,
            role NVARCHAR(20) NOT NULL
        );
        
        -- Copy data from Users to Users_Temp
        INSERT INTO Users_Temp (Name, LastName, Login, Password, role)
        SELECT Name, LastName, Login, Password, role FROM Users;
        
        -- Drop the original Users table
        DROP TABLE Users;
        
        -- Rename Users_Temp to Users
        EXEC sp_rename 'Users_Temp', 'Users';
        
        PRINT 'Users table structure has been fixed.';
    END
    ELSE
    BEGIN
        PRINT 'Users table already has the correct structure.';
    END
END
ELSE
BEGIN
    -- Create Users table if it doesn't exist
    CREATE TABLE Users (
        CodeUser INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        Login NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(50) NOT NULL,
        role NVARCHAR(20) NOT NULL
    );
    
    PRINT 'Users table has been created.';
END

-- Update or create Client table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Client')
BEGIN
    -- Table exists, check if we need to add columns
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Allergies')
    BEGIN
        ALTER TABLE Client ADD Allergies NVARCHAR(255) NULL;
        PRINT 'Added Allergies column to Client table.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'CreatedAt')
    BEGIN
        ALTER TABLE Client ADD CreatedAt DATETIME DEFAULT GETDATE();
        PRINT 'Added CreatedAt column to Client table.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Status')
    BEGIN
        ALTER TABLE Client ADD Status NVARCHAR(20) DEFAULT 'Active';
        PRINT 'Added Status column to Client table.';
    END
    
    -- Update existing records to have default values
    UPDATE Client SET 
        Allergies = ISNULL(Allergies, 'None'),
        CreatedAt = ISNULL(CreatedAt, GETDATE()),
        Status = ISNULL(Status, 'Active')
    WHERE Allergies IS NULL OR CreatedAt IS NULL OR Status IS NULL;
    
    PRINT 'Updated existing Client records with default values.';
END
ELSE
BEGIN
    -- Create Client table if it doesn't exist
    CREATE TABLE Client (
        CodeClient INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        LastName NVARCHAR(100) NOT NULL,
        DateOfBirth DATE NULL,
        Sexe NVARCHAR(10) NULL,
        Adresse NVARCHAR(255) NULL,
        Profession NVARCHAR(100) NULL,
        TelNumber NVARCHAR(20) NULL,
        Email NVARCHAR(100) NULL,
        Allergies NVARCHAR(255) NULL,
        CreatedAt DATETIME DEFAULT GETDATE(),
        Status NVARCHAR(20) DEFAULT 'Active'
    );
    
    PRINT 'Client table has been created.';
END

-- Update or create Dent table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Dent')
BEGIN
    -- Table exists, check if we need to add columns
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'TreatmentType')
    BEGIN
        ALTER TABLE Dent ADD TreatmentType NVARCHAR(100) NULL;
        PRINT 'Added TreatmentType column to Dent table.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Cost')
    BEGIN
        ALTER TABLE Dent ADD Cost DECIMAL(10, 2) DEFAULT 0;
        PRINT 'Added Cost column to Dent table.';
    END
    
    -- Update column types if needed
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Description')
    BEGIN
        -- Check if we need to alter the column
        DECLARE @DataType NVARCHAR(128);
        SELECT @DataType = TYPE_NAME(system_type_id)
        FROM sys.columns
        WHERE object_id = OBJECT_ID('Dent') AND name = 'Description';
        
        IF @DataType = 'nchar'
        BEGIN
            -- Create a temporary table to hold the data
            CREATE TABLE Dent_Temp (
                CodeDent INT IDENTITY(1,1) PRIMARY KEY,
                TreatmentType NVARCHAR(100) NULL,
                Description NVARCHAR(255) NULL,
                Cost DECIMAL(10, 2) DEFAULT 0
            );
            
            -- Copy data from Dent to Dent_Temp
            INSERT INTO Dent_Temp (TreatmentType, Description, Cost)
            SELECT 
                ISNULL(TreatmentType, Description) AS TreatmentType, 
                Description, 
                ISNULL(Cost, 0) AS Cost 
            FROM Dent;
            
            -- Drop the original Dent table
            DROP TABLE Dent;
            
            -- Rename Dent_Temp to Dent
            EXEC sp_rename 'Dent_Temp', 'Dent';
            
            PRINT 'Dent table structure has been updated.';
        END
    END
END
ELSE
BEGIN
    -- Create Dent table if it doesn't exist
    CREATE TABLE Dent (
        CodeDent INT IDENTITY(1,1) PRIMARY KEY,
        TreatmentType NVARCHAR(100) NULL,
        Description NVARCHAR(255) NULL,
        Cost DECIMAL(10, 2) DEFAULT 0
    );
    
    PRINT 'Dent table has been created.';
END

-- Update or create RDV (Appointment) table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'RDV')
BEGIN
    -- Table exists, check if we need to modify columns
    DECLARE @DataType NVARCHAR(128);
    SELECT @DataType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('RDV') AND name = 'Comments';
    
    IF @DataType != 'nvarchar' OR EXISTS (
        SELECT * FROM sys.columns 
        WHERE object_id = OBJECT_ID('RDV') 
        AND name = 'Comments' 
        AND max_length < 510
    )
    BEGIN
        -- Alter the column to use NVARCHAR(255)
        ALTER TABLE RDV ALTER COLUMN Comments NVARCHAR(255) NULL;
        PRINT 'Updated Comments column in RDV table.';
    END
END
ELSE
BEGIN
    -- Create RDV table if it doesn't exist
    CREATE TABLE RDV (
        CodeRDV INT IDENTITY(1,1) PRIMARY KEY,
        DateRDV DATE NOT NULL,
        Time NVARCHAR(20) NOT NULL,
        ClientID INT NOT NULL,
        Comments NVARCHAR(255) NULL
    );
    
    PRINT 'RDV table has been created.';
END

-- Update or create Interventions table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Interventions')
BEGIN
    -- Table exists, check if we need to modify columns
    DECLARE @DataType NVARCHAR(128), @Precision INT, @Scale INT;
    SELECT 
        @DataType = TYPE_NAME(system_type_id),
        @Precision = precision,
        @Scale = scale
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Interventions') AND name = 'Cout';
    
    IF @DataType != 'decimal' OR @Precision != 10 OR @Scale != 2
    BEGIN
        -- Alter the column to use DECIMAL(10,2) for proper currency display
        ALTER TABLE Interventions ALTER COLUMN Cout DECIMAL(10, 2);
        PRINT 'Updated Cout column in Interventions table to DECIMAL(10,2) for proper currency display.';
    END
    
    -- Check and update observation column
    SELECT @DataType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Interventions') AND name = 'observation';
    
    IF @DataType = 'nchar'
    BEGIN
        -- Alter the column to use NVARCHAR(255)
        ALTER TABLE Interventions ALTER COLUMN observation NVARCHAR(255) NULL;
        PRINT 'Updated observation column in Interventions table.';
    END
    
    -- Check and update Acte column
    SELECT @DataType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Interventions') AND name = 'Acte';
    
    IF @DataType = 'nchar'
    BEGIN
        -- Alter the column to use NVARCHAR(100)
        ALTER TABLE Interventions ALTER COLUMN Acte NVARCHAR(100) NULL;
        PRINT 'Updated Acte column in Interventions table.';
    END
END
ELSE
BEGIN
    -- Create Interventions table if it doesn't exist
    CREATE TABLE Interventions (
        CodeInt INT IDENTITY(1,1) PRIMARY KEY,
        Date DATETIME DEFAULT GETDATE(),
        CodeClient INT NOT NULL,
        CodeDent INT NOT NULL,
        Cout DECIMAL(10, 2) DEFAULT 0,
        Nbre INT DEFAULT 1,
        Acte NVARCHAR(100) NULL,
        observation NVARCHAR(255) NULL
    );
    
    PRINT 'Interventions table has been created.';
END

-- Re-add foreign key constraints
ALTER TABLE Interventions ADD CONSTRAINT FK_Interventions_Client 
FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient);
PRINT 'Added FK_Interventions_Client constraint.';

ALTER TABLE Interventions ADD CONSTRAINT FK_Interventions_Dent 
FOREIGN KEY (CodeDent) REFERENCES Dent(CodeDent);
PRINT 'Added FK_Interventions_Dent constraint.';

ALTER TABLE RDV ADD CONSTRAINT FK_RDV_Client 
FOREIGN KEY (ClientID) REFERENCES Client(CodeClient);
PRINT 'Added FK_RDV_Client constraint.';

-- Insert sample data if tables are empty
-- Sample client
IF NOT EXISTS (SELECT TOP 1 * FROM Client)
BEGIN
    INSERT INTO Client (Name, LastName, DateOfBirth, Sexe, Adresse, Profession, TelNumber, Email, Allergies, Status)
    VALUES ('John', 'Doe', '1980-01-01', 'Male', '123 Main St', 'Engineer', '555-1234', 'john@example.com', 'None', 'Active');
    PRINT 'Added sample client data.';
END

-- Sample dental treatments
IF NOT EXISTS (SELECT TOP 1 * FROM Dent)
BEGIN
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Cleaning', 'Regular dental cleaning', 50.00);
    
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Filling', 'Dental filling procedure', 100.00);
    
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Root Canal', 'Root canal treatment', 300.00);
    
    PRINT 'Added sample dental treatment data.';
END

-- Sample user if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM Users WHERE Login = 'admin')
BEGIN
    INSERT INTO Users (Name, LastName, Login, Password, role)
    VALUES ('Admin', 'User', 'admin', 'admin', 'Admin');
    PRINT 'Added admin user.';
END

-- Sample appointment if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM RDV)
BEGIN
    -- Get the first client ID
    DECLARE @ClientID INT;
    SELECT TOP 1 @ClientID = CodeClient FROM Client;
    
    -- Only insert if we have a client
    IF @ClientID IS NOT NULL
    BEGIN
        INSERT INTO RDV (DateRDV, Time, ClientID, Comments)
        VALUES (GETDATE(), '09:00 - 10:00', @ClientID, 'Regular checkup');
        PRINT 'Added sample appointment data.';
    END
END

-- Sample intervention if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM Interventions)
BEGIN
    -- Get the first client ID and dent ID
    DECLARE @ClientID INT, @DentID INT;
    SELECT TOP 1 @ClientID = CodeClient FROM Client;
    SELECT TOP 1 @DentID = CodeDent FROM Dent;
    
    -- Only insert if we have both a client and a dent
    IF @ClientID IS NOT NULL AND @DentID IS NOT NULL
    BEGIN
        INSERT INTO Interventions (Date, CodeClient, CodeDent, Cout, Nbre, Acte, observation)
        VALUES (GETDATE(), @ClientID, @DentID, 50.00, 1, 'Cleaning', 'Regular cleaning performed');
        PRINT 'Added sample intervention data.';
    END
END

PRINT '=================================================='
PRINT 'Database setup completed successfully!'
PRINT 'All tables have been created or updated.'
PRINT 'Sample data has been added where needed.'
PRINT '=================================================='
GO
