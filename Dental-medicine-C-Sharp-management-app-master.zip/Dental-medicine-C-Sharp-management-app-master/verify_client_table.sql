-- Verify and fix Client table structure
USE [dentaldoctor]
GO

-- Check if Client table exists
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Client')
BEGIN
    -- Check for Allergies column
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Allergies')
    BEGIN
        ALTER TABLE Client ADD Allergies NVARCHAR(255) NULL;
        PRINT 'Added Allergies column to Client table.';
    END
    
    -- Check for CreatedAt column
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'CreatedAt')
    BEGIN
        ALTER TABLE Client ADD CreatedAt DATETIME DEFAULT GETDATE();
        PRINT 'Added CreatedAt column to Client table.';
    END
    
    -- Check for Status column
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Status')
    BEGIN
        ALTER TABLE Client ADD Status NVARCHAR(20) DEFAULT 'Active';
        PRINT 'Added Status column to Client table.';
    END
    
    -- Update existing records to have default values
    UPDATE Client SET 
        Allergies = ISNULL(Allergies, 'None'),
        CreatedAt = ISNULL(CreatedAt, GETDATE()),
        Status = ISNULL(Status, 'Active')
    WHERE Allergies IS NULL OR CreatedAt IS NULL OR Status IS NULL;
    
    PRINT 'Client table structure has been verified and updated.';
END
ELSE
BEGIN
    PRINT 'Client table does not exist. Please run the main database script first.';
END
GO
