-- Add admin user if missing
USE [dentaldoctor]
GO

-- Check if admin user exists
IF NOT EXISTS (SELECT * FROM Users WHERE Login = 'admin')
BEGIN
    -- Add admin user
    INSERT INTO Users (Name, LastName, Login, Password, role)
    VALUES ('Admin', 'User', 'admin', 'admin', 'Admin');
    
    PRINT 'Admin user has been added.';
END
ELSE
BEGIN
    PRINT 'Admin user already exists.';
END
GO
