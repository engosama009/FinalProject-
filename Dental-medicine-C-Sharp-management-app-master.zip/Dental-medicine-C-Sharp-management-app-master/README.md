"# Dental-medicine-C# -management-app 2020 " 
A School project made for  Dental medicines to help with the global  management .  made Using C# and windows Forms 


## Features
 - statistics of Dental medicine   .
 - Datasets SQL.
 - statistics of Dental medicine   .
 - Patient management
 - Appointment management
...
## Requirements
- visual studio sql server 



## Getting Started
- Clone or download
- import the Sql tables scripts from "script.sql"
- Build and Run and have fun 




<img width="1378" alt="Capture d’écran 2020-05-31 à 18 09 04" src="https://user-images.githubusercontent.com/17935370/83360789-de0e3780-a37b-11ea-82df-0e43aae665e5.png">
<img width="1369" alt="Capture d’écran 2020-05-31 à 18 09 16" src="https://user-images.githubusercontent.com/17935370/83360798-e5354580-a37b-11ea-8edd-87246a206f27.png">
<img width="1355" alt="Capture d’écran 2020-05-31 à 18 09 21" src="https://user-images.githubusercontent.com/17935370/83360802-ea929000-a37b-11ea-9309-eebfd2457068.png">
<img width="706" alt="Capture d’écran 2020-05-31 à 18 09 25" src="https://user-images.githubusercontent.com/17935370/83360803-efefda80-a37b-11ea-9d17-ce98805792e0.png">
<img width="349" alt="Capture d’écran 2020-05-31 à 18 09 34" src="https://user-images.githubusercontent.com/17935370/83360805-f2523480-a37b-11ea-841c-4a0b6fe7af45.png">
<img width="360" alt="Capture d’écran 2020-05-31 à 18 09 39" src="https://user-images.githubusercontent.com/17935370/83360807-f41bf800-a37b-11ea-96b4-80a6783b71f5.png">
<img width="1345" alt="Capture d’écran 2020-05-31 à 18 09 45" src="https://user-images.githubusercontent.com/17935370/83360809-f5e5bb80-a37b-11ea-9840-08d4a9616968.png">
<img width="1356" alt="Capture d’écran 2020-05-31 à 18 09 50" src="https://user-images.githubusercontent.com/17935370/83360814-fed68d00-a37b-11ea-9f06-558193583414.png">
<img width="1364" alt="Capture d’écran 2020-05-31 à 18 09 55" src="https://user-images.githubusercontent.com/17935370/83360819-05650480-a37c-11ea-8fbe-90bc38e50812.png">
<img width="1356" alt="Capture d’écran 2020-05-31 à 18 09 59" src="https://user-images.githubusercontent.com/17935370/83360821-085ff500-a37c-11ea-801e-fbca9e835e79.png">
<img width="1350" alt="Capture d’écran 2020-05-31 à 18 10 03" src="https://user-images.githubusercontent.com/17935370/83360826-0dbd3f80-a37c-11ea-9cd8-cc3063ce6bc9.png">
<img width="480" alt="Capture d’écran 2020-05-31 à 18 10 10" src="https://user-images.githubusercontent.com/17935370/83360827-13b32080-a37c-11ea-8bc9-c76a2e79e42b.png">
