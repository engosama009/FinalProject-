-- Improved database script for dental clinic application
-- This script updates the database structure to match the application requirements

USE [master]
GO

-- Create the database if it doesn't exist
IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'dentaldoctor')
BEGIN
    CREATE DATABASE dentaldoctor;
END
GO

USE [dentaldoctor]
GO

-- Drop foreign key constraints first to avoid conflicts when modifying tables
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Interventions_Client')
BEGIN
    ALTER TABLE Interventions DROP CONSTRAINT FK_Interventions_Client;
END
GO

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Interventions_Dent')
BEGIN
    ALTER TABLE Interventions DROP CONSTRAINT FK_Interventions_Dent;
END
GO

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RDV_Client')
BEGIN
    ALTER TABLE RDV DROP CONSTRAINT FK_RDV_Client;
END
GO

-- Update or create Client table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Client')
BEGIN
    -- Table exists, check if we need to add columns
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Allergies')
    BEGIN
        ALTER TABLE Client ADD Allergies NVARCHAR(255) NULL;
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'CreatedAt')
    BEGIN
        ALTER TABLE Client ADD CreatedAt DATETIME DEFAULT GETDATE();
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Status')
    BEGIN
        ALTER TABLE Client ADD Status NVARCHAR(20) DEFAULT 'Active';
    END
    
    -- Update column types if needed
    ALTER TABLE Client ALTER COLUMN Name NVARCHAR(100) NOT NULL;
    ALTER TABLE Client ALTER COLUMN LastName NVARCHAR(100) NOT NULL;
    ALTER TABLE Client ALTER COLUMN Adresse NVARCHAR(255) NULL;
    ALTER TABLE Client ALTER COLUMN Profession NVARCHAR(100) NULL;
    ALTER TABLE Client ALTER COLUMN TelNumber NVARCHAR(20) NULL;
    ALTER TABLE Client ALTER COLUMN Email NVARCHAR(100) NULL;
    ALTER TABLE Client ALTER COLUMN Sexe NVARCHAR(10) NULL;
END
ELSE
BEGIN
    -- Create Client table if it doesn't exist
    CREATE TABLE Client (
        CodeClient INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        LastName NVARCHAR(100) NOT NULL,
        DateOfBirth DATE NULL,
        Sexe NVARCHAR(10) NULL,
        Adresse NVARCHAR(255) NULL,
        Profession NVARCHAR(100) NULL,
        TelNumber NVARCHAR(20) NULL,
        Email NVARCHAR(100) NULL,
        Allergies NVARCHAR(255) NULL,
        CreatedAt DATETIME DEFAULT GETDATE(),
        Status NVARCHAR(20) DEFAULT 'Active'
    );
END
GO

-- Update or create Dent table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Dent')
BEGIN
    -- Table exists, check if we need to add columns
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'TreatmentType')
    BEGIN
        ALTER TABLE Dent ADD TreatmentType NVARCHAR(100) NULL;
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Cost')
    BEGIN
        ALTER TABLE Dent ADD Cost DECIMAL(10, 2) DEFAULT 0;
    END
    
    -- Update column types if needed
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Description')
    BEGIN
        ALTER TABLE Dent ALTER COLUMN Description NVARCHAR(255) NULL;
    END
END
ELSE
BEGIN
    -- Create Dent table if it doesn't exist
    CREATE TABLE Dent (
        CodeDent INT IDENTITY(1,1) PRIMARY KEY,
        TreatmentType NVARCHAR(100) NULL,
        Description NVARCHAR(255) NULL,
        Cost DECIMAL(10, 2) DEFAULT 0
    );
END
GO

-- Update or create RDV (Appointment) table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'RDV')
BEGIN
    -- Table exists, check if we need to modify columns
    ALTER TABLE RDV ALTER COLUMN Comments NVARCHAR(255) NULL;
END
ELSE
BEGIN
    -- Create RDV table if it doesn't exist
    CREATE TABLE RDV (
        CodeRDV INT IDENTITY(1,1) PRIMARY KEY,
        DateRDV DATE NOT NULL,
        Time NVARCHAR(20) NOT NULL,
        ClientID INT NOT NULL,
        Comments NVARCHAR(255) NULL
    );
END
GO

-- Update or create Interventions table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Interventions')
BEGIN
    -- Table exists, check if we need to modify columns
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Interventions') AND name = 'Cout')
    BEGIN
        -- Change Cout to use decimal with 2 decimal places for currency
        ALTER TABLE Interventions ALTER COLUMN Cout DECIMAL(10, 2) NOT NULL;
    END
    
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Interventions') AND name = 'observation')
    BEGIN
        ALTER TABLE Interventions ALTER COLUMN observation NVARCHAR(255) NULL;
    END
    
    IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Interventions') AND name = 'Acte')
    BEGIN
        ALTER TABLE Interventions ALTER COLUMN Acte NVARCHAR(100) NULL;
    END
END
ELSE
BEGIN
    -- Create Interventions table if it doesn't exist
    CREATE TABLE Interventions (
        CodeInt INT IDENTITY(1,1) PRIMARY KEY,
        Date DATETIME DEFAULT GETDATE(),
        CodeClient INT NOT NULL,
        CodeDent INT NOT NULL,
        Cout DECIMAL(10, 2) DEFAULT 0,
        Nbre INT DEFAULT 1,
        Acte NVARCHAR(100) NULL,
        observation NVARCHAR(255) NULL
    );
END
GO

-- Update or create Users table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    -- Table exists, check if we need to modify columns
    ALTER TABLE Users ALTER COLUMN Name NVARCHAR(50) NOT NULL;
    ALTER TABLE Users ALTER COLUMN LastName NVARCHAR(50) NOT NULL;
    ALTER TABLE Users ALTER COLUMN Login NVARCHAR(50) NOT NULL;
    ALTER TABLE Users ALTER COLUMN Password NVARCHAR(50) NOT NULL;
    ALTER TABLE Users ALTER COLUMN role NVARCHAR(20) NOT NULL;
    
    -- Change primary key if needed
    IF EXISTS (SELECT * FROM sys.key_constraints WHERE name = 'PK_Users' AND parent_object_id = OBJECT_ID('Users'))
    BEGIN
        -- Drop the existing primary key
        ALTER TABLE Users DROP CONSTRAINT PK_Users;
        
        -- Add new primary key on CodeUser
        ALTER TABLE Users ADD CONSTRAINT PK_Users PRIMARY KEY (CodeUser);
    END
END
ELSE
BEGIN
    -- Create Users table if it doesn't exist
    CREATE TABLE Users (
        CodeUser INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        Login NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(50) NOT NULL,
        role NVARCHAR(20) NOT NULL
    );
END
GO

-- Re-add foreign key constraints
ALTER TABLE Interventions ADD CONSTRAINT FK_Interventions_Client 
FOREIGN KEY (CodeClient) REFERENCES Client(CodeClient);
GO

ALTER TABLE Interventions ADD CONSTRAINT FK_Interventions_Dent 
FOREIGN KEY (CodeDent) REFERENCES Dent(CodeDent);
GO

ALTER TABLE RDV ADD CONSTRAINT FK_RDV_Client 
FOREIGN KEY (ClientID) REFERENCES Client(CodeClient);
GO

-- Insert sample data if tables are empty
-- Sample client
IF NOT EXISTS (SELECT TOP 1 * FROM Client)
BEGIN
    INSERT INTO Client (Name, LastName, DateOfBirth, Sexe, Adresse, Profession, TelNumber, Email, Allergies, Status)
    VALUES ('John', 'Doe', '1980-01-01', 'Male', '123 Main St', 'Engineer', '555-1234', 'john@example.com', 'None', 'Active');
END
GO

-- Sample dental treatments
IF NOT EXISTS (SELECT TOP 1 * FROM Dent)
BEGIN
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Cleaning', 'Regular dental cleaning', 50.00);
    
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Filling', 'Dental filling procedure', 100.00);
    
    INSERT INTO Dent (TreatmentType, Description, Cost)
    VALUES ('Root Canal', 'Root canal treatment', 300.00);
END
GO

-- Sample user if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM Users)
BEGIN
    INSERT INTO Users (Name, LastName, Login, Password, role)
    VALUES ('Admin', 'User', 'admin', 'admin', 'Admin');
END
GO

-- Sample appointment if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM RDV)
BEGIN
    -- Get the first client ID
    DECLARE @ClientID INT;
    SELECT TOP 1 @ClientID = CodeClient FROM Client;
    
    -- Only insert if we have a client
    IF @ClientID IS NOT NULL
    BEGIN
        INSERT INTO RDV (DateRDV, Time, ClientID, Comments)
        VALUES (GETDATE(), '09:00 - 10:00', @ClientID, 'Regular checkup');
    END
END
GO

-- Sample intervention if none exists
IF NOT EXISTS (SELECT TOP 1 * FROM Interventions)
BEGIN
    -- Get the first client ID and dent ID
    DECLARE @ClientID INT, @DentID INT;
    SELECT TOP 1 @ClientID = CodeClient FROM Client;
    SELECT TOP 1 @DentID = CodeDent FROM Dent;
    
    -- Only insert if we have both a client and a dent
    IF @ClientID IS NOT NULL AND @DentID IS NOT NULL
    BEGIN
        INSERT INTO Interventions (Date, CodeClient, CodeDent, Cout, Nbre, Acte, observation)
        VALUES (GETDATE(), @ClientID, @DentID, 50.00, 1, 'Cleaning', 'Regular cleaning performed');
    END
END
GO

PRINT 'Database update completed successfully.'
GO
