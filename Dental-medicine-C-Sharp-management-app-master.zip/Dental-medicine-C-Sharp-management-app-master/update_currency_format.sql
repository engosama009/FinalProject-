-- Update currency format in Interventions table
USE [dentaldoctor]
GO

-- Check if Interventions table exists
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Interventions')
BEGIN
    -- Check Cout column type
    DECLARE @DataType NVARCHAR(128);
    SELECT @DataType = TYPE_NAME(system_type_id)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Interventions') AND name = 'Cout';
    
    -- If Cout is not DECIMAL(10,2), update it
    IF @DataType != 'decimal' OR NOT EXISTS (
        SELECT * FROM sys.columns 
        WHERE object_id = OBJECT_ID('Interventions') 
        AND name = 'Cout' 
        AND precision = 10 
        AND scale = 2
    )
    BEGIN
        -- Alter the column to use DECIMAL(10,2) for proper currency display
        ALTER TABLE Interventions ALTER COLUMN Cout DECIMAL(10, 2);
        PRINT 'Updated Cout column to DECIMAL(10,2) for proper currency display.';
    END
    ELSE
    BEGIN
        PRINT 'Cout column already has the correct format.';
    END
    
    -- Check if Dent table exists and has Cost column
    IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Dent')
    BEGIN
        -- Check if Cost column exists
        IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Cost')
        BEGIN
            -- Check Cost column type
            SELECT @DataType = TYPE_NAME(system_type_id)
            FROM sys.columns
            WHERE object_id = OBJECT_ID('Dent') AND name = 'Cost';
            
            -- If Cost is not DECIMAL(10,2), update it
            IF @DataType != 'decimal' OR NOT EXISTS (
                SELECT * FROM sys.columns 
                WHERE object_id = OBJECT_ID('Dent') 
                AND name = 'Cost' 
                AND precision = 10 
                AND scale = 2
            )
            BEGIN
                -- Alter the column to use DECIMAL(10,2) for proper currency display
                ALTER TABLE Dent ALTER COLUMN Cost DECIMAL(10, 2);
                PRINT 'Updated Cost column in Dent table to DECIMAL(10,2) for proper currency display.';
            END
            ELSE
            BEGIN
                PRINT 'Cost column in Dent table already has the correct format.';
            END
        END
        ELSE
        BEGIN
            -- Add Cost column if it doesn't exist
            ALTER TABLE Dent ADD Cost DECIMAL(10, 2) DEFAULT 0;
            PRINT 'Added Cost column to Dent table.';
        END
    END
    
    PRINT 'Currency format has been updated to display in dollars ($).';
END
ELSE
BEGIN
    PRINT 'Interventions table does not exist. Please run the main database script first.';
END
GO
