# تعليمات إعداد قاعدة البيانات لتطبيق عيادة الأسنان

## نظرة عامة

هذا المستند يشرح كيفية إعداد وتحديث قاعدة البيانات لتطبيق عيادة الأسنان. تم تحسين هيكل قاعدة البيانات لتلبية متطلبات التطبيق وإصلاح المشاكل المتعلقة بالأعمدة المفقودة.

## الملفات المتوفرة

1. `updated_setup_complete_database.sql` - سكريبت شامل محدث لإعداد قاعدة البيانات بالكامل (يشمل جدول History)
2. `setup_complete_database.sql` - سكريبت شامل لإعداد قاعدة البيانات بالكامل
3. `improved_database.sql` - سكريبت لتحديث هيكل قاعدة البيانات
4. `fix_users_table.sql` - سكريبت لإصلاح جدول المستخدمين
5. `verify_client_table.sql` - سكريبت للتحقق من جدول العملاء
6. `update_currency_format.sql` - سكريبت لتحديث تنسيق العملة
7. `add_admin_user.sql` - سكريبت لإضافة مستخدم المسؤول
8. `final_database_check_fixed.sql` - سكريبت للتحقق النهائي من قاعدة البيانات
9. `final_history_table.sql` - سكريبت لإنشاء جدول History
10. `insert_history_data.sql` - سكريبت لإضافة بيانات إلى جدول History
11. `database_changes_summary.txt` - ملخص التغييرات التي تم إجراؤها

## كيفية الاستخدام

### الطريقة السريعة (موصى بها)

لإعداد قاعدة البيانات بالكامل، قم بتنفيذ السكريبت الشامل المحدث:

```
sqlcmd -S .\SQLEXPRESS -i updated_setup_complete_database.sql
```

هذا السكريبت سيقوم بما يلي:
- إنشاء قاعدة البيانات إذا لم تكن موجودة
- إنشاء أو تحديث جميع الجداول المطلوبة (بما في ذلك جدول History)
- إضافة الأعمدة المفقودة
- تصحيح أنواع البيانات
- إضافة العلاقات بين الجداول
- إضافة بيانات نموذجية إذا كانت الجداول فارغة

### الطريقة التفصيلية

إذا كنت ترغب في تنفيذ التحديثات خطوة بخطوة، يمكنك تنفيذ السكريبتات بالترتيب التالي:

1. تحديث هيكل قاعدة البيانات:
   ```
   sqlcmd -S .\SQLEXPRESS -i improved_database.sql
   ```

2. إصلاح جدول المستخدمين:
   ```
   sqlcmd -S .\SQLEXPRESS -i fix_users_table.sql
   ```

3. التحقق من جدول العملاء:
   ```
   sqlcmd -S .\SQLEXPRESS -i verify_client_table.sql
   ```

4. تحديث تنسيق العملة:
   ```
   sqlcmd -S .\SQLEXPRESS -i update_currency_format.sql
   ```

5. إضافة مستخدم المسؤول:
   ```
   sqlcmd -S .\SQLEXPRESS -i add_admin_user.sql
   ```

6. إنشاء جدول History:
   ```
   sqlcmd -S .\SQLEXPRESS -i final_history_table.sql
   ```

7. إضافة بيانات إلى جدول History:
   ```
   sqlcmd -S .\SQLEXPRESS -i insert_history_data.sql
   ```

8. التحقق النهائي من قاعدة البيانات:
   ```
   sqlcmd -S .\SQLEXPRESS -i final_database_check_fixed.sql
   ```

## التغييرات الرئيسية

1. تم تغيير عرض العملة من الدينار التونسي إلى الدولار ($)
2. تم إضافة حقول إضافية لعرض معلومات المرضى بشكل أكثر تفصيلاً
3. تم إصلاح الخطأ المتعلق بالأعمدة المفقودة (Allergies, CreatedAt, Status)
4. تم تحسين هيكل قاعدة البيانات ليكون أكثر مرونة وقابلية للتوسع
5. تم إنشاء جدول History وربطه بجدول Client لتتبع زيارات المرضى

## هيكل قاعدة البيانات المحدث

### جدول Client (العملاء)
- CodeClient (INT, PK) - معرف العميل
- Name (NVARCHAR(100)) - اسم العميل
- LastName (NVARCHAR(100)) - اسم العائلة
- DateOfBirth (DATE) - تاريخ الميلاد
- Sexe (NVARCHAR(10)) - الجنس
- Adresse (NVARCHAR(255)) - العنوان
- Profession (NVARCHAR(100)) - المهنة
- TelNumber (NVARCHAR(20)) - رقم الهاتف
- Email (NVARCHAR(100)) - البريد الإلكتروني
- Allergies (NVARCHAR(255)) - الحساسية
- CreatedAt (DATETIME) - تاريخ إنشاء السجل
- Status (NVARCHAR(20)) - حالة العميل

### جدول Dent (الأسنان)
- CodeDent (INT, PK) - معرف السن
- TreatmentType (NVARCHAR(100)) - نوع العلاج
- Description (NVARCHAR(255)) - وصف السن
- Cost (DECIMAL(10,2)) - تكلفة العلاج

### جدول Interventions (التدخلات)
- CodeInt (INT, PK) - معرف التدخل
- Date (DATETIME) - تاريخ التدخل
- CodeClient (INT, FK) - معرف العميل
- CodeDent (INT, FK) - معرف السن
- Cout (DECIMAL(10,2)) - تكلفة التدخل
- Nbre (INT) - العدد
- Acte (NVARCHAR(100)) - الإجراء
- observation (NVARCHAR(255)) - ملاحظات

### جدول RDV (المواعيد)
- CodeRDV (INT, PK) - معرف الموعد
- DateRDV (DATE) - تاريخ الموعد
- Time (NVARCHAR(20)) - وقت الموعد
- ClientID (INT, FK) - معرف العميل
- Comments (NVARCHAR(255)) - ملاحظات

### جدول Users (المستخدمين)
- CodeUser (INT, PK) - معرف المستخدم
- Name (NVARCHAR(50)) - اسم المستخدم
- LastName (NVARCHAR(50)) - اسم العائلة
- Login (NVARCHAR(50)) - اسم الدخول
- Password (NVARCHAR(50)) - كلمة المرور
- role (NVARCHAR(20)) - دور المستخدم

### جدول History (التاريخ)
- CodeHist (INT, PK) - معرف السجل
- CauseOFVisite (NVARCHAR(255)) - سبب الزيارة
- DateVisite (DATETIME) - تاريخ الزيارة
- CodeClient (INT, FK) - معرف العميل

## ملاحظات هامة

1. يجب إعادة تشغيل التطبيق بعد تنفيذ هذه التغييرات
2. تم الاحتفاظ بجميع البيانات الموجودة مسبقاً
3. تم إضافة قيم افتراضية للأعمدة الجديدة
4. تم ربط جدول History بجدول Client لتتبع زيارات المرضى
5. إذا واجهت أي مشاكل، يرجى التحقق من ملف `database_changes_summary.txt` للحصول على مزيد من المعلومات

## بيانات تسجيل الدخول الافتراضية

- اسم المستخدم: `admin`
- كلمة المرور: `admin`
