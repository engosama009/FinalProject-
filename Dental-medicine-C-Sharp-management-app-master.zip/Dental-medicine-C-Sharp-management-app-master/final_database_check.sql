-- Final database check and verification
USE [dentaldoctor]
GO

PRINT '=== DENTAL CLINIC DATABASE VERIFICATION REPORT ==='
PRINT '=================================================='
PRINT ''

-- Check Client table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Client')
BEGIN
    PRINT 'Client table: EXISTS'
    
    -- Check required columns
    DECLARE @MissingColumns NVARCHAR(MAX) = '';
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Allergies')
        SET @MissingColumns = @MissingColumns + 'Allergies, ';
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'CreatedAt')
        SET @MissingColumns = @MissingColumns + 'CreatedAt, ';
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Client') AND name = 'Status')
        SET @MissingColumns = @MissingColumns + 'Status, ';
    
    IF @MissingColumns = ''
        PRINT '  - All required columns exist'
    ELSE
        PRINT '  - Missing columns: ' + LEFT(@MissingColumns, LEN(@MissingColumns) - 1)
    
    -- Check data
    DECLARE @ClientCount INT;
    SELECT @ClientCount = COUNT(*) FROM Client;
    PRINT '  - Contains ' + CAST(@ClientCount AS NVARCHAR) + ' client records'
END
ELSE
BEGIN
    PRINT 'Client table: MISSING'
END

PRINT ''

-- Check Dent table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Dent')
BEGIN
    PRINT 'Dent table: EXISTS'
    
    -- Check required columns
    SET @MissingColumns = '';
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Cost')
        SET @MissingColumns = @MissingColumns + 'Cost, ';
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Dent') AND name = 'Description')
        SET @MissingColumns = @MissingColumns + 'Description, ';
    
    IF @MissingColumns = ''
        PRINT '  - All required columns exist'
    ELSE
        PRINT '  - Missing columns: ' + LEFT(@MissingColumns, LEN(@MissingColumns) - 1)
    
    -- Check data
    DECLARE @DentCount INT;
    SELECT @DentCount = COUNT(*) FROM Dent;
    PRINT '  - Contains ' + CAST(@DentCount AS NVARCHAR) + ' dental treatment records'
END
ELSE
BEGIN
    PRINT 'Dent table: MISSING'
END

PRINT ''

-- Check Interventions table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Interventions')
BEGIN
    PRINT 'Interventions table: EXISTS'
    
    -- Check currency format
    DECLARE @DataType NVARCHAR(128), @Precision INT, @Scale INT;
    SELECT 
        @DataType = TYPE_NAME(system_type_id),
        @Precision = precision,
        @Scale = scale
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Interventions') AND name = 'Cout';
    
    IF @DataType = 'decimal' AND @Precision = 10 AND @Scale = 2
        PRINT '  - Currency format is correct (DECIMAL(10,2))'
    ELSE
        PRINT '  - Currency format needs correction (Current: ' + @DataType + ')'
    
    -- Check data
    DECLARE @InterventionsCount INT;
    SELECT @InterventionsCount = COUNT(*) FROM Interventions;
    PRINT '  - Contains ' + CAST(@InterventionsCount AS NVARCHAR) + ' intervention records'
END
ELSE
BEGIN
    PRINT 'Interventions table: MISSING'
END

PRINT ''

-- Check RDV table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'RDV')
BEGIN
    PRINT 'RDV (Appointments) table: EXISTS'
    
    -- Check data
    DECLARE @RDVCount INT;
    SELECT @RDVCount = COUNT(*) FROM RDV;
    PRINT '  - Contains ' + CAST(@RDVCount AS NVARCHAR) + ' appointment records'
END
ELSE
BEGIN
    PRINT 'RDV (Appointments) table: MISSING'
END

PRINT ''

-- Check Users table
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    PRINT 'Users table: EXISTS'
    
    -- Check primary key
    IF EXISTS (SELECT * FROM sys.key_constraints 
               WHERE parent_object_id = OBJECT_ID('Users')
               AND type = 'PK'
               AND COL_NAME(parent_object_id, parent_column_id) = 'CodeUser')
        PRINT '  - Primary key is correctly set on CodeUser'
    ELSE
        PRINT '  - Primary key is not correctly set on CodeUser'
    
    -- Check data
    DECLARE @UsersCount INT;
    SELECT @UsersCount = COUNT(*) FROM Users;
    PRINT '  - Contains ' + CAST(@UsersCount AS NVARCHAR) + ' user records'
    
    -- Check admin user
    IF EXISTS (SELECT * FROM Users WHERE Login = 'admin')
        PRINT '  - Admin user exists'
    ELSE
        PRINT '  - Admin user is missing'
END
ELSE
BEGIN
    PRINT 'Users table: MISSING'
END

PRINT ''
PRINT '=================================================='
PRINT '=== DATABASE VERIFICATION COMPLETE ==='
GO
